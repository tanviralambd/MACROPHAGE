
# cd C
# cd C:\Program Files\R\R-3.1.1\bin
# C:\Program Files\R\R-3.1.1\bin>Rscript.exe D:\research\MACROPHAGE\R_macrophage_v7\diffExpression_v7PlotNew_ReviewNAR.r

library(MASS)
library(ggplot2)
library(extrafont)
library(stringr)
doAllPlot<-function()
{

myDir="D:/research/MACROPHAGE/R_macrophage_v7_ReviewNAR/"; 
myData="D:/research/MACROPHAGE/data/dataCAGEv7_ReviewNAR/"
myOut="D:/research/MACROPHAGE/data/dataCAGEv7_ReviewNARPlot/"
                                   
# For linux
#myDir="/home/alamt/MACROPHAGE/R_macrophage_v7_ReviewNAR/"; 
#myData="/home/alamt/MACROPHAGE/data/dataCAGEv7_ReviewNAR/"
setwd(myDir);

source('diffExpression_v7PlotNew_ReviewNAR.r')

# Number of replica for all point = 3, except time 24 which has 4 replica

foldName="IFNG"
datafiles=c(
"NFvsIFNG.0vs2.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs4.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs6.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs12.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG=c(
"NFvsIFNG.0vs2.withoutMtb.deg",
"NFvsIFNG.0vs4.withoutMtb.deg",
"NFvsIFNG.0vs6.withoutMtb.deg",
"NFvsIFNG.0vs12.withoutMtb.deg",
"NFvsIFNG.0vs24.withoutMtb.deg");
noRow=4; noCol=4;
#doWork1line(datafiles, datafilesDEG, foldName , noRow, noCol);

# doWorkSeperate(datafiles, datafilesDEG, foldName);

foldName="IL413"
datafiles2=c(
"NFvsIL413.0vs2.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs4.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs6.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs12.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG2=c(
"NFvsIL413.0vs2.withoutMtb.deg",
"NFvsIL413.0vs4.withoutMtb.deg",
"NFvsIL413.0vs6.withoutMtb.deg",
"NFvsIL413.0vs12.withoutMtb.deg",
"NFvsIL413.0vs24.withoutMtb.deg");
noRow=4; noCol=4;
#doWork1line(datafiles2, datafilesDEG2, foldName , noRow, noCol);
# doWorkSeperate(datafiles2, datafilesDEG2, foldName);foldName="IL413"

foldName="BOTH"
#doWork2Lines(datafiles,datafiles2, datafilesDEG, foldName , noRow, noCol);
groupLabel=c("IFNg","IL4+13")
doWork2LinesGGPlot(datafiles,datafiles2, datafilesDEG, foldName , noRow, noCol,groupLabel);


}


doWork2LinesGGPlot<-function(datafiles,datafiles2, datafilesDEG, foldName , noRow, noCol,groupLabel)
{

	colors <- rainbow(2) 
	## First create folder 
	dir.create(file.path(myOut, foldName))
	## a.  Create the Mean of each time point replica by taking Median
	mergedMat = getMergedMat(datafiles);
	mergedMat2 = getMergedMat(datafiles2);
	mergedFinal = cbind(mergedMat,mergedMat2)
	 
	allTrxTableName=paste(myOut , '/', foldName,'/', 'allTrx', foldName , '.table.txt.tagcount.TPM' , sep="");
	write.table(mergedFinal, file = allTrxTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);

	## b. (in case of only DEG) Create the list of unique Trx name
	# uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 

	# b. (in case of ALL  genes) 
	allName= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
	allName=rownames(allName)
	uniqueGeneNames = allName

	# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

	## c.  Load the Trx having same name from ALL trx
	selectedMat=mergedFinal[ uniqueGeneNames ,  ];
	totImage = dim(selectedMat)[1]
	
	
	
	finalMatName=paste(myOut , '/', foldName,'/', foldName , '.mat.txt' , sep="");
	finalTableName=paste(myOut , '/', foldName,'/', foldName , '.table.txt' , sep="");
	write.matrix(selectedMat, file = finalMatName, sep = "\t");
	write.table(selectedMat, file = finalTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);



	## Plot TPM graphs
	allTime=c(0,2,4,6,12,24)
	# pdf( paste(myOut , '/', foldName,'/', foldName , '.pdf' , sep="") ) #if you want, use (png)
	noImagePerPage=noRow*noCol;
	totIteration = ceiling(totImage/noImagePerPage)


	for(curIter in 1:totIteration)
	{
			print(curIter)
			startInd = (curIter-1)*noImagePerPage +1;
			endInd   = (curIter)*noImagePerPage ;	
			if(endInd > totImage)
			{
				endInd = totImage;
			}	
			print( paste( "start at: ", startInd));
			print( paste( "end   at: ", endInd));
			
			
			# pdf( paste(myOut , '/', foldName,'/', foldName , startInd , '.pdf' , sep="") )
			# par(mfrow=c(noRow,noCol) )
				

			if(TRUE){ # SINGLE PLOT for each protein/transcript
				for(i in startInd:endInd  ) {
					# print(i) 
					trxName= rownames(selectedMat)[i]
					curRow = selectedMat[ trxName, ];
					x <- c(0,2,4,6,12,24) # c(0,2,4,6,12,24) , c(24,28,36,48,72,120)
					ywithout <- curRow[1:6]
					ywith <- curRow[7:12]
					
					### ggplot
					totTimePoint=dim(as.matrix(x))[1]
					df  = data.frame(dfX = rep(x, 2), dfY = c( ywithout, ywith ), stimulation = rep(groupLabel, each=totTimePoint ))
					
					p  =  ggplot(df, aes(x=dfX, y=dfY, group=stimulation)) 
					p = p + geom_line(aes(colour = stimulation), linetype = 1) + labs(list(title = trxName, x = "Time points", y = "Avg. Expression"))
					p+ scale_x_discrete(breaks=x,labels=x) + theme_bw() + theme(axis.text=element_text(size=18), axis.title=element_text(size=18,face="bold") , plot.title = element_text(size=24,face="bold"))
			
					### end ggplot
					
		
					ggsave(file=paste(myOut , '/', foldName,'/', trxName , '.png' , sep="") , width = 100, height = 80, units = "mm", dpi = 400, scale = 2 )
				
				}
			}		
			
			# dev.off()	
			
	}

}


doWork2Lines<-function(datafiles,datafiles2, datafilesDEG, foldName , noRow, noCol)
{

	colors <- rainbow(2) 
	## First create folder 
	dir.create(file.path(myOut, foldName))
	## a.  Create the Mean of each time point replica by taking Median
	mergedMat = getMergedMat(datafiles);
	mergedMat2 = getMergedMat(datafiles2);
	mergedFinal = cbind(mergedMat,mergedMat2)
	 
	allTrxTableName=paste(myOut , '/', foldName,'/', 'allTrx', foldName , '.table.txt.tagcount.TPM' , sep="");
	write.table(mergedFinal, file = allTrxTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);

	## b. (in case of only DEG) Create the list of unique Trx name
	# uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 

	# b. (in case of ALL  genes) 
	allName= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
	allName=rownames(allName)
	uniqueGeneNames = allName

	# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

	## c.  Load the Trx having same name from ALL trx
	selectedMat=mergedFinal[ uniqueGeneNames ,  ];
	totImage = dim(selectedMat)[1]
	
	
	
	finalMatName=paste(myOut , '/', foldName,'/', foldName , '.mat.txt' , sep="");
	finalTableName=paste(myOut , '/', foldName,'/', foldName , '.table.txt' , sep="");
	write.matrix(selectedMat, file = finalMatName, sep = "\t");
	write.table(selectedMat, file = finalTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);



	## Plot TPM graphs
	allTime=c(0,2,4,6,12,24)
	# pdf( paste(myOut , '/', foldName,'/', foldName , '.pdf' , sep="") ) #if you want, use (png)
	noImagePerPage=noRow*noCol;
	totIteration = ceiling(totImage/noImagePerPage)


	for(curIter in 1:totIteration)
	{
			print(curIter)
			startInd = (curIter-1)*noImagePerPage +1;
			endInd   = (curIter)*noImagePerPage ;	
			if(endInd > totImage)
			{
				endInd = totImage;
			}	
			print( paste( "start at: ", startInd));
			print( paste( "end   at: ", endInd));
			
			
			pdf( paste(myOut , '/', foldName,'/', foldName , startInd , '.pdf' , sep="") )
			par(mfrow=c(noRow,noCol) )
				

			if(TRUE){ # COMBINED PLOT
				for(i in startInd:endInd  ) {
					# print(i) 
					trxName= rownames(selectedMat)[i]
					curRow = selectedMat[ trxName, ];
					x <- c(0,2,4,6,12,24) # c(0,2,4,6,12,24) , c(24,28,36,48,72,120)
					ywithout <- curRow[1:6]
					ywith <- curRow[7:12]
					# plot(x,ywithout, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(24, 120), sub=trxName, col="red" , xaxt='n')
					
					# get the range for the x and y axis
					xrange <- range(x)
					yrange <- range(c(ywithout,ywith))

					# set up the plot
					p1<-plot(xrange, yrange, axes=F,type="n", xlab='Time Points', ylab='Avg. Expr (TPM)' , xlim=c(0, 24) ,  sub=trxName, col="red" , xaxt='n')
					#p1<-plot(x, ywithout, axes=F,type="n", xlab='Time Points', ylab='Avg. Expr (TPM)' , xlim=c(24, 120) ,  sub=trxName, col="red" , xaxt='n')
					axis(1, at=allTime)
					#axis(2, at=cbind( floor(yrange[1]), ceiling(yrange[2]) ) )
					axis(2, at=floor(yrange))
					#axis(2, at=yrange )
					lines(x, ywithout, type="b", lwd=1.5,   col=colors[1])
					lines(x, ywith,    type="b", lwd=1.5,   col=colors[2])
				}
			}		
			
			dev.off()	
			
	}

}

doWork1Line<-function(datafiles, datafilesDEG, foldName , noRow, noCol)
{

## First create folder 
dir.create(file.path(myOut, foldName))
## a.  Create the Mean of each time point replica by taking Median
mergedMat = getMergedMat(datafiles);
allTrxTableName=paste(myOut , '/', foldName,'/', 'allTrx', foldName , '.table.txt.tagcount.TPM' , sep="");
write.table(mergedMat, file = allTrxTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);

## b.  Create the list of unique Trx name
# uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 

# b. All gene names 
allName= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
allName=rownames(allName)
uniqueGeneNames = allName

# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

## c.  Load the Trx having same name from ALL trx
selectedMat=mergedMat[ uniqueGeneNames ,  ];
totImage = dim(selectedMat)[1]

finalMatName=paste(myOut , '/', foldName,'/', foldName , '.mat.txt' , sep="");
finalTableName=paste(myOut , '/', foldName,'/', foldName , '.table.txt' , sep="");
write.matrix(selectedMat, file = finalMatName, sep = "\t");
write.table(selectedMat, file = finalTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);



## Plot TPM graphs
allTime=c(0,2,4,6,12,24)
# pdf( paste(myOut , '/', foldName,'/', foldName , '.pdf' , sep="") ) #if you want, use (png)
noImagePerPage=noRow*noCol;
totIteration = ceiling(totImage/noImagePerPage)


for(curIter in 1:totIteration)
{
		print(curIter)
		startInd = (curIter-1)*noImagePerPage +1;
		endInd   = (curIter)*noImagePerPage ;	
		if(endInd > totImage)
		{
			endInd = totImage;
		}	
		print( paste( "start at: ", startInd));
		print( paste( "end   at: ", endInd));
		
		
		pdf( paste(myOut , '/', foldName,'/', foldName , startInd , '.pdf' , sep="") )
		par(mfrow=c(noRow,noCol) )
			
			
		for(i in startInd:endInd  ) {
			
				trxName= rownames(selectedMat)[i]
				curRow = selectedMat[ trxName, ];
				x <- c(0,2,4,6,12,24)
				y <- curRow
				plot(x,y, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(0, 24), sub=trxName, col="red" , xaxt='n')
				axis(1, at=allTime)
			
		}	
			
		if(FALSE){ # COMBINED PLOT
			for(i in startInd:endInd  ) {
				# print(i) 
				trxName= rownames(selectedMat)[i]
				curRow = selectedMat[ trxName, ];
				x <- c(24,28,36,48,72) # c(0,2,4,6,12,24) , c(24,28,36,48,72,120)
				ywithout <- curRow[1:5]
				ywith <- curRow[6:10]
				# plot(x,ywithout, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(24, 120), sub=trxName, col="red" , xaxt='n')
				
				# get the range for the x and y axis
				xrange <- range(x)
				yrange <- range(c(ywithout,ywith))

				# set up the plot
				p1<-plot(xrange, yrange, axes=F,type="n", xlab='Time Points', ylab='Avg. Expr (TPM)' , xlim=c(24, 72) ,  sub=trxName, col="red" , xaxt='n')
				#p1<-plot(x, ywithout, axes=F,type="n", xlab='Time Points', ylab='Avg. Expr (TPM)' , xlim=c(24, 120) ,  sub=trxName, col="red" , xaxt='n')
				axis(1, at=allTime)
				#axis(2, at=cbind( floor(yrange[1]), ceiling(yrange[2]) ) )
				axis(2, at=floor(yrange))
				#axis(2, at=yrange )
				lines(x, ywithout, type="b", lwd=1.5,   col=colors[1])
				lines(x, ywith,    type="b", lwd=1.5,   col=colors[2])
			}
		}		
		
		dev.off()	
		
}


}


doWorkSeperate<-function(datafiles, datafilesDEG, foldName )
{

## a.  Create the Median of each time point replica by taking Median
mergedMat = getMergedMat(datafiles);

## b.  Create the list of unique Trx name
uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 
# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

## c.  Load the Trx having same name from ALL trx
selectedMat=mergedMat[ uniqueGeneNames ,  ];

## Plot TPM graphs
allTime=c(0,2,4,6,12,24)


noRow=1
noCol=1;
for(i in 1:  length(rownames(selectedMat))  ) {
    trxName= rownames(selectedMat)[i]
	curRow = selectedMat[ trxName, ];
	x <- c(0,2,4,6,12,24)
	y <- curRow
	pdf( paste(myOut , '/', foldName,'/', trxName , '.pdf' , sep="") , bg="white" ) #if you want, use (png)
	par(mfrow=c(noRow,noCol) )
	plot(x,y, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(0, 24), sub=trxName, col="red" , xaxt='n')
	axis(1, at=allTime)
	dev.off()
}
#print(filePath)


}


getMergedMat_Median <- function(datafiles) {


mat2= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
val0=mat2[,1:3]
val0 = as.matrix(val0)
val0=apply(val0, 1, median)

totCol=ncol(mat2)
val2=mat2[,4:totCol]
val2 = as.matrix(val2)
val2=apply(val2, 1, median)

mat4= read.table( paste(  myData,"/",datafiles[2] , sep=""), header=T, row.names=1)
totCol=ncol(mat4)
val4=mat4[,4:totCol]
val4 = as.matrix(val4)
val4=apply(val4, 1, median)

mat6= read.table( paste(  myData,"/",datafiles[3] , sep=""), header=T, row.names=1)
totCol=ncol(mat6)
val6=mat6[,4:totCol]
val6 = as.matrix(val6)
val6=apply(val6, 1, median)

mat12= read.table( paste(  myData,"/",datafiles[4] , sep=""), header=T, row.names=1)
totCol=ncol(mat12)
val12=mat12[,4:totCol]
val12 = as.matrix(val12)
val12=apply(val12, 1, median)


mat24= read.table( paste(  myData,"/",datafiles[5] , sep=""), header=T, row.names=1)
totCol=ncol(mat24)
val24=mat24[,4:totCol]
val24 = as.matrix(val24)
val24=apply(val24, 1, median)


mergedMat = cbind(val0,val2,val4,val6,val12,val24);
return (mergedMat);
}


getMergedMat <- function(datafiles) {


mat2= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
val0=mat2[,1:3]
val0 = as.matrix(val0)
val0=apply(val0, 1, mean)

totCol=ncol(mat2)
val2=mat2[,4:totCol]
val2 = as.matrix(val2)
val2=apply(val2, 1, mean)

mat4= read.table( paste(  myData,"/",datafiles[2] , sep=""), header=T, row.names=1)
totCol=ncol(mat4)
val4=mat4[,4:totCol]
val4 = as.matrix(val4)
val4=apply(val4, 1, mean)

mat6= read.table( paste(  myData,"/",datafiles[3] , sep=""), header=T, row.names=1)
totCol=ncol(mat6)
val6=mat6[,4:totCol]
val6 = as.matrix(val6)
val6=apply(val6, 1, mean)

mat12= read.table( paste(  myData,"/",datafiles[4] , sep=""), header=T, row.names=1)
totCol=ncol(mat12)
val12=mat12[,4:totCol]
val12 = as.matrix(val12)
val12=apply(val12, 1, mean)


mat24= read.table( paste(  myData,"/",datafiles[5] , sep=""), header=T, row.names=1)
totCol=ncol(mat24)
val24=mat24[,4:totCol]
val24 = as.matrix(val24)
val24=apply(val24, 1, mean)


mergedMat = cbind(val0,val2,val4,val6,val12,val24);
return (mergedMat);
}


getUniqueGeneNamesWrong <- function(datafilesDEG) {

curName2= read.table( paste(  myData,"/",datafilesDEG[1] , sep=""), header=T, row.names=1)
curName2=rownames(curName2)
totCol=dim(curName2)
if (is.null(totCol)) { # ONLY ONLY FOR IL4. if you use it for other then result will be wrong
   # curName2=NULL;
}

curName4= read.table( paste(  myData,"/",datafilesDEG[2] , sep=""), header=T, row.names=1)
curName4=rownames(curName4)

curName6= read.table( paste(  myData,"/",datafilesDEG[3] , sep=""), header=T, row.names=1)
curName6=rownames(curName6)

curName12= read.table( paste(  myData,"/",datafilesDEG[4] , sep=""), header=T, row.names=1)
curName12=rownames(curName12)

curName24= read.table( paste(  myData,"/",datafilesDEG[5] , sep=""), header=T, row.names=1)
curName24=rownames(curName24)

finalName=union(curName2,curName4)
finalName=union(finalName,curName6)
finalName=union(finalName,curName12)
finalName=union(finalName,curName24)


return (finalName);
}


getUniqueGeneNames <- function(datafilesDEG) {

curName2= read.table( paste(  myData,"/",datafilesDEG[1] , sep=""), header=T, row.names=1)
totRow=nrow(curName2)
totCol=ncol(curName2)
if(totRow==0 || totCol==1)
{
	curName2 = NULL
}else
{
	curName2=rownames(curName2)
}

curName4= read.table( paste(  myData,"/",datafilesDEG[2] , sep=""), header=T, row.names=1)
totRow=nrow(curName4)
totCol=ncol(curName4)
if(totRow==0 || totCol==1)
{
	curName4 = NULL
}else
{
	curName4=rownames(curName4)
}

curName6= read.table( paste(  myData,"/",datafilesDEG[3] , sep=""), header=T, row.names=1)
totRow=nrow(curName6)
totCol=ncol(curName6)
if(totRow==0 || totCol==1)
{
	curName6 = NULL
}else
{
	curName6=rownames(curName6)
}
curName12= read.table( paste(  myData,"/",datafilesDEG[4] , sep=""), header=T, row.names=1)
totRow=nrow(curName12)
totCol=ncol(curName12)
if(totRow==0 || totCol==1)
{
	curName12 = NULL
}else
{
	curName12=rownames(curName12)
}

curName24= read.table( paste(  myData,"/",datafilesDEG[5] , sep=""), header=T, row.names=1)
totRow=nrow(curName24)
totCol=ncol(curName24)
if(totRow==0 || totCol==1)
{
	curName24 = NULL
}else
{
	curName24=rownames(curName24)
}

finalName=union(curName2,curName4)
finalName=union(finalName,curName6)
finalName=union(finalName,curName12)
finalName=union(finalName,curName24)

return (finalName);
}	


