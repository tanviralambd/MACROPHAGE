# cd C
# cd C:\Program Files\R\R-3.1.1\bin
# C:\Program Files\R\R-3.1.1\bin>Rscript.exe D:\research\MACROPHAGE\R_macrophage_v7\caller_diffExpression_v7_TB.r
if(T){
	library(MASS)
	# library(maSigPro)
	# library(DESeq)
	library(limma)
	library(edgeR) 
}
# For Windows
myDir="D:/research/MACROPHAGE/R_macrophage_v7_TB/"; 
myData="D:/research/MACROPHAGE/data/dataCAGEv7_TB/"

# For linux
#myDir="/home/alamt/MACROPHAGE/R_macrophage_v7_TB/"; 
#myData="/home/alamt/MACROPHAGE/data/dataCAGEv7_TB/"


setwd(myDir);
source('diffExpression_v7_TB.r')


noStim="mouse_macrophage_TB_infection_non-stimulated.counts.csv" # No need to use it. It does not contain 0 time point

allStim= c("mouse_macrophage_TB_infection_IFNg.counts.csv",
"mouse_macrophage_TB_infection_IL4.counts.csv",
"mouse_macrophage_TB_infection_IL13.counts.csv",
"mouse_macrophage_TB_infection_IL4-IL13.counts.csv");

## (NS) vs (S)
allTime=c("0", "2", "4","6","12","24","28","36","48","72","120");
# strangeTime=c( "2", "4","6","12","24");
strangeTime=c( "4", "12","24","48");
baseTime=c("0");

startPointBeforeMtb=c("4");
endPointBeforeMtb=c("24");


afterTime=c("28","36","48","72","120");
startPointAfterMtb=c("28");
endPointAfterMtb=c("120");

 normal  =c("NFvsIFNG","NFvsIL4","NFvsIL13","NFvsIL413");
 reverse =c("IFNGvsNF","IL4vsNF","IL13vsNF","IL413vsNF");
 allOut=normal;
 
 
 
extWithoutMtb=".withoutMtb"
extDESeq=".DESEQ"
extEDGEr=".EDGER"
extNorm=".norm"
extLibsize=".libsize"

#######################################################
#### Merge  data in (0,2) ; (0,4) ; (0,6) ; (0,12) ; (0,24)
#######################################################

if(T){
	fnmNoStim= paste(myData , allStim[1] , ".matrix", ".", 0, ".",0 ,  extWithoutMtb,  sep="");
	#baseMat = read.table(fnmNoStim, header=T, row.names=1)
	fnmNoStimLibsize=paste(myData , allStim[1] ,  ".", 0, ".",0 , extLibsize , extWithoutMtb,  sep="");
	#baseMatLibSize = read.table(fnmNoStimLibsize, header=T, row.names=NULL)
	
		
	for(i in 1:length(allOut) ) { # length(allOut)  2: 2
	   
		for(curTime in strangeTime ) {  # for time 2..24
			timeStart=curTime;
			timeEnd=curTime;
			
			
			fnmStim= paste(myData , allStim[i] , ".matrix", ".", timeStart, ".",timeEnd ,  extWithoutMtb,  sep="");
			fnmStimLibSize= paste(myData , allStim[i] , ".", timeStart, ".",timeEnd , extLibsize,extWithoutMtb,  sep="");
			# doAnalysis( fnmNoStim, fnmStim, fnmNoStimLibsize , fnmStimLibSize , allOut[i] , baseTime ,timeStart ,  extWithoutMtb);
			doAnalysisFC( fnmNoStim, fnmStim, fnmNoStimLibsize , fnmStimLibSize , allOut[i] , baseTime ,timeStart ,  extWithoutMtb);

			if(FALSE)
			{
			
				fnmData1=fnmNoStim;
				fnmData2=fnmStim;
				fnmLibsize1=fnmNoStimLibsize;
				fnmLibsize2=fnmStimLibSize;
				outPrefix=allOut[i];
				baseTime=baseTime;
				timeInterest=timeStart;
				extWithoutMtb=extWithoutMtb;
			}
			
			
		}
	}
}



## Merge Log(Fold Change )

if(T){

# for IFNG
	if(F){
		foldName="IFNG"
		outPrefix="NFvsIFNG"
		datafiles=c(
		"NFvsIFNG.0vs4.withoutMtb.all.stat",
		"NFvsIFNG.0vs12.withoutMtb.all.stat",
		"NFvsIFNG.0vs24.withoutMtb.all.stat",
		"NFvsIFNG.0vs48.withoutMtb.all.stat",);
		datafilesDEG=c(
		"NFvsIFNG.0vs4.withoutMtb.deg",
		"NFvsIFNG.0vs12.withoutMtb.deg",
		"NFvsIFNG.0vs24.withoutMtb.deg",
		"NFvsIFNG.0vs48.withoutMtb.deg",);
		annotationFile="mouse_macrophage_TB_infection_IFNg.counts.csv.annotation";
	}

	# for IL413
	if(T){
		foldName="IL413"
		outPrefix="NFvsIL413"
		datafiles=c(
		"NFvsIL413.0vs4.withoutMtb.all.stat",
		"NFvsIL413.0vs12.withoutMtb.all.stat",
		"NFvsIL413.0vs24.withoutMtb.all.stat",
		"NFvsIL413.0vs48.withoutMtb.all.stat",);
		datafilesDEG=c(
		"NFvsIL413.0vs4.withoutMtb.deg",
		"NFvsIL413.0vs12.withoutMtb.deg",
		"NFvsIL413.0vs24.withoutMtb.deg",
		"NFvsIL413.0vs48.withoutMtb.deg",);
		annotationFile="mouse_macrophage_TB_infection_IL4-IL13.counts.csv.annotation"
	}

	## a.  Create the Median of each time point replica by taking Median
	outName=paste(myData , outPrefix , ".allTime" ,  extWithoutMtb,  ".FC"   ,sep="");

	mergedMatFC = getMergedMatLogFoldChange(datafiles);
	write.table(mergedMatFC[,2:6],sep="\t",quote=FALSE,row.names=mergedMatFC[,1],col.names=TRUE,file=outName )
	mergedMatFC = read.table(sep="\t",header=T, row.names=1,file=outName )


	## b. Create the list of unique Trx name
	uniqueGeneNames= getUniqueGeneNames(datafilesDEG) ;
	## c. Load the Trx having same name from ALL trx
	selectedMat=mergedMatFC[ uniqueGeneNames ,  ];

	outNameDEG=paste(myData , outPrefix , ".allTime.deg" ,  extWithoutMtb,  ".FC"   ,sep="");
	write.table(selectedMat,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=outNameDEG )

	## d. Find the cluster Names
	matAnnot = read.table(sep="\t",header=T, row.names=1,file=paste(myData , annotationFile   ,sep="") )
	selectedMatAnnot=matAnnot[uniqueGeneNames, ];
	outAnnotDEG=paste(myData , outPrefix , ".allTime.deg" ,  extWithoutMtb,  ".clusterid"   ,sep="");
	write.table(selectedMatAnnot[,1],sep="\t",quote=FALSE,row.names=rownames(selectedMatAnnot),col.names=TRUE,file=outAnnotDEG )

}
