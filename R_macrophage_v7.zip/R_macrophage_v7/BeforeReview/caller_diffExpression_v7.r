# cd C
# cd C:\Program Files\R\R-3.1.1\bin
# C:\Program Files\R\R-3.1.1\bin>Rscript.exe D:\research\MACROPHAGE\R_macrophage_v7\caller_diffExpression_v7.r
if(T){
	library(MASS)
	# library(maSigPro)
	# library(DESeq)
	library(limma)
	library(edgeR) 
}
# For Windows
myDir="D:/research/MACROPHAGE/R_macrophage_v7/"; 
myData="D:/research/MACROPHAGE/data/dataCAGEv7/"

# For linux
#myDir="/home/alamt/MACROPHAGE/R_macrophage_v7/"; 
#myData="/home/alamt/MACROPHAGE/data/dataCAGEv7/"


setwd(myDir);
source('diffExpression_v7.r')


noStim="mouse_macrophage_TB_infection_non-stimulated.counts.csv" # No need to use it. It does not contain 0 time point

allStim= c("mouse_macrophage_TB_infection_IFNg.counts.csv",
"mouse_macrophage_TB_infection_IL4.counts.csv",
"mouse_macrophage_TB_infection_IL13.counts.csv",
"mouse_macrophage_TB_infection_IL4-IL13.counts.csv");

## (NS) vs (S)
allTime=c("0", "2", "4","6","12","24","28","36","48","72","120");
befMtbTime=c( "2", "4","6","12","24");
baseTime=c("0");

startPointBeforeMtb=c("4");
endPointBeforeMtb=c("24");


afterTime=c("28","36","48","72","120");
startPointAfterMtb=c("28");
endPointAfterMtb=c("120");

 normal  =c("NFvsIFNG","NFvsIL4","NFvsIL13","NFvsIL413");
 reverse =c("IFNGvsNF","IL4vsNF","IL13vsNF","IL413vsNF");
 allOut=normal;
 
 
 
extWithoutMtb=".withoutMtb"
extDESeq=".DESEQ"
extEDGEr=".EDGER"
extNorm=".norm"
extLibsize=".libsize"

#######################################################
#### Merge  data in (0,2) ; (0,4) ; (0,6) ; (0,12) ; (0,24)
#######################################################

if(T){
	fnmNoStim= paste(myData , allStim[1] , ".matrix", ".", 0, ".",0 ,  extWithoutMtb,  sep="");
	#baseMat = read.table(fnmNoStim, header=T, row.names=1)
	fnmNoStimLibsize=paste(myData , allStim[1] ,  ".", 0, ".",0 , extLibsize , extWithoutMtb,  sep="");
	#baseMatLibSize = read.table(fnmNoStimLibsize, header=T, row.names=NULL)
	
		
	for(i in 1:length(allOut) ) { # length(allOut)  2: 2
	   
		for(curTime in befMtbTime ) {  # for time 2..24
			timeStart=curTime;
			timeEnd=curTime;
			
			
			fnmStim= paste(myData , allStim[i] , ".matrix", ".", timeStart, ".",timeEnd ,  extWithoutMtb,  sep="");
			fnmStimLibSize= paste(myData , allStim[i] , ".", timeStart, ".",timeEnd , extLibsize,extWithoutMtb,  sep="");
			doAnalysis( fnmNoStim, fnmStim, fnmNoStimLibsize , fnmStimLibSize , allOut[i] , baseTime ,timeStart ,  extWithoutMtb);

			
			# NO NEED TO WRITE HERE
			#fnmOutputMerge= paste(myData , allOut[i] , ".matrix", ".", baseTime, "vs",timeStart ,  extWithoutMtb,  sep="");
			#curMat = read.table(fnmStim, header=T, row.names=1)
			#mergedMat = cbind(baseMat,curMat);
			#write.table( mergedMat, file=fnmOutputMerge,row.names=T,col.names=T, sep='\t',quote=F);
			
			
			
			
			
		}


		
	}

}

