
# cd C
# cd C:\Program Files\R\R-3.1.1\bin
# C:\Program Files\R\R-3.1.1\bin>Rscript.exe D:\research\MACROPHAGE\R_macrophage_v7\diffExpression_v7PlotNew.r

library(MASS)
library(gplots)
library(extrafont)

doAllPlot<-function()
{

myDir="D:/research/MACROPHAGE/R_macrophage_v7/"; 
myData="D:/research/MACROPHAGE/data/dataCAGEv7/"
myOut="D:/research/MACROPHAGE/data/dataCAGEv7Plot/"

# For linux
#myDir="/home/alamt/MACROPHAGE/R_macrophage_v7/"; 
#myData="/home/alamt/MACROPHAGE/data/dataCAGEv7/"
setwd(myDir);

source('diffExpression_v7PlotNew.r')

# Number of replica for all point = 3, except time 24 which has 4 replica

foldName="IFNG"
datafiles=c(
"NFvsIFNG.0vs2.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs4.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs6.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs12.withoutMtb.tagcount.TPM",
"NFvsIFNG.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG=c(
"NFvsIFNG.0vs2.withoutMtb.deg",
"NFvsIFNG.0vs4.withoutMtb.deg",
"NFvsIFNG.0vs6.withoutMtb.deg",
"NFvsIFNG.0vs12.withoutMtb.deg",
"NFvsIFNG.0vs24.withoutMtb.deg");
# doWork(datafiles, datafilesDEG, foldName , 4,5);
# doWorkSeperate(datafiles, datafilesDEG, foldName);

foldName="IL413"
datafiles=c(
"NFvsIL413.0vs2.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs4.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs6.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs12.withoutMtb.tagcount.TPM",
"NFvsIL413.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG=c(
"NFvsIL413.0vs2.withoutMtb.deg",
"NFvsIL413.0vs4.withoutMtb.deg",
"NFvsIL413.0vs6.withoutMtb.deg",
"NFvsIL413.0vs12.withoutMtb.deg",
"NFvsIL413.0vs24.withoutMtb.deg");
# doWork(datafiles, datafilesDEG, foldName , 4, 4);
# doWorkSeperate(datafiles, datafilesDEG, foldName);foldName="IL413"





foldName="IL4"
datafiles=c(
"NFvsIL4.0vs2.withoutMtb.tagcount.TPM",
"NFvsIL4.0vs4.withoutMtb.tagcount.TPM",
"NFvsIL4.0vs6.withoutMtb.tagcount.TPM",
"NFvsIL4.0vs12.withoutMtb.tagcount.TPM",
"NFvsIL4.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG=c(
"NFvsIL4.0vs2.withoutMtb.deg",
"NFvsIL4.0vs4.withoutMtb.deg",
"NFvsIL4.0vs6.withoutMtb.deg",
"NFvsIL4.0vs12.withoutMtb.deg",
"NFvsIL4.0vs24.withoutMtb.deg");
# doWorkSeperate(datafiles, datafilesDEG, foldName);
# doWork(datafiles, datafilesDEG, foldName , 4, 5); ## Total 18


foldName="IL13"
datafiles=c(
"NFvsIL13.0vs2.withoutMtb.tagcount.TPM",
"NFvsIL13.0vs4.withoutMtb.tagcount.TPM",
"NFvsIL13.0vs6.withoutMtb.tagcount.TPM",
"NFvsIL13.0vs12.withoutMtb.tagcount.TPM",
"NFvsIL13.0vs24.withoutMtb.tagcount.TPM");
datafilesDEG=c(
"NFvsIL13.0vs2.withoutMtb.deg",
"NFvsIL13.0vs4.withoutMtb.deg",
"NFvsIL13.0vs6.withoutMtb.deg",
"NFvsIL13.0vs12.withoutMtb.deg",
"NFvsIL13.0vs24.withoutMtb.deg");
#doWorkSeperate(datafiles, datafilesDEG, foldName);
# doWork(datafiles, datafilesDEG, foldName , 4, 4); ## Total 16


}

doWork<-function(datafiles, datafilesDEG, foldName , noRow, noCol)
{



## a.  Create the Mean of each time point replica by taking Median
mergedMat = getMergedMat(datafiles);
allTrxTableName=paste(myOut , '/', foldName,'/', 'allTrx', foldName , '.table.txt.tagcount.TPM' , sep="");
write.table(mergedMat, file = allTrxTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);
## b.  Create the list of unique Trx name
uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 
# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

## c.  Load the Trx having same name from ALL trx
selectedMat=mergedMat[ uniqueGeneNames ,  ];


finalMatName=paste(myOut , '/', foldName,'/', foldName , '.mat.txt' , sep="");
finalTableName=paste(myOut , '/', foldName,'/', foldName , '.table.txt' , sep="");
write.matrix(selectedMat, file = finalMatName, sep = "\t");
write.table(selectedMat, file = finalTableName, sep = "\t", row.names=TRUE,col.names=TRUE,);

##################### HEATMAP GENERATION ###################
 if (F){

	 ############## Step - 1   #############
	 
	 ## MANUALLY CREATE IFNG.up.table.txt  FOR IFNG. you have to manually remove 3 upregulated trx 067618.4 , 133125.1 , 147681.1
	 
	 ############# Step -2  #############
	 
	## option 1 - USED
	# install.packages("gplots") 
	#library(gplots)
	finalFile=paste(myOut , '/', foldName,'/', foldName , '.up.table.txt' , sep="");
	finalTable=read.table(finalFile)
	finalMat=as.matrix(finalTable)
	myE=0.00000001
	finalMatLog2=log( (finalMat+myE),2)

	labRow=rownames(finalTable)
	newLabRow= substr( labRow,7,21)
	newLabRow=labRow

	newLabCol=c( "Unstimulated_0 h", "IFN γ_2 h", "IFN γ_4 h", "IFN γ_6 h", "IFN γ_12 h", "IFN γ_24 h")
	newLabCol=c( "Unstimulated_0 h", "IL4IL13_2 h", "IL4IL13_4 h", "IL4IL13_6 h", "IL4IL13_12 h", "IL4IL13_24 h" );
	#pdf("the.pdf", width = 250, height = 250)
	#dev.off()

	#heatmap.2(as.matrix(finalMatLog2), col=redblue(75), scale="row", key=T, keysize=1.5,density.info="none", trace="none",cexCol=0.9,cexRow=.5,labRow=newLabRow,labCol=newLabCol ,srtRow=0, srtCol=45, offsetRow=0, offsetCol=0     )    
	heatmap.2(as.matrix(finalMatLog2), col=redblue(75), scale="row", key=T, keysize=1.5,density.info="none", trace="none",cexCol=0.9,cexRow=.5,labRow=newLabRow,labCol=newLabCol ,srtRow=20, srtCol=45, offsetRow=-1, offsetCol=0     )    
	 

	 
	# Opt2 Simple  -- NOT USED
	#selectedMatLog2=log(selectedMat,2)
	#mtscaled <- as.matrix(scale(selectedMatLog2))
	#heatmap(mtscaled, Colv=F, scale='none')
	#heatmap(mtscaled, Rowv=NA, Colv=NA, col = heat.colors(256), scale="column", margins=c(5,10))


	# opt 3 -- NOT USED
	#require(graphics); require(grDevices)
	#x  <- as.matrix(selectedMatLog2)
	#rc <- rainbow(nrow(x), start = 0, end = 1.0)
	#cc <- rainbow(ncol(x), start = 0, end = 1.0)
	#hv <- heatmap(x, col = cm.colors(256), scale = "column",RowSideColors = rc, ColSideColors = cc, margins = c(5,10),xlab = "Time(hr)", ylab =  "",main = "")
	#utils::str(hv) # the two re-ordering index vectors


}
 
## Plot TPM graphs
allTime=c(0,2,4,6,12,24)
pdf( paste(myOut , '/', foldName,'/', foldName , '.pdf' , sep="") ) #if you want, use (png)
noRow=4;
noCol=4;
par(mfrow=c(noRow,noCol) )
 for(i in 1:  length(rownames(selectedMat))  ) {
    trxName= rownames(selectedMat)[i]
	curRow = selectedMat[ trxName, ];
	x <- c(0,2,4,6,12,24)
	y <- curRow
	plot(x,y, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(0, 24), sub=trxName, col="red" , xaxt='n')
	axis(1, at=allTime)
}
#print(filePath)
dev.off()

}


doWorkSeperate<-function(datafiles, datafilesDEG, foldName )
{

## a.  Create the Median of each time point replica by taking Median
mergedMat = getMergedMat(datafiles);

## b.  Create the list of unique Trx name
uniqueGeneNames= getUniqueGeneNames(datafilesDEG) 
# NO NEED uniqueGeneNames=as.table(uniqueGeneNames)

## c.  Load the Trx having same name from ALL trx
selectedMat=mergedMat[ uniqueGeneNames ,  ];

## Plot TPM graphs
allTime=c(0,2,4,6,12,24)


noRow=1
noCol=1;
for(i in 1:  length(rownames(selectedMat))  ) {
    trxName= rownames(selectedMat)[i]
	curRow = selectedMat[ trxName, ];
	x <- c(0,2,4,6,12,24)
	y <- curRow
	pdf( paste(myOut , '/', foldName,'/', trxName , '.pdf' , sep="") , bg="white" ) #if you want, use (png)
	par(mfrow=c(noRow,noCol) )
	plot(x,y, type='b',xlab='Time Points', ylab='Avg. Expression (TPM)' , xlim=c(0, 24), sub=trxName, col="red" , xaxt='n')
	axis(1, at=allTime)
	dev.off()
}
#print(filePath)


}


getMergedMat_Median <- function(datafiles) {


mat2= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
val0=mat2[,1:3]
val0 = as.matrix(val0)
val0=apply(val0, 1, median)

totCol=ncol(mat2)
val2=mat2[,4:totCol]
val2 = as.matrix(val2)
val2=apply(val2, 1, median)

mat4= read.table( paste(  myData,"/",datafiles[2] , sep=""), header=T, row.names=1)
totCol=ncol(mat4)
val4=mat4[,4:totCol]
val4 = as.matrix(val4)
val4=apply(val4, 1, median)

mat6= read.table( paste(  myData,"/",datafiles[3] , sep=""), header=T, row.names=1)
totCol=ncol(mat6)
val6=mat6[,4:totCol]
val6 = as.matrix(val6)
val6=apply(val6, 1, median)

mat12= read.table( paste(  myData,"/",datafiles[4] , sep=""), header=T, row.names=1)
totCol=ncol(mat12)
val12=mat12[,4:totCol]
val12 = as.matrix(val12)
val12=apply(val12, 1, median)


mat24= read.table( paste(  myData,"/",datafiles[5] , sep=""), header=T, row.names=1)
totCol=ncol(mat24)
val24=mat24[,4:totCol]
val24 = as.matrix(val24)
val24=apply(val24, 1, median)


mergedMat = cbind(val0,val2,val4,val6,val12,val24);
return (mergedMat);
}


getMergedMat <- function(datafiles) {


mat2= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T, row.names=1)
val0=mat2[,1:3]
val0 = as.matrix(val0)
val0=apply(val0, 1, mean)

totCol=ncol(mat2)
val2=mat2[,4:totCol]
val2 = as.matrix(val2)
val2=apply(val2, 1, mean)

mat4= read.table( paste(  myData,"/",datafiles[2] , sep=""), header=T, row.names=1)
totCol=ncol(mat4)
val4=mat4[,4:totCol]
val4 = as.matrix(val4)
val4=apply(val4, 1, mean)

mat6= read.table( paste(  myData,"/",datafiles[3] , sep=""), header=T, row.names=1)
totCol=ncol(mat6)
val6=mat6[,4:totCol]
val6 = as.matrix(val6)
val6=apply(val6, 1, mean)

mat12= read.table( paste(  myData,"/",datafiles[4] , sep=""), header=T, row.names=1)
totCol=ncol(mat12)
val12=mat12[,4:totCol]
val12 = as.matrix(val12)
val12=apply(val12, 1, mean)


mat24= read.table( paste(  myData,"/",datafiles[5] , sep=""), header=T, row.names=1)
totCol=ncol(mat24)
val24=mat24[,4:totCol]
val24 = as.matrix(val24)
val24=apply(val24, 1, mean)


mergedMat = cbind(val0,val2,val4,val6,val12,val24);
return (mergedMat);
}


getUniqueGeneNamesWrong <- function(datafilesDEG) {

curName2= read.table( paste(  myData,"/",datafilesDEG[1] , sep=""), header=T, row.names=1)
curName2=rownames(curName2)
totCol=dim(curName2)
if (is.null(totCol)) { # ONLY ONLY FOR IL4. if you use it for other then result will be wrong
   # curName2=NULL;
}

curName4= read.table( paste(  myData,"/",datafilesDEG[2] , sep=""), header=T, row.names=1)
curName4=rownames(curName4)

curName6= read.table( paste(  myData,"/",datafilesDEG[3] , sep=""), header=T, row.names=1)
curName6=rownames(curName6)

curName12= read.table( paste(  myData,"/",datafilesDEG[4] , sep=""), header=T, row.names=1)
curName12=rownames(curName12)

curName24= read.table( paste(  myData,"/",datafilesDEG[5] , sep=""), header=T, row.names=1)
curName24=rownames(curName24)

finalName=union(curName2,curName4)
finalName=union(finalName,curName6)
finalName=union(finalName,curName12)
finalName=union(finalName,curName24)


return (finalName);
}


getUniqueGeneNames <- function(datafilesDEG) {

curName2= read.table( paste(  myData,"/",datafilesDEG[1] , sep=""), header=T, row.names=1)
totRow=nrow(curName2)
totCol=ncol(curName2)
if(totRow==0 || totCol==1)
{
	curName2 = NULL
}else
{
	curName2=rownames(curName2)
}

curName4= read.table( paste(  myData,"/",datafilesDEG[2] , sep=""), header=T, row.names=1)
totRow=nrow(curName4)
totCol=ncol(curName4)
if(totRow==0 || totCol==1)
{
	curName4 = NULL
}else
{
	curName4=rownames(curName4)
}

curName6= read.table( paste(  myData,"/",datafilesDEG[3] , sep=""), header=T, row.names=1)
totRow=nrow(curName6)
totCol=ncol(curName6)
if(totRow==0 || totCol==1)
{
	curName6 = NULL
}else
{
	curName6=rownames(curName6)
}
curName12= read.table( paste(  myData,"/",datafilesDEG[4] , sep=""), header=T, row.names=1)
totRow=nrow(curName12)
totCol=ncol(curName12)
if(totRow==0 || totCol==1)
{
	curName12 = NULL
}else
{
	curName12=rownames(curName12)
}

curName24= read.table( paste(  myData,"/",datafilesDEG[5] , sep=""), header=T, row.names=1)
totRow=nrow(curName24)
totCol=ncol(curName24)
if(totRow==0 || totCol==1)
{
	curName24 = NULL
}else
{
	curName24=rownames(curName24)
}

finalName=union(curName2,curName4)
finalName=union(finalName,curName6)
finalName=union(finalName,curName12)
finalName=union(finalName,curName24)


return (finalName);
}	


