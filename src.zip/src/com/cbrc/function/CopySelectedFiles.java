/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cbrc.function;

import com.cbrc.common.CommonFunction;
import com.cbrc.folderoperation.FolderOperations;
import java.util.Vector;



/**
 *
 * @author alamt
 */
public class CopySelectedFiles {
    
    String fnmFname;
    String extension;
    String fnmSourceDir;
    String fnmDestinationDir;

    public CopySelectedFiles(String fnmFname, String extension, String fnmSourceDir, String fnmDestinationDir) {
        this.fnmFname = fnmFname;
        this.extension = extension;
        this.fnmSourceDir = fnmSourceDir;
        this.fnmDestinationDir = fnmDestinationDir;
    }


    
    void doProcessing()
    {
        
        Vector<String> vectAllFileName = CommonFunction.readlinesOfAfile(this.fnmFname);
        
        FolderOperations.create_new_folder(this.fnmDestinationDir);
        
        String curFname, curFnameFullpath, curDestFullPath;
        for( int i=0 ; i<vectAllFileName.size() ;i++){
            
            curFname = vectAllFileName.get(i) + this.extension;
            curFnameFullpath = this.fnmSourceDir+"/" + curFname  ;
            
            curDestFullPath = this.fnmDestinationDir + "/" + curFname;
            
            if( FolderOperations.isFileExistInFolder(curFnameFullpath)){
            
                FolderOperations.copy_paste_file(curFnameFullpath, curDestFullPath);
        
            }else
            {
                System.out.print("NOT FOUND : " + curFnameFullpath);
            }
        }
    }
    
    public static void main(String[] args) {

        CopySelectedFiles obj = new CopySelectedFiles( args[0], args[1] , args[2] , args[3]);
        
        
        
        
        obj.doProcessing();
        
    }
    
    
}
