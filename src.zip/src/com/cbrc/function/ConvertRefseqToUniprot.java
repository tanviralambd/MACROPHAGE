package com.cbrc.function;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ConvertRefseqToUniprot {



	String fnmInput;
	String fnmMappingRefseqUniprot;
	String fnmOutput;


	LinkedHashMap<String, Set<String>> lhm_ref_uni = new  LinkedHashMap<String, Set<String>>();

	LinkedHashMap<String, Set<String>> lhm_RNA_refseq = new  LinkedHashMap<String, Set<String>>();








	public ConvertRefseqToUniprot(String fnmInput,
			String fnmMappingRefseqUniprot, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmMappingRefseqUniprot = fnmMappingRefseqUniprot;
		this.fnmOutput = fnmOutput;
	}




	void loadFiles()
	{

		lhm_ref_uni = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(this.fnmMappingRefseqUniprot, 0, 1);

		lhm_RNA_refseq = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated(this.fnmInput, 0, 1);



	}




	void writeMapping()
	{
		StringBuffer bufRes = new StringBuffer();
		String tmp[];

		Set set = lhm_RNA_refseq.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry) itr.next();

			String rnaid = (String) me.getKey();
			Set<String> refseqSet= (Set<String>)me.getValue();

			// Refseq --> Uniprot


			if(refseqSet.size() > 0)
			{


				String[] arr = (String[]) refseqSet.toArray(new String[refseqSet.size()]);
				int setSize = arr.length;
				Set<String> setUni = new LinkedHashSet<String>();
				String refseqWithoutSerial;
				for(int c=0; c < setSize;c++)
				{

					if( arr[c].contains("#") ){
						refseqWithoutSerial = arr[c].substring(0,  arr[c].indexOf('#'));
					}else
					{
						refseqWithoutSerial = arr[c];
					}
					
					
					
					
					if(lhm_ref_uni.containsKey( refseqWithoutSerial ))
					{
						setUni.addAll( lhm_ref_uni.get(  refseqWithoutSerial  ) );  
					}


				} 
				
				//
				
				bufRes.append( rnaid + "\t" );


				String[] arrUni = (String[]) setUni.toArray(new String[setUni.size()]);
				int setSizeUni = arrUni.length;
				for(int un=0; un < setSizeUni; un++)
				{
					if(un==setSizeUni-1)
						bufRes.append( arrUni[un] + "\n");

					else
						bufRes.append(arrUni[un]+ ConstantValue.SEPERATOR_LIST);

				} 



			}

		}


		CommonFunction.writeContentToFile(this.fnmOutput, bufRes+"");

	}


	void doProcessing()
	{
		loadFiles();
		writeMapping();

	}


	public static void main(String[] args) {

				ConvertRefseqToUniprot obj = new ConvertRefseqToUniprot(args[0], args[1], args[2]);

//		ConvertRefseqToUniprot obj = new ConvertRefseqToUniprot("NSvsIL413.allTime.withoutVSwithMtb.coExpList.0.70", 
//				"refgeneNM_swissprot_mm9_download.tab.mapping", "NSvsIL413.allTime.withoutVSwithMtb.coExpList.0.70.uniprot");

		obj.doProcessing();

	}


}
