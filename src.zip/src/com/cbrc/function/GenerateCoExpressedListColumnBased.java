package com.cbrc.function;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class GenerateCoExpressedListColumnBased {

	
	String fnmMatrix;
	String fnmMatrixRownames;
	String fnmMatrixColnames;
	String fnmOutList;
	double thrCoExpression;
	
	Vector<String> vectAll, vectAllRow, vectAllCol;
	// matrix : Row:Refseq , Col:Gencode
	
	void findCoExpressedRefseq()
	{
		String tmp[];
		tmp = ConstantValue.patCSV.split(vectAll.get(0));
		
		int totRow = vectAll.size();
		int totCol = tmp.length;
		
		
		String expressedList[] = new String[totCol];
		for( int k=0 ; k<totCol ;k++)
		{
			expressedList[k] = new String();
		}
		
		System.out.println("Now checking thr");
		
		double expVal;
		
		for(int i=0 ; i< vectAll.size();i++)
		{
			tmp = ConstantValue.patCSV.split(vectAll.get(i));
			
			for(int j=0 ; j< tmp.length ;j++)
			{
				expVal = Double.parseDouble(tmp[j]);
				
				if( expVal >= this.thrCoExpression)
				{
					expressedList[j] = expressedList[j] + vectAllRow.get(i)  + ";"  ;
				}
				
			}
			
			
		}
		
		
		System.out.println("Now Writing");
		
		StringBuffer resBuf = new StringBuffer();
		
		for(int j=0 ; j< vectAllCol.size() ;j++)
		{
			
			resBuf.append( vectAllCol.get(j) + "\t" +
					expressedList[j] + "\n");
		}
		
		CommonFunction.writeContentToFile(this.fnmOutList, resBuf+"");
		
	}
	
	
	void loadMatrix()
	{
		
		System.out.println("Start Loading matrix...");
		
		vectAll = CommonFunction.readlinesOfAfile(this.fnmMatrix);
		vectAllRow = CommonFunction.readlinesOfAfile(this.fnmMatrixRownames);
		vectAllCol = CommonFunction.readlinesOfAfile(this.fnmMatrixColnames);
		
		System.out.println("Loading done...");
	}
	
	void doProcessing()
	{
		
		
		loadMatrix();
		findCoExpressedRefseq();
		
		
	}
	
	
	public static void main(String[] args) {
		
		
		GenerateCoExpressedListColumnBased obj = new GenerateCoExpressedListColumnBased(args[0], args[1], args[2], args[3], 
				Double.parseDouble(args[4]) );
		
		
		
		obj.doProcessing();
		
	}






	public GenerateCoExpressedListColumnBased(String fnmMatrix, String fnmMatrixRownames,
			String fnmMatrixColnames, String fnmOutList, double thrCoExpression) {
		super();
		this.fnmMatrix = fnmMatrix;
		this.fnmMatrixRownames = fnmMatrixRownames;
		this.fnmMatrixColnames = fnmMatrixColnames;
		this.fnmOutList = fnmOutList;
		this.thrCoExpression = thrCoExpression;
	}
	
	
	
}
