

package com.cbrc.function;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class GenerateCoExpressedListRowBased {

	
	String fnmMatrix;
	String fnmMatrixRownames;
	String fnmMatrixColnames;
	String fnmOutList;
	double thrCoExpression;
	
	Vector<String> vectAll, vectAllRow, vectAllCol;
	// matrix : Row:Refseq , Col:Gencode
	
	void findCoExpressedRefseq()
	{
		String tmp[];
		tmp = ConstantValue.patCSV.split(vectAll.get(0));
		
		int totRow = vectAll.size();
//		int totCol = tmp.length;
		
		
		String expressedList[] = new String[totRow];
		for( int k=0 ; k<totRow ;k++)
		{
			expressedList[k] = new String();
		}
		
		System.out.println("Now checking thr");
		
		double expVal;
		
		for(int i=0 ; i< vectAllRow.size();i++)
		{
			tmp = ConstantValue.patCSV.split(vectAll.get(i));
			
			for(int j=0 ; j< tmp.length ;j++)
			{
				expVal = Double.parseDouble(tmp[j]);
				
				if( expVal >= this.thrCoExpression)
				{
					expressedList[i] = expressedList[i] + vectAllCol.get(j)  + ";"  ;
				}
				
			}
			
			
		}
		
		
		System.out.println("Now Writing");
		
		StringBuffer resBuf = new StringBuffer();
		
		for(int i=0 ; i< vectAllRow.size() ; i++)
		{
			
			resBuf.append( vectAllRow.get(i) + "\t" +
					expressedList[i] + "\n");
		}
		
		CommonFunction.writeContentToFile(this.fnmOutList, resBuf+"");
		
	}
	
	
	void loadMatrix()
	{
		
		System.out.println("Start Loading matrix...");
		
		
		vectAllRow = CommonFunction.readlinesOfAfile(this.fnmMatrixRownames);
		System.out.println("OUtput will have " + vectAllRow.size() + " rows");
		
		vectAllCol = CommonFunction.readlinesOfAfile(this.fnmMatrixColnames);
		System.out.println("OUtput will have " + vectAllCol.size() + " columnss");
		
		vectAll = CommonFunction.readlinesOfAfile(this.fnmMatrix);
		
		System.out.println("Loading done...");
	}
	
	void doProcessing()
	{
		
		
		loadMatrix();
		findCoExpressedRefseq();
		
		
	}
	
	
	public GenerateCoExpressedListRowBased(String fnmMatrix, String fnmMatrixRownames,
			String fnmMatrixColnames, String fnmOutList, double thrCoExpression) {
		super();
		this.fnmMatrix = fnmMatrix;
		this.fnmMatrixRownames = fnmMatrixRownames;
		this.fnmMatrixColnames = fnmMatrixColnames;
		this.fnmOutList = fnmOutList;
		this.thrCoExpression = thrCoExpression;
	}

	
	
	public static void main(String[] args) {
		
		
		GenerateCoExpressedListRowBased obj = new GenerateCoExpressedListRowBased(args[0], args[1], args[2], args[3], 
				Double.parseDouble(args[4]) );
		
		
		
		obj.doProcessing();
		
	}

	
	
	
}

