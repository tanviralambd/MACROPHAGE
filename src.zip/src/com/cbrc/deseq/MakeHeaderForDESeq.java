package com.cbrc.deseq;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MakeHeaderForDESeq {

	String finMatrix;
	String foutHeadDESeq;
	
	
	
	void doProcessing()
	{
		int len;
		String firstLine;
		StringBuffer bufResult = new StringBuffer();
		String tmp[], tmpUnderScore[];

		Vector<String > vectStr = CommonFunction.readlinesOfAfile(this.finMatrix);
		firstLine = vectStr.get(0);
		tmp = ConstantValue.patWhiteSpace.split(firstLine);
		
		for(int i= 0; i< tmp.length;i++)
		{
			tmpUnderScore = ConstantValue.patUnderscore.split( tmp[i] );
			len = tmpUnderScore.length;
			
			bufResult.append(tmpUnderScore[len-1]+"\n");
//			System.out.println(tmpUnderScore[len-1]);
			
		}
		
		CommonFunction.writeContentToFile(this.foutHeadDESeq, bufResult+"");
		
		
	}
	
	void doProcessing_ByMatrix()
	{
		int len;
		String firstLine;
		StringBuffer bufResult = new StringBuffer();
		String tmp[], tmpUnderScore[];

		Vector<String > vectStr = CommonFunction.readlinesOfAfile(this.finMatrix);
		
		
		for(int i=0; i<vectStr.size();i++)
		{
			tmpUnderScore = ConstantValue.patUnderscore.split(vectStr.get(i) );
			len = tmpUnderScore.length;
			
			bufResult.append(tmpUnderScore[len-1]+"\n");
			System.out.println(tmpUnderScore[len-1]);
			
		}
		
		CommonFunction.writeContentToFile(this.foutHeadDESeq, bufResult+"");
		
		
	}
	
	
	
	public MakeHeaderForDESeq(String fin, String fout) {
		this.finMatrix = fin;
		this.foutHeadDESeq = fout;
	}
	
	
	public static void main(String[] args) {
		
		MakeHeaderForDESeq obj = new  MakeHeaderForDESeq(args[0], args[1]);
		
//		MakeHeaderForDESeq obj = new  MakeHeaderForDESeq("NFvsIL4.matrix.4.4.withoutMtb", "NFvsIL4.matrix.header.4.4.withoutMtb.DESEQ");
		obj.doProcessing();
	}
	
	
}
