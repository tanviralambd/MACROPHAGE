package com.cbrc.deseq;



import java.util.LinkedHashMap;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;


/*
 *  1. Take only entry for genes common in two files
 *  2. Change the header; Add suffix 
 */
public class Combine_2file {

	
	String fin1;
	String fin2;
	String fout;
	String suffix_1st;
	String suffix_2nd;
	
	void doProcessing(String f1,String f2, String fO , String pre1, String pre2)
	{
		
		this.fin1 = f1;
		this.fin2 = f2;
		this.fout = fO;
		this.suffix_1st= pre1;
		this.suffix_2nd= pre2;
		
		/*
		 *  Read two files
		 */
		
		Vector<String> vectFirst  = CommonFunction.readlinesOfAfile(this.fin1);
		Vector<String> vectSecond = CommonFunction.readlinesOfAfile(this.fin2);
		
		
		String tmp[];
		StringBuffer bufResult = new StringBuffer();
		
		/*
		 *  Manage Header
		 */
//		bufResult.append("TrxID\t");
		
		String head1= vectFirst.get(0);
		tmp = ConstantValue.patTab.split(head1);
		for(int i=1; i<tmp.length ;i++)
		{
			bufResult.append(tmp[i]+"_"+suffix_1st + "\t" ) ;
		}
		
		
		String head2= vectSecond.get(0);
		tmp = ConstantValue.patTab.split(head2);
		for(int i=1; i<tmp.length ;i++)
		{
			if(i==tmp.length -1)
				bufResult.append(tmp[i]+"_"+suffix_2nd  ) ;
			else
				bufResult.append(tmp[i]+"_"+suffix_2nd + "\t" ) ;
		}
		bufResult.append("\n");
		
		
		
		/*
		 *  Manage Data; Take genes common in both files.
		 */
		
		String geneID;
		LinkedHashMap<String, String> lhm_Geneid_val_Firstfile = new LinkedHashMap<String, String>();
		StringBuffer bufCurLine= new StringBuffer();
		
		for(int i=1; i<vectFirst.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectFirst.get(i));
			
			bufCurLine = new StringBuffer();
			geneID = tmp[0];
			for(int j=1; j<tmp.length ;j++)
			{
				bufCurLine.append(tmp[j]+"\t");
			}
			
			lhm_Geneid_val_Firstfile.put(geneID, (bufCurLine+"").trim() );
			
		}
		
		
		
		for(int i=1; i<vectSecond.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectSecond.get(i));
			
			bufCurLine = new StringBuffer();
			geneID = tmp[0];
			for(int j=1; j<tmp.length ;j++)
			{
				if(j==tmp.length-1)
					bufCurLine.append(tmp[j]);
				else
					bufCurLine.append(tmp[j] +"\t");
			}
			
			if(lhm_Geneid_val_Firstfile.containsKey(geneID))
			{
				bufResult.append(geneID+"\t" + lhm_Geneid_val_Firstfile.get(geneID) + "\t"+ bufCurLine + "\n");
			}
		}
		
		CommonFunction.writeContentToFile(this.fout, bufResult+"");
		
	}
	
	
	
	public static void main(String[] args) {
		
		Combine_2file obj = new Combine_2file();
		obj.doProcessing(args[0], args[1], args[2], args[3], args[4]);
//		obj.doProcessing("mouse_macrophage_TB_infection_non-stimulated.counts.csv.matrix.0.24", "mouse_macrophage_TB_infection_IL4-IL13.counts.csv.matrix.0.24", "combined.matrix" , "First","Second");  
		
	}
	
	
}
