package com.cbrc.nearbyGene;

import java.util.LinkedHashMap;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SubselectGenes {

	String fnmId;
	String fnmAll;
	String fnmOut;
	
	LinkedHashMap<String, String> lhm_Id_Id = new LinkedHashMap<String, String>();
	
	void loadID()
	{
		lhm_Id_Id = new LinkedHashMap<String, String>();
		String tmp[];
		Vector<String> vect = CommonFunction.readlinesOfAfile(this.fnmId);
		for(int i=0; i<vect.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vect.get(i));
			lhm_Id_Id.put(tmp[0], tmp[0]);
		}
		
	}
	
	
	void findMatch()
	{
		
		String tmp[];
		String curLine;
		Vector<String> vectBed = CommonFunction.readlinesOfAfile(this.fnmAll);
		
		StringBuffer resBuffer = new StringBuffer();
		
		for(int i=0; i<vectBed.size();i++)
		{
			curLine = vectBed.get(i);
			
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			if(lhm_Id_Id.containsKey(tmp[3]))
			{
				resBuffer.append(curLine + "\n");
			}
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, resBuffer+"");
		
	}
	
	void doProcessing()
	{
		loadID();
		findMatch();
	}
	

	
	
	public SubselectGenes(String fnmId, String fnmAll, String fnmOut) {
		super();
		this.fnmId = fnmId;
		this.fnmAll = fnmAll;
		this.fnmOut = fnmOut;
	}


	public static void main(String[] args) {
		
//		SubselectGenes obj = new SubselectGenes("selectedIFNG.id", "finalLncRNA.bed", "selectedIFNG.id.bed");
//		SubselectGenes obj = new SubselectGenes("selectedIL413.id", "finalLncRNA.bed", "selectedIL413.id.bed");
		
		SubselectGenes obj = new SubselectGenes(args[0], args[1], args[2]  ) ;
		
		obj.doProcessing();
	}
	
}
