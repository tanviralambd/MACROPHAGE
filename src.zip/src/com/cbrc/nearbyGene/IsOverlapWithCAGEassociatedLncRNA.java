package com.cbrc.nearbyGene;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;





import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class IsOverlapWithCAGEassociatedLncRNA {

	
	String fnmCage;
	String fnmRefseqOverlap;
	String fnmOut;
	
	

		
	public IsOverlapWithCAGEassociatedLncRNA(String fnmCage,
			String fnmRefseqOverlap, String fnmOut) {
		super();
		this.fnmCage = fnmCage;
		this.fnmRefseqOverlap = fnmRefseqOverlap;
		this.fnmOut = fnmOut;
	}


	LinkedHashMap<String, String> lhm_cageDistance_details = new LinkedHashMap<String, String>();
	
	LinkedHashMap<String, String> lhm_refseqOverlap_details = new LinkedHashMap<String, String>();
	
	
	
	void loadCAGElncRNARefseq()
	{
		lhm_cageDistance_details = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fnmCage, 0);
		
		
	}
	
	void loadRefseqOverlap()
	{
		lhm_refseqOverlap_details = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fnmRefseqOverlap, 0);
				
	}
	
	
	
	Set<String> listElementsAsSet(String fnmDetails)
	{
		
		Set<String> setElem = new LinkedHashSet<String>();
		
		int len = fnmDetails.length();
		
		if(fnmDetails.charAt(0) == '[')
		{
			fnmDetails = fnmDetails.substring(1, len);
		}
		
		String tmp[];
		tmp = ConstantValue.patCSV.split(fnmDetails);
		
		for( int i=0 ; i < tmp.length  ;i++)
		{
			setElem.add( tmp[i] );
		}
		
		
		return setElem;
	}
	
	
	
	
	void findListOfOverlapp_CAGE_LncRNA_Refseq()
	{
		int intersectionSize;
		int found=0, notFound=0;
		String tmp[] , tmpCSV[];
		
		String cageNearestLncRNA,cageNearestRefseq;
		Set<String> cageNearestLncRNASet,cageNearestRefseqSet;
		
		
		String refseqOverlapLncRNA, refseqOverlapDirection;
		Set<String> refseqOverlapLncRNASet, refseqOverlapDirectionSet;
		
		
		
		StringBuffer bufRes = new StringBuffer();

		
		Set set = lhm_cageDistance_details.entrySet();
        System.out.println("Total Unique entry:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            String id = (String)me.getKey();
            String cageInfo = (String) me.getValue();
            
            
            tmp = ConstantValue.patTab.split(cageInfo);
            
            cageNearestLncRNA = tmp[1];
            cageNearestRefseq = tmp[2];
            
            
            cageNearestLncRNASet = listElementsAsSet(cageNearestLncRNA);
            
            
            if(  lhm_refseqOverlap_details.containsKey( cageNearestRefseq))
            {
            	
            	found++;
            	
            	String refseqInfo = lhm_refseqOverlap_details.get(cageNearestRefseq);
            	tmp = ConstantValue.patTab.split( refseqInfo );
            	
            	refseqOverlapLncRNA    = tmp[1];
            	refseqOverlapDirection = tmp[2];
            	
            	
            	refseqOverlapLncRNASet = listElementsAsSet(refseqOverlapLncRNA);
            	
            	Set intersection = new HashSet(cageNearestLncRNASet);
            	intersection.retainAll(refseqOverlapLncRNASet);
            	intersectionSize = intersection.size();
            	
            	if(intersectionSize>0)
            		bufRes.append( cageInfo + "\t" + "Overlap" + "\n");
            	else
            		bufRes.append( cageInfo + "\t" + "NoOverlap" + "\n");
            	
            	
            }else
            {
            	
            	bufRes.append( cageInfo + "\t" + "NoOverlap" + "\n");
            	notFound++;
            }
            
            
           
        }
		
        System.out.println("Found:" + found + " NOTfound: " + notFound);
		
		CommonFunction.writeContentToFile(this.fnmOut, bufRes+"");
	}


	void doProcessing()
	{
		
		loadCAGElncRNARefseq();
		loadRefseqOverlap();
		
		findListOfOverlapp_CAGE_LncRNA_Refseq();
		
	}
	

	public static void main(String[] args) {
	
		
		IsOverlapWithCAGEassociatedLncRNA obj = new IsOverlapWithCAGEassociatedLncRNA(args[0], args[1], args[2]) ;
		
		
//		IsOverlapWithCAGEassociatedLncRNA obj = new IsOverlapWithCAGEassociatedLncRNA("manualTableMtb.txt", "finalLncRNA.bed.sorted.bed.overlap.information", "manualTableMtb.txt.isoverlap") ;
		
		
		
		obj.doProcessing();
		
		
	}
	
	
	
}
