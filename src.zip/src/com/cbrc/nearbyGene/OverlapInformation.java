package com.cbrc.nearbyGene;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class OverlapInformation {


	String fnmInput;
	String fnmOutput;



	LinkedHashMap<String, Set<String>>  lhm_name_setName = new LinkedHashMap<String, Set<String>>();

	LinkedHashMap<String, Vector<String>>  lhm_name_setDistance = new LinkedHashMap<String, Vector<String>>();

	LinkedHashMap<String, Vector<String>>  lhm_name_setDirection = new LinkedHashMap<String, Vector<String>>();






	Vector<String> vectAll = new Vector<String>();
	void readLines()

	{
		vectAll = CommonFunction.readlinesOfAfile(this.fnmInput);

	}

	
	void loadIntoHashMap(String keyName,  String valueName,   String direction ) // String distance ,
	{
		

			/* 
			 *  keyName --> Name1;Name1
			 */
			if(lhm_name_setName.containsKey(keyName))
			{
				lhm_name_setName.get(keyName).add(valueName);
			}else
			{
				Set tmSet = new LinkedHashSet<String>();
				tmSet.add( valueName);
				lhm_name_setName.put(keyName, tmSet);
			}

			/* 
			 *  Name2 --> Distance1;Distance1
			 */
//			if(lhm_name_setDistance.containsKey(name2))
//			{
//				lhm_name_setDistance.get(name2).add(distance);
//			}else
//			{
//				Vector<String> tmVec = new Vector<String>();
//				tmVec.add( distance);
//				lhm_name_setDistance.put(name2, tmVec);
//			}
			

			/* 
			 *  Name2 --> Direction1;Direction1
			 */
			if(lhm_name_setDirection.containsKey(keyName))
			{
				lhm_name_setDirection.get(keyName).add(direction);
			}else
			{
				Vector tmVec = new Vector<String>();
				tmVec.add( direction);
				lhm_name_setDirection.put(keyName, tmVec);
			}



		

		
	}
	

	void parseEachline()
	{

		int secondTermStartIndex;
		String tmp[];

		String name1, name2;
		String strand1,strand2;
		String direction;
		String distance;


		StringBuffer resBuf = new StringBuffer();

		for( int i=0 ; i<vectAll.size() ;i++)
		{

			tmp = ConstantValue.patTab.split(vectAll.get(i));

			name1= tmp[3];
			strand1 = tmp[5];

			int j;
			for(j=6; j< tmp.length ; j++)
			{
				if(tmp[j].startsWith("chr"))
					break;
			}
			secondTermStartIndex = j;

			// NM_001290504#13235  total 4992
			name2= tmp[j+3];

			// NM_001290504  total 4992
			name2 = name2.substring(0, name2.indexOf('#'));

			strand2 = tmp[j+5];


			if(strand1.equals(strand2))
				direction="S";
			else
				direction="AS";


//			distance = tmp[ tmp.length-1];



			loadIntoHashMap( name2,  name1,    direction );



			resBuf.append( name1 + "\t" + strand1 + "\t" + name2 + "\t" + strand2 +   "\t"  + direction + "\n");



		}



		CommonFunction.writeContentToFile(this.fnmOutput+".all", resBuf+ "");

	}



	void generateInformation()

	{
		StringBuffer resBuf = new StringBuffer();


		Set set = lhm_name_setName.entrySet();
		System.out.println("Total Unique entry:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String id = (String)me.getKey();


			Set setgeneName = (Set) me.getValue();
//			Vector setDistance = (Vector) lhm_name_setDistance.get(id);
			Vector setDirection = (Vector) lhm_name_setDirection.get(id);



			resBuf.append( id 
					+ "\t" +  setgeneName.toString()  
//					+ "\t" +  setDistance.toString() 
					+ "\t" +  setDirection.toString() +"\n") ;



		}


		CommonFunction.writeContentToFile(this.fnmOutput , resBuf+ "");
	}



	void doProcessing()
	{

		readLines();
		parseEachline();

		generateInformation();

	}





	public OverlapInformation(String fnmInput, String fnmOutput) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOutput = fnmOutput;
	}


	public static void main(String[] args) {


		//		OverlapInformation obj = new OverlapInformation( args[0] , args[1]);

		OverlapInformation obj = new OverlapInformation( "finalLncRNA.bed.sorted.bed.overlap" , "finalLncRNA.bed.sorted.bed.overlap.information" );

		obj.doProcessing();

	}


}
