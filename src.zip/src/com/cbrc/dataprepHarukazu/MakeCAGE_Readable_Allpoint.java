package com.cbrc.dataprepHarukazu;

import java.util.Vector;
import java.util.regex.Matcher;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/*
 *  1. Make the heade readable
 *  
 */
public class MakeCAGE_Readable_Allpoint {



	String finCage="";
	String fout="";


	String readableHeader;
	String newLabel="";



	void makeTimePointsReadable() { 


		
		Matcher m;

		int start_Exp_0based=6;


		StringBuffer bufResult = new StringBuffer();
		StringBuffer bufHead = new StringBuffer();
		Vector<String> vectOne = CommonFunction.readlinesOfAfile(this.finCage);

		Vector<String> vectHeaderDataPoint = new Vector<String>();
		Vector<String> vectHeaderDataPointReadable = new Vector<String>();

		Vector<String> vectLibSize = new Vector<String>();
		int totDataPoint,totLibsizeTimePoint;

		String cageID;
		String tmp[],cageSplit[];
		String colNameUnReadable, newColName;
		int replicaNo;
		String finalColName=""  , curMatch;

		// 1st line - handle header
		String headerLine = vectOne.get(0);
		String tmpHeader[] = ConstantValue.patTabSingle.split(headerLine);
		for(int v=start_Exp_0based; v<tmpHeader.length;v++)
		{
			vectHeaderDataPoint.add(tmpHeader[v] ) ;
		}
		totDataPoint = vectHeaderDataPoint.size();
		System.out.println("Total dataPoint in this file: "+ totDataPoint);

		bufHead.append("CAGEID");
		for(int i=0; i<vectHeaderDataPoint.size();i++)
		{
			colNameUnReadable = vectHeaderDataPoint.get(i) ;
			newColName= getNewHeader(colNameUnReadable);

			m=  ConstantValue.patReplicaFantom.matcher(colNameUnReadable) ;
			if (m.find()) {
				curMatch = m.group();
				int indexDot = curMatch.indexOf('.');
				replicaNo = Integer.parseInt(curMatch.substring(1, indexDot));
				finalColName = newColName+"_"+replicaNo ;
				bufHead.append( "\t" + finalColName);
				
				vectHeaderDataPointReadable.add(finalColName);
			}
		}



		// 2nd line - Library Size
		String libsizeLine = vectOne.get(1);
		String tmpLibsize[] = ConstantValue.patTabSingle.split(libsizeLine);
		for(int v=start_Exp_0based; v<tmpLibsize.length;v++)
		{
			vectLibSize.add(tmpLibsize[v] ) ;
		}
		totLibsizeTimePoint = vectLibSize.size();
		System.out.println("Total libSize Entry in this file: "+ totLibsizeTimePoint);
		System.out.println("Total readable Entry in this file: "+ vectHeaderDataPointReadable.size());

		StringBuffer bufLlibSize = new StringBuffer();
		for(int d=0;d<totDataPoint;d++)
		{
			if(d==totDataPoint-1)
				bufLlibSize.append(vectHeaderDataPointReadable.get(d));
			else
				bufLlibSize.append(vectHeaderDataPointReadable.get(d)+"\t");

		}
		bufLlibSize.append("\n");
		for(int d=0;d<totLibsizeTimePoint;d++)
		{
			if(d==totLibsizeTimePoint-1)
				bufLlibSize.append(vectLibSize.get(d));
			else
				bufLlibSize.append(vectLibSize.get(d)+"\t");
		}
		CommonFunction.writeContentToFile( this.fout + ".libsize", bufLlibSize+"");
		
		
		
		// 3rd - last Line
		for (  int i=2; i<vectOne.size();i++) {
			
			tmp = ConstantValue.patTabSingle.split(vectOne.get(i));

			cageID = tmp[0];
			
			bufResult.append(cageID);

			for(int j=start_Exp_0based ;  j<tmp.length;j++)
			{

				bufResult.append( "\t" +tmp[j]);
			}

			bufResult.append("\n");


		}

		System.out.println("Total number of DPI in this file: "+ (vectOne.size()-2 ));

		/* 
		 *  Write result
		 */
		CommonFunction.writeContentToFile(this.fout, bufHead + "\n" + bufResult+"");

		

	

	}



	String getNewHeader (String prevHeader)
	{

		boolean found=false;
		Matcher m;

		// 0 hr
		m=  ConstantValue.pat_without_0hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[0];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_0hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[0];
			found = true;
			//			return found;
		}

		// 2 hr
		m=  ConstantValue.pat_without_2hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[1];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_2hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[1];
			found = true;
			//			return found;
		}



		// 4 hr
		m=  ConstantValue.pat_without_4hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[2];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_4hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[2];
			found = true;
			//			return found;
		}




		// 6 hr
		m=  ConstantValue.pat_without_6hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[3];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_6hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[3];
			found = true;
			//			return found;
		}




		// 12 hr
		m=  ConstantValue.pat_without_12hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[4];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_12hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[4];
			found = true;
			//			return found;
		}




		// 24 hr
		m=  ConstantValue.pat_without_24hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[5];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_24hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[5];
			found = true;
			//			return found;
		}




		// 28 hr
		m=  ConstantValue.pat_without_28hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[6];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_28hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[6];
			found = true;
			//			return found;
		}




		// 36 hr
		m=  ConstantValue.pat_without_36hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[7];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_36hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[7];
			found = true;
			//			return found;
		}




		// 48 hr
		m=  ConstantValue.pat_without_48hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[8];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_48hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[8];
			found = true;
			//			return found;
		}




		// 72 hr
		m=  ConstantValue.pat_without_72hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[9];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_72hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[9];
			found = true;
			//			return found;
		}




		// 120 hr
		m=  ConstantValue.pat_without_120hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[10];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_120hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[10];
			found = true;
			//			return found;
		}


		return newLabel;

	}


	void init(String fnmInput,  String extOut)
	{
		this.finCage = fnmInput;
		
		this.fout= this.finCage+ extOut;
	}

	void doProcessing()
	{
		makeTimePointsReadable();
	}


	public static void main(String[] args) {
		MakeCAGE_Readable_Allpoint obj = new MakeCAGE_Readable_Allpoint();
		
		obj.init(args[0], args[1]);
//		obj.init("mouse_macrophage_TB_infection_non-stimulated.counts1.csv", ".readable.cage");
		obj.doProcessing();
	}
}
