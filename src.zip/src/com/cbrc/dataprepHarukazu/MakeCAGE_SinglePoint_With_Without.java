package com.cbrc.dataprepHarukazu;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MakeCAGE_SinglePoint_With_Without {


	String fin;
	String finLibsize;

	String suffWith;
	String suffWithout;


	void handleCage(String fnm ,  String sufWith, String sufWihtout)
	{


		Vector<String> vectMat = CommonFunction.readlinesOfAfile( fnm);



		LinkedHashSet<Integer> setWith_columnIdx = new LinkedHashSet<Integer>();
		LinkedHashSet<Integer> setWithOut_columnIdx = new LinkedHashSet<Integer>();

		LinkedHashMap<Integer, Integer> lhmWithout_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();
		LinkedHashMap<Integer, Integer> lhmWith_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();

		String curColName="" ,curReplicaName="";


		/*
		 *  Manage Header/1st Line
		 */
		int maxNoReplica_With=0     ;
		int maxNoReplica_Without=0  ;
		String firstLine = vectMat.get(0);
		String tmp[];
		tmp = ConstantValue.patWhiteSpace.split(firstLine);

		for(int i=0; i<tmp.length;i++)
		{
			curColName = tmp[i];


			if(tmp[i].startsWith("With_"))
			{
				setWith_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWith_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);

				if( Integer.parseInt(curReplicaName) > maxNoReplica_With)
				{
					maxNoReplica_With = Integer.parseInt(curReplicaName);
				}

			}else if ( tmp[i].startsWith("Without_"))
			{
				setWithOut_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWithout_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);
				if( Integer.parseInt(curReplicaName) > maxNoReplica_Without)
				{
					maxNoReplica_Without = Integer.parseInt(curReplicaName);
				}

			}
		}

		//		int totReplica_With     = lhmWith_replicaNo_ColumnIdx.size();
		//		int totReplica_Without  = lhmWithout_replicaNo_ColumnIdx.size();


		/*
		 *  Rewrite 1st to Last Line
		 */
		StringBuffer bufWith = new StringBuffer();
		StringBuffer bufWithout = new StringBuffer();
		String trxName;
		int selectedColumn;

		for(int i=0; i<vectMat.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectMat.get(i));
			trxName = tmp[0];
			bufWith.append(trxName);
			bufWithout.append(trxName);



			//			Set set = lhmWith_replicaNo_ColumnIdx.entrySet();
			//
			//			Iterator itr = set.iterator();
			//			while(itr.hasNext()){
			//
			//
			//				Map.Entry me = (Map.Entry) itr.next();
			//				int id = (Integer)me.getKey();
			//				int index = (Integer) me.getValue();
			//				bufWith.append("\t" + tmp[ index  ]);
			//
			//			}

			for(int k=1; k<=maxNoReplica_With ;k++)
			{
				if(lhmWith_replicaNo_ColumnIdx.containsKey(k))
				{
					selectedColumn = lhmWith_replicaNo_ColumnIdx.get(k) ; 
					bufWith.append("\t" + tmp[ selectedColumn  ]);
				}


			}


			for(int k=1; k<= maxNoReplica_Without ;k++)
			{
				if(lhmWithout_replicaNo_ColumnIdx.containsKey(k))
				{
					selectedColumn = lhmWithout_replicaNo_ColumnIdx.get(k) ; 
					bufWithout.append("\t" + tmp[ selectedColumn  ]);
				}
			}



			bufWith.append("\n");
			bufWithout.append("\n");


		}

		CommonFunction.writeContentToFile( fnm + this.suffWith     , bufWith+"");
		CommonFunction.writeContentToFile( fnm + this.suffWithout  , bufWithout+"");



	}

	void handleLibsize(String fnmLib, String sufWith, String sufWihtout)
	{

		Vector<String> vectMat = CommonFunction.readlinesOfAfile( fnmLib);


		//		
		//		LinkedHashSet<Integer> setWith_columnIdx = new LinkedHashSet<Integer>();
		//		LinkedHashSet<Integer> setWithOut_columnIdx = new LinkedHashSet<Integer>();

		LinkedHashMap<Integer, Integer> lhmWithout_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();
		LinkedHashMap<Integer, Integer> lhmWith_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();

		String curColName="" ,curReplicaName="";
		int maxNoReplica_With=0     ;
		int maxNoReplica_Without=0  ;

		/*
		 *  Manage Header/1st Line
		 */
		String firstLine = vectMat.get(0);
		String tmp[];
		tmp = ConstantValue.patWhiteSpace.split(firstLine);

		for(int i=0; i<tmp.length;i++)
		{
			curColName = tmp[i];


			if(tmp[i].startsWith("With_"))
			{
				//				setWith_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWith_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);

				if( Integer.parseInt(curReplicaName) > maxNoReplica_With)
				{
					maxNoReplica_With = Integer.parseInt(curReplicaName);
				}

			}else if ( tmp[i].startsWith("Without_"))
			{
				//				setWithOut_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWithout_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);

				if( Integer.parseInt(curReplicaName) > maxNoReplica_Without)
				{
					maxNoReplica_Without = Integer.parseInt(curReplicaName);
				}

			}
		}

		//		int totReplica_With     = lhmWith_replicaNo_ColumnIdx.size();
		//		int totReplica_Without  = lhmWithout_replicaNo_ColumnIdx.size();

		//		System.out.println( "For libwith: "+ totReplica_With  + " libWithout:" + totReplica_Without);

		/*
		 *  Rewrite 1st to Last Line
		 */
		StringBuffer bufWith = new StringBuffer();
		StringBuffer bufWithout = new StringBuffer();
		String trxName;
		int selectedColumn;

		for(int i=0; i<vectMat.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectMat.get(i));
			//			trxName = tmp[0];
			//			bufWith.append(trxName);
			//			bufWithout.append(trxName);

			for(int k=1; k<=maxNoReplica_With ;k++)
			{
				if(lhmWith_replicaNo_ColumnIdx.containsKey(k))
				{
					selectedColumn = lhmWith_replicaNo_ColumnIdx.get(k) ; 
					bufWith.append( tmp[ selectedColumn  ] + "\t"  );
				}
			}


			for(int k=1; k<=maxNoReplica_Without ;k++)
			{
				if(lhmWithout_replicaNo_ColumnIdx.containsKey(k))
				{
					selectedColumn = lhmWithout_replicaNo_ColumnIdx.get(k) ; 
					bufWithout.append(  tmp[ selectedColumn  ]  +  "\t"  ) ;
				}
			}



			bufWith.append("\n");
			bufWithout.append("\n");


		}

		CommonFunction.writeContentToFile(fnmLib+ this.suffWith     , bufWith+"");
		CommonFunction.writeContentToFile(fnmLib+ this.suffWithout  , bufWithout+"");


	}


	void doProcessingMakeSerialReplicate(String fnm , String fnmLib, String sufWith, String sufWihtout)
	{
		this.fin = fnm;
		this.finLibsize = fnmLib;
		this.suffWith = sufWith;
		this.suffWithout = sufWihtout;				


		handleCage( fnm ,   sufWith,  sufWihtout);

		handleLibsize( fnmLib ,   sufWith,  sufWihtout);


	}


	public static void main(String[] args) {

		MakeCAGE_SinglePoint_With_Without obj = new MakeCAGE_SinglePoint_With_Without();
				obj.doProcessingMakeSerialReplicate(args[0], args[1] , args[2] , args[3]);

//		obj.doProcessingMakeSerialReplicate("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage.28.28" ,"mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage.libsize.28.28", ".withMtb" , ".withoutMtb") ; 
	}



}
