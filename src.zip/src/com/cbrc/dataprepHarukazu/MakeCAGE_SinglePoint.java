package com.cbrc.dataprepHarukazu;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MakeCAGE_SinglePoint {

	Set setSlected_0basedColumn = new LinkedHashSet<Integer>();

	/*
	 *  1. Select only column within range
	 */
	void selectOnlyInRange() { 



		Vector<String > vectOne = CommonFunction.readlinesOfAfile(this.finCageAll);

		/*
		 *  First Line - Header
		 */
		String firstLine = vectOne.get(0);
		String tmp[] = ConstantValue.patTab.split(firstLine);
		String tmpRepNo[];
		String cageID;
		int totColumn = tmp.length; // CAGED |  values...
	
		int timePointsCount=0;
		int replicaNo,curTimpoint;
		String  colNameReadable ;

		StringBuffer bufHead = new StringBuffer();
		
		for(int i=0;i<tmp.length;i++)
		{
			if(i==0 ) {
				bufHead.append(tmp[i]);
				setSlected_0basedColumn.add(i);
			}else
			{
				colNameReadable = tmp[i];
				curTimpoint = Integer.parseInt(ConstantValue.patUnderscore.split(colNameReadable)[2] ) ;

				if  ( curTimpoint == startT   ){ 
					bufHead.append( "\t" + colNameReadable);
					setSlected_0basedColumn.add(i);
				}
			}
			timePointsCount++;

		}


	
	String readableHeader = bufHead.toString();
	readableHeader.trim();

	StringBuffer bufResult = new StringBuffer();
	bufResult.append(readableHeader+"\n");



	/*
	 *  2nd to last line
	 */
	// CLUSTERID |  TimePoints values...
	int startTimepoint_index0based=1;

	for(int i=1;i< vectOne.size();i++)
	{
		tmp = ConstantValue.patTab.split(vectOne.get(i)); 

		cageID = tmp[0];
		bufResult.append(cageID +"\t");

		for(int k=startTimepoint_index0based; k<tmp.length ;k++){
			if  ( setSlected_0basedColumn.contains(k) ){ 
				bufResult.append(tmp[k] +"\t");
			}

		}


		bufResult.append("\n");

	}

	CommonFunction.writeContentToFile(this.foutCageRange, bufResult+"");

}
void selectOnlyInRange_Libsize()
{


	

	Vector<String> vectLibFile = CommonFunction.readlinesOfAfile(this.finLibCageAll);
	StringBuffer bufResult = new StringBuffer();
	
	String curLine;
	String tmp[];
	
	for(int i=0;i<vectLibFile.size();i++)
	{
		curLine = vectLibFile.get(i) ;
		tmp = ConstantValue.patWhiteSpace.split(curLine);
		for(int j=0; j<tmp.length;j++)
		{
			if(setSlected_0basedColumn.contains(j+1))
			{
				bufResult.append(tmp[j] + "\t");
			}
		}
		
		bufResult.append( "\n");
		
	}
	
	CommonFunction.writeContentToFile(foutLibRange, bufResult+"");


}

void init(String f1, String fo , String startTime,  String finLibsizeUnreadable, String foutLibsizeReadable) {

	this.finCageAll =f1;
	this.foutCageRange = fo;
	this.startT = Integer.parseInt(startTime);

	this.finLibCageAll = finLibsizeUnreadable;
	this.foutLibRange = foutLibsizeReadable;
}


String finCageAll;
String foutCageRange;
int startT;


String finLibCageAll ;
String foutLibRange;


void doProcessing()
{
	selectOnlyInRange();
	selectOnlyInRange_Libsize();
}

public static void main(String[] args) {
	MakeCAGE_SinglePoint obj = new MakeCAGE_SinglePoint();
	
	obj.init(	args[0],	args[1],	args[2],	args[3],	args[4]); 
//	obj.init("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage" , "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage.24.24"   , "24",
//			"mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage.libsize" , "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.readable.cage.libsize.24.24");

	obj.doProcessing();
}

}
