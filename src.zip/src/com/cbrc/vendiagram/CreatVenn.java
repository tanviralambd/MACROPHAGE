package com.cbrc.vendiagram;




import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class CreatVenn {


	

	String fnmIfngmtb_unstimulated="IFNGmtb_Unstimulated.txt";
	String fnmIl413gmtb_unstimulated="IL413mtb_Unstimulated.txt";
	String fnmMtb_unstimulated="Mtb_Unstimulated.txt";
	String fnmOut;
	

	Vector<String>  vectIfng;
	Vector<String> vectIl413;
	Vector<String> vectMtbonly ;

	


	public CreatVenn(String fnmIfngmtb_unstimulated,
			String fnmIl413gmtb_unstimulated, String fnmMtb_unstimulated,
			String fnmOut) {
		super();
		this.fnmIfngmtb_unstimulated = fnmIfngmtb_unstimulated;
		this.fnmIl413gmtb_unstimulated = fnmIl413gmtb_unstimulated;
		this.fnmMtb_unstimulated = fnmMtb_unstimulated;
		this.fnmOut = fnmOut;
	}


	void doProcessing()
	{

		loadData();


		findCommon();
		
		
		

	}


	void loadData()
	{
		vectIfng = CommonFunction.readlinesOfAfile(this.fnmIfngmtb_unstimulated);
		vectIl413 = CommonFunction.readlinesOfAfile(this.fnmIl413gmtb_unstimulated);
		vectMtbonly = CommonFunction.readlinesOfAfile(this.fnmMtb_unstimulated);
		
		System.out.println("Total line in file: " + vectIfng.size());
		System.out.println("Total line in file: " + vectIl413.size());
		System.out.println("Total line in file: " + vectMtbonly.size());
		
		
		
	}

	void findCommon( )
	{

		

		Set<String> setInfg = new LinkedHashSet<String>();
		Set<String> setIL413 = new LinkedHashSet<String>();
		Set<String> setMtbonly = new LinkedHashSet<String>();


		String tmp[];
		double valueOfInterest;
		String curCluster;

		for(int i=0 ; i< vectIfng.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectIfng.get(i));

			curCluster = tmp[0];

			setInfg.add(curCluster);

		}

		// IL413
		for(int i=0 ; i< vectIl413.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectIl413.get(i));

			curCluster = tmp[0];

			setIL413.add(curCluster);

		}


		// MtbOnly
		for(int i=0 ; i< vectMtbonly.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectMtbonly.get(i));

			curCluster = tmp[0];

			setMtbonly.add(curCluster);
		}


		System.out.println("Total elem in set: " + setInfg.size());
		System.out.println("Total elem in set: " + setIL413.size());
		System.out.println("Total elem in set: " + setMtbonly.size());

		

		CommonFunction.doAllSetOperation_3Set_Stat(setInfg, setIL413,  setMtbonly , this.fnmOut);


	}



	public static void main(String[] args) {

	
		
		CreatVenn obj = new CreatVenn(
				
				"./VennDiagram/IFNGmtb_Unstimulated.txt", 
				"./VennDiagram/IL413mtb_Unstimulated.txt", 
				"./VennDiagram/Mtb_Unstimulated.txt",
				"./VennDiagram/OutputCommon.txt" );
		
		obj.doProcessing();
		
		
	}

}

