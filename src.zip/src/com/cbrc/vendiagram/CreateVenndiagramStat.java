package com.cbrc.vendiagram;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class CreateVenndiagramStat {


	String dataRoot;

	String fnmIfngmtb_unstimulated="IFNGmtb_Unstimulated.txt";
	String fnmIl413gmtb_unstimulated="IL413mtb_Unstimulated.txt";
	String fnmMtb_unstimulated="Mtb_Unstimulated.txt";


	Vector<String>  vectIfng;
	Vector<String> vectIl413;
	Vector<String> vectMtbonly ;

	int timePoint; // 28 36 48 72
	int up_down; // +1  up ; -1 down



	
	


	public CreateVenndiagramStat(String dataRoot,
			String fnmIfngmtb_unstimulated, String fnmIl413gmtb_unstimulated,
			String fnmMtb_unstimulated) {
		super();
		this.dataRoot = dataRoot;
		this.fnmIfngmtb_unstimulated = fnmIfngmtb_unstimulated;
		this.fnmIl413gmtb_unstimulated = fnmIl413gmtb_unstimulated;
		this.fnmMtb_unstimulated = fnmMtb_unstimulated;
	}


	void doProcessing()
	{

		loadData();


		int timeInterest=28;
		findStatForVen( timeInterest, 1) ;
		findStatForVen( timeInterest, -1) ;
		
		timeInterest=36;
		findStatForVen( timeInterest, 1) ;
		findStatForVen( timeInterest, -1) ;
		
		timeInterest=48;
		findStatForVen( timeInterest, 1) ;
		findStatForVen( timeInterest, -1) ;
		
		timeInterest=72;
		findStatForVen( timeInterest, 1) ;
		findStatForVen( timeInterest, -1) ;
		
		
		

	}


	void loadData()
	{
		vectIfng = CommonFunction.readlinesOfAfile(this.fnmIfngmtb_unstimulated);
		vectIl413 = CommonFunction.readlinesOfAfile(this.fnmIl413gmtb_unstimulated);
		vectMtbonly = CommonFunction.readlinesOfAfile(this.fnmMtb_unstimulated);
		
		System.out.println("Total line in file: " + vectIfng.size());
		System.out.println("Total line in file: " + vectIl413.size());
		System.out.println("Total line in file: " + vectMtbonly.size());
		
		
		
	}

	void findStatForVen( int timePoint, int upOrDown)
	{

		double thr;
		int index0based=0;
		switch (timePoint) {
		case 28:
			index0based=1;
			break;
		case 36:
			index0based=2;		
			break;
		case 48:
			index0based=3;
			break;
		case 72:
			index0based=4;
			break;
		default:
			break;
		}

		Set<String> setInfg = new LinkedHashSet<String>();
		Set<String> setIL413 = new LinkedHashSet<String>();
		Set<String> setMtbonly = new LinkedHashSet<String>();


		String tmp[];
		double valueOfInterest;
		String curCluster;

		for(int i=0 ; i< vectIfng.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectIfng.get(i));

			curCluster = tmp[0];
			valueOfInterest = Double.parseDouble(tmp [index0based] );

			switch (upOrDown) {
			case 1:

				if(valueOfInterest>= 0.0)
				{
					setInfg.add(curCluster);
				}

				break;

			case -1:
				if(valueOfInterest < 0.0)
				{
					setInfg.add(curCluster);
				}
				break;
			case 0:
				break;
			}

		}

		// IL413
		for(int i=0 ; i< vectIl413.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectIl413.get(i));

			curCluster = tmp[0];
			valueOfInterest =  Double.parseDouble(tmp [index0based] );

			switch (upOrDown) {
			case 1:

				if(valueOfInterest>= 0.0)
				{
					setIL413.add(curCluster);
				}

				break;

			case -1:
				if(valueOfInterest < 0.0)
				{
					setIL413.add(curCluster);
				}
				break;
			case 0:
				break;
			}

		}


		// MtbOnly
		for(int i=0 ; i< vectMtbonly.size() ;i++)
		{
			tmp = ConstantValue.patTab.split( vectMtbonly.get(i));

			curCluster = tmp[0];
			valueOfInterest =  Double.parseDouble(tmp [index0based] );

			switch (upOrDown) {
			case 1:

				if(valueOfInterest>= 0.0)
				{
					setMtbonly.add(curCluster);
				}

				break;

			case -1:
				if(valueOfInterest < 0.0)
				{
					setMtbonly.add(curCluster);
				}
				break;
			case 0:
				break;
			}

		}


		System.out.println("Total elem in set: " + setInfg.size());
		System.out.println("Total elem in set: " + setIL413.size());
		System.out.println("Total elem in set: " + setMtbonly.size());

		String fnmOut = dataRoot + "/" + timePoint;
		if( upOrDown ==1)
		{
			fnmOut = fnmOut + "_" + "up.txt" ;
		}else
		{
			fnmOut = fnmOut + "_" + "down.txt" ;
		}

		CommonFunction.doAllSetOperation_3Set_Stat(setInfg, setIL413,  setMtbonly , fnmOut);


	}



	public static void main(String[] args) {

	
		
		CreateVenndiagramStat obj = new CreateVenndiagramStat(
				"./VennDiagram/", 
				"./VennDiagram/IFNGmtb_Unstimulated.txt", 
				"./VennDiagram/IL413mtb_Unstimulated.txt", 
				"./VennDiagram/Mtb_Unstimulated.txt");
		
		obj.doProcessing();
		
		
	}

}
