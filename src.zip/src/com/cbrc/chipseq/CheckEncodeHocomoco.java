package com.cbrc.chipseq;

import com.cbrc.common.CommonFunction;

public class CheckEncodeHocomoco {

	public static void main(String[] args) {
		CheckEncodeHocomoco obj = new CheckEncodeHocomoco();
//		CommonFunction.doAllSetOperation("motifUniprotSingleLine.name", "encode.name");
		
//		CommonFunction.doAllSetOperation("common_Hoc_Enc.name", "CPS_hocomoco.name");
//		CommonFunction.doAllSetOperation("common_Hoc_Enc.name", "REFPS_hocomoco.name");
		
//		CommonFunction.doAllSetOperation("common_Hoc_Enc.name", "CPS_dmf.name");
//		CommonFunction.doAllSetOperation("common_Hoc_Enc.name", "REFPS_dmf.name");
	}
}
