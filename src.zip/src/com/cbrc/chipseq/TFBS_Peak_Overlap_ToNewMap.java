package com.cbrc.chipseq;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import com.cbrc.constant.ConstantValue;

public class TFBS_Peak_Overlap_ToNewMap {

	
	int arrMap[][];
	
	String dataRoot;
	String fNameOvlapSuffix;
	int totSeq;
	int totMotif;
	String fnmOvrlapMap;
	
	void init(String dataRoot, String fNameOverlap, String totS, String totMot, String fnmOutputmap)
	{
		this.dataRoot=dataRoot;
		this.fNameOvlapSuffix =  fNameOverlap;
		this.totSeq = Integer.parseInt(totS);
		this.totMotif = Integer.parseInt(totMot);
		this.fnmOvrlapMap =  this.dataRoot+ fnmOutputmap;
		arrMap  =  new int[this.totSeq][this.totMotif];
		
	}
	
	void withoutinit()
	{
		this.dataRoot= ConstantValue.filePrefixChIPSeq;
		this.fNameOvlapSuffix = ".overlap.bed";
		this.totSeq = Integer.parseInt("18537");
		this.totMotif = Integer.parseInt("3");
		this.fnmOvrlapMap =   this.dataRoot+  "all.overlap.map";
		arrMap  =  new int[this.totSeq][this.totMotif];
	}
	
	void init()
	{
		for (int i=0; i<this.totSeq;i++)
		{
			for(int j=0 ;j<totMotif; j++)
			{
				arrMap[i][j] = 0;
			}
		}
	}
	
	void writeArray()
	{
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter( fnmOvrlapMap  ));
			StringBuffer buf = new StringBuffer();
			for (int i=0; i<this.totSeq;i++)
			{
				for(int j=0 ;j<totMotif; j++)
				{
					buf.append(arrMap[i][j]+"\t" );
				}
				buf.append( "\n" );
			}
			
			out.write(buf+"");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	void makeOverlapBed_OverlapMap(int motifNo)
	{
		try {
			
			FileInputStream fstream = new FileInputStream( this.dataRoot+ motifNo+ fNameOvlapSuffix);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			
			String strLine = null;
			String tmp[];
			String name[];
			int seqNo;

			while ((strLine = br.readLine()) != null) {
				
				if( strLine.length() < 5)
				{
					continue;
				}
				tmp = ConstantValue.patTab.split(strLine);
				name = ConstantValue.patColon.split(tmp[3]);
				seqNo = Integer.parseInt(name[0]);
//				motifNo = Integer.parseInt(name[1]);
				arrMap[seqNo-1][motifNo-1]++;
			}
			
			br.close();
			in.close();
			fstream.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void doProcessing()
	{
		for(int j=0 ; j<this.totMotif ;j++)
		{
			makeOverlapBed_OverlapMap(j+1 );
		}
		writeArray();
		
	}
	
	public static void main(String[] args) {
		TFBS_Peak_Overlap_ToNewMap obj = new TFBS_Peak_Overlap_ToNewMap();
//		obj.withoutinit();
		obj.init(args[0], args[1], args[2] , args[3],  args[4]);
		
		obj.doProcessing();
	}
}
