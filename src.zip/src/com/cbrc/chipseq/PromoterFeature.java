package com.cbrc.chipseq;

import java.util.ArrayList;

import com.cbrc.bean.ChromatinState;

public class PromoterFeature {

	
	int index;

	String chrom;
    int start;
    int end;
    char strand;
    ArrayList<ChromatinState> stateList;

	public PromoterFeature(int index, String chm,int st, int en,char stra) {
		this.index = index;
		this.chrom = chm;
		this.start = st;
		this.end = en;
		this.strand = stra;
        
        stateList = new ArrayList<ChromatinState>();
    }
    
    
    void addStateOverlap( String stateChrm, Integer stateStart, Integer stateEnd, Integer stNo)
    {
    	ChromatinState newstate = new ChromatinState(stateChrm, stateStart, stateEnd  , stNo);
    	stateList.add(newstate);
    }
    
   
	public ArrayList<ChromatinState> getStateList() {
		return stateList;
	}
	public void setStateList(ArrayList<ChromatinState> stateList) {
		this.stateList = stateList;
	}
    
    public String getChrom() {
		return chrom;
	}
	public void setChrom(String chrom) {
		this.chrom = chrom;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public char getStrand() {
		return strand;
	}
	public void setStrand(char strand) {
		this.strand = strand;
	}
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
    
    
}
