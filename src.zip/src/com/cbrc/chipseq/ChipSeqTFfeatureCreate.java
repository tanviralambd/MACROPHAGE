package com.cbrc.chipseq;



import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.regex.*;



import com.cbrc.bean.ChromatinState;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/**
 *
 * _author tanviralam
 */
class ChipSeqTFfeatureCreate {

	HashMap<String, Vector<PromoterFeature>> mapChrmWisePromoterState = new HashMap<String, Vector<PromoterFeature>>();

	int threshold ;
	int seqSize ; // =2000

	int sampleSize ; // 419 413
	int windowSize = 100;
	int windowShift = 50;
	int totWindow ;

	String myfold;
	String hmfold;
	String celltype;

	String fnameSeqPromoter ; //= "D:/KAUST/5.Fall2011-12/ucsc/data/DeletedFinal/onlyP.bed"; // onlyP.bed  all.bookkeep.onlyPrimates.bed
	String fnameCellExperimentAntibody; // "D:/KAUST/5.Fall2011-12/ucsc/data/hg19/cpg/cgi_UCSC_hg19_unmasked"
	String fnameFeatrue;
	String fnameWholeMat ;

	String fnameOverlap="gene.stateOverlap.txt";

	/*
	 *  value represents the index
	 */
	int featmatrix[][] ; 

	void withoutInit()
	{


		if(CommonFunction.isWindows())
		{
			myfold = ConstantValue.filePrefixWindows ;

		}else if ( CommonFunction.isUnix())
		{
			myfold = ConstantValue.filePrefixLinux;
		}
		
		this.hmfold =  "/media/Data/KAUST/research/CNC/dataforHM/"; //  "/home/KAUST/alamt/CNC/dataforHM/";
		this.celltype= "GM12878";

		threshold = 95;
		sampleSize =  ConstantValue.SAMPLESIZE; // 1420; // 308 + 1112
		seqSize=ConstantValue.SEQLEN;
		featmatrix = new int[sampleSize][seqSize] ;

		windowSize = ConstantValue.WINDOWSIZE;
		windowShift = ConstantValue.WINDOWSHIFT;
		if(windowShift == windowSize)
			totWindow = seqSize/windowShift ;
		else
			totWindow = seqSize/windowShift - 1;

		fnameSeqPromoter=  myfold + "cnc_norepeats_CAGE562NucleusPolyA-.bed"; //"allGene.bed" ; // "all.bed"; 
		fnameCellExperimentAntibody= hmfold + "GM12878_antibody.txt";
		
//		fnameFeatrue = myfold + "gene.state.feature" ; // cpg.feature
//		fnameWholeMat = myfold + "gene.statewholelen.matrix" ; // cpgwholelen.matrix

	}

	void init( String myroot, String HMroot ,int thr, String delType , int sampSize ,  int seqSz, int winShift, int winSize, 
			String fNameSeq,  String fNameCellExprAntibody, String cellname)
	{

		this.myfold = myroot;
		this.hmfold = HMroot;
		this.celltype= cellname;
		
		threshold = thr;
		sampleSize = sampSize; // 308 + 1124
		seqSize=seqSz;
		featmatrix = new int[sampleSize][seqSize] ;

		windowSize = winSize;
		windowShift = winShift;
		if(windowShift == windowSize)
			totWindow = seqSize/windowShift ;
		else
			totWindow = seqSize/windowShift - 1;

		fnameSeqPromoter                   =  this.myfold + fNameSeq; 
		fnameCellExperimentAntibody =  this.hmfold+  fNameCellExprAntibody ; //"D:/KAUST/5.Fall2011-12/ucsc/data/hg19/cpg/cgi_UCSC_hg19_unmasked";
		
//		fnameFeatrue            = myfold +fNameFeat ; // gene.state.feature
//		fnameWholeMat        = myfold+fNameFeat + ".matrix";
		
	}

	public static void main(String args[]) {

		ChipSeqTFfeatureCreate obj = new ChipSeqTFfeatureCreate();

		int thr = Integer.parseInt(args[2], 10);
		String delType = args[3];
		int sampSize = Integer.parseInt(args[4], 10);
		int seqSize = Integer.parseInt(args[5], 10) ;  
		int winShift = Integer.parseInt(args[6], 10) ;
		int winSize = Integer.parseInt(args[7], 10) ;
		String fNameSeq  = args[8] ;
		String fNameCellAntibody  = args[9] ;
		String cellName  = args[10] ;

		System.out.println("Thr:"+thr + " delType:"+ delType+" Sam:"+sampSize + " Seq:"+seqSize + " windShift:"+winShift + " winSize:"+winSize +  " fnamSeq:"+fNameSeq + " fNmCellantibodyExperiment:" + fNameCellAntibody+ " fnameCell:"+cellName);
		obj.init( args[0], args[1], thr, delType ,sampSize, seqSize,winShift, winSize, fNameSeq, fNameCellAntibody,cellName);

//		obj.withoutInit() ;
		obj.doProcessing() ;

	}

	void doProcessing()
	{
		
		// find the promoters
		makeChrmWisePromoterMap() ;

		// loop over all experiment
		int tfNo=0;
		try {
			
			String strLine;
			FileInputStream fstream = new FileInputStream(this.fnameCellExperimentAntibody);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ((strLine = br.readLine()) != null) {
				if (strLine.length() < 3) {
					continue;
				}
				tfNo++;
				System.out.println("Handling TF:"+tfNo);
				
				fnameFeatrue     =  this.myfold+ this.celltype +"."+ tfNo+ ".feature" ; 
				fnameWholeMat =  this.myfold+ this.celltype +"."+ tfNo+ ".feature.matrix" ; 
				
				// ( find + make  list of  states) in each promoter
				extractPeakInfor( tfNo , this.hmfold+strLine.trim()) ;
				
				// create Feature
				createFeatureWithPeakOverlap() ;
				
				// write feature matrix
//				writeFeatureMatrix() ;
				
				writeFeatureMatrixWindowBased() ;
				writeFeatureMatrixWholeLength() ;
				
				cleandata();
				
			} // read each ANTIBODY file name
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
	}

	void cleandata()
	{

		int totPromUnderAchrom=0;
		Set set = mapChrmWisePromoterState.entrySet();
        System.out.println("Total Unique chrmomosome entry:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(  itr.hasNext()){
            Map.Entry me = (Map.Entry)itr.next();
            String chrName = (String)me.getKey();
            totPromUnderAchrom = mapChrmWisePromoterState.get(chrName).size();
            for(int promIndex=0 ;  promIndex<totPromUnderAchrom ; promIndex++)
            {
            	mapChrmWisePromoterState.get(chrName).get(promIndex).getStateList().clear();
            }
           
        }
		
		
		for(int i=0; i<sampleSize ; i++)
		{
			for(int j=0 ; j < seqSize; j++)
			{
				featmatrix[i ][ j ]= 0;
			}
		}
	}
	
	void makeChrmWisePromoterMap() {
		System.out.println("Extracting prom info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[,\\t]+");
		int index = 0;
//		int l;
		try {

			FileInputStream fstream = new FileInputStream(fnameSeqPromoter);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			//            BufferedWriter out = new BufferedWriter(new FileWriter(fnamePromInfo));

			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);
//				l = tmp.length;
//				if (l < 7) {
//					System.out.println("some problem for string:" + strLine);
//				} else {
					
					try {
						//                        out.write(">HG19_"+tmp[0] + "_" + tmp[1] + "_" + tmp[2] + "_" + tmp[5] );
						//                        out.write("\n");
						addInChrMap(index ,tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])  -1 , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

					} catch (Exception e) {
						e.printStackTrace();
					}
					index++;
//				}

			}

			System.out.println("Total PROMOTER entry:" + index); //9918801
			br.close();
			in.close();
			fstream.close();
			//            out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	void extractPeakInfor(int tfNo , String fnameTFPeak) {

		System.out.println("Extracting state info ... ... ...");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		int c = 0;
		int l;

		try {

			FileInputStream fstream = new FileInputStream(fnameTFPeak);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 5) {
					continue;
				}

				tmp = p.split(strLine, 6); // 4 column seperated by tab
				l = tmp.length;
				if (l < 3) {
					System.out.println("some problem for string:" + strLine);
				} else {
					try {
						
						updateStateInChrWisePromoter(tmp[0], Integer.parseInt(tmp[1]), Integer.parseInt(tmp[2])  -1  , tfNo );
					} catch (Exception e) {
						e.printStackTrace();
					}
					c++;
				}

			}

			System.out.println("Total State entry:" + c); 
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void addInChrMap(int index, String chrm, int start, int end, char strand) {

		PromoterFeature pm = new PromoterFeature(index ,chrm, start, end, strand);

		if (mapChrmWisePromoterState.containsKey(chrm)) {
			mapChrmWisePromoterState.get(chrm).add(pm);
		} else {
			Vector<PromoterFeature> vp = new Vector<PromoterFeature>();
			vp.add(pm);
			mapChrmWisePromoterState.put(chrm, vp);
		}

	}


	void updateStateInChrWisePromoter(String chrmState, int startState, int endState , int tfNo) {

		if (mapChrmWisePromoterState.containsKey(chrmState)) {
			Vector<PromoterFeature> vectPromoter = mapChrmWisePromoterState.get(chrmState);

			Iterator<PromoterFeature> itr = vectPromoter.iterator();
			while (itr.hasNext()) {
				PromoterFeature prm = (PromoterFeature) itr.next();

				if ((startState <= prm.start && endState >= prm.end)
						|| (prm.start <= startState && prm.end >= endState)
						|| (prm.start <= startState && startState <= prm.end)
						|| (prm.start <= endState && endState <= prm.end)) {
					//                            System.out.println("OVERLAP FOUND FOR: "+ prm.chrom+"_"+prm.start+"_"+ prm.end+"_"+prm.strand );
					prm.addStateOverlap(chrmState, startState, endState , tfNo);
				}

			}
		}
	}

	void createFeatureWithPeakOverlap() {

		System.out.println("Finding overlap  ... ... ... ");
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter(fnameOverlap));
			int countOverlap = 0;
			int itrIndex = 0;

			int strIn;
			int endIn;
			Set setChrm = mapChrmWisePromoterState.entrySet();
			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				System.out.println("Find overlap in chromosome:"+me.getKey());
				Vector<PromoterFeature> vp = (Vector<PromoterFeature>) me.getValue();
				Iterator itr = vp.iterator();
				while (itr.hasNext()) {
					PromoterFeature prm = (PromoterFeature) itr.next();

					Iterator itrState = prm.getStateList().iterator();
					countOverlap = 0;
					while (itrState.hasNext()) {
						countOverlap++;

						ChromatinState tmp = (ChromatinState)itrState.next();

						strIn = prm.start > tmp.getStateStart() ? prm.start : tmp.getStateStart();
						endIn = prm.end   < tmp.getStateEnd()   ? prm.end   : tmp.getStateEnd();

						out.write(">HG19_"+prm.chrom.toUpperCase() + "_" + prm.start + "_" + prm.end + "_" + prm.strand + "\t" +  prm.getIndex() +"\t"+tmp.getStateChrom() +"\t"+  tmp.getStateStart() +"\t" + tmp.getStateEnd()+ "\t" + (endIn - strIn +1)  );
						out.write("\n");
						//                        System.out.println( "PromIndex: "+ prm.getIndex() + " itrIndex: " + itrIndex);
						updateFeatureMatrix(  prm.start,  prm.end , tmp.getStateStart(), tmp.getStateEnd() ,  tmp.getStateNo() , prm.getIndex() ) ;

					}
					if (countOverlap == 0) {

						out.write(">HG19_"+prm.chrom.toUpperCase() + "_" + prm.start + "_" + prm.end + "_" + prm.strand + "\t" +  "0" +"\t"             +  "0" +"\t" +                  "0" + "\t" +           "0"+"\t"   );
						out.write("\n");
					}

					itrIndex++;

				}
			}
			System.out.println("End find overlap.");
			out.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	void updateFeatureMatrix( int promStart, int promEnd , int stateStart, int stateEnd , int stNo  ,int promIndex)
	{

		int overlapStart = promStart > stateStart ? promStart : stateStart ; // take max
		int overlapEnd   = promEnd   < stateEnd   ? promEnd   : stateEnd   ; // take min
		int len = overlapEnd - overlapStart + 1;

		int overlapStartIndex = overlapStart - promStart   ;
		int overlapEndIndex   =  overlapStartIndex + len -1;

		int i=0;
		try {

			for( i=overlapStartIndex; i<=overlapEndIndex ; i++)
			{
				if(i==seqSize)
					break;
				if( featmatrix[promIndex][i]  != 0 ){
//					System.out.println("PREVIOUS state found " + featmatrix[promIndex][i]  + "\t NEW state found:" + stNo);
					;
				}

				featmatrix[promIndex][i]  = stNo; 
			}
		} catch (Exception e) {
			System.out.println("error for i:"+i + " promIndex:"+promIndex);
			e.printStackTrace();
		}

	}

	void writeFeatureMatrixWindowBased()
	{
		System.out.println("Writing feature matrix Window Based...");
		NumberFormat f = new DecimalFormat("#0.00");
		f.setGroupingUsed(false);
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter( fnameFeatrue ));
			for(int i=0; i<sampleSize;i++)
			{
				for(int windowIndex=0;windowIndex< totWindow;windowIndex++)
				{
					//        			System.out.println("Window no:"+ windowIndex );
					int startSeqIndex =     windowIndex* windowShift;
					int endSeqIndex   = startSeqIndex + windowSize - 1;
					if(endSeqIndex > seqSize  )
					{
						endSeqIndex = seqSize-1;
					}
					int sum = 0;
					for(int j=startSeqIndex; j<= endSeqIndex;j++)
					{
						sum += featmatrix[i][j] ;
					}
					out.write( sum + "\t");
				}
				out.write("\n");
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("End of Writing feature matrix ...");
	}
	
	void writeFeatureMatrix()
	{
		System.out.println("Writing feature matrix ...");
		NumberFormat f = new DecimalFormat("#0.00");
		f.setGroupingUsed(false);
		try {
			BufferedWriter out = new BufferedWriter(new FileWriter( fnameFeatrue ));
			for(int i=0; i<sampleSize;i++)
			{
//				float statePercent[] = new float[ConstantValue.NO_HM_ANTIBODY];
				float statePercent = 0;
				for(int j=0; j< seqSize;j++)
				{
					if(featmatrix [i][j] !=0)
					{
//						statePercent[ featmatrix [i][j]-1 ]  +=1;
						statePercent +=1 ;
					}
				}
				for(int s=0; s< ConstantValue.NO_HM_ANTIBODY;s++)
				{
//					out.write(  f.format( statePercent[s]/ConstantValue.SEQLEN ) + "\t");
					out.write(  f.format( statePercent /ConstantValue.SEQLEN ) + "\t") ;
				}
				out.write("\n");
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("End of Writing feature matrix ...");
	}


	void writeFeatureMatrixWholeLength()
	{
		System.out.println("Writing WHOLE feature matrix ...");
		try {

			BufferedWriter out = new BufferedWriter(new FileWriter( fnameWholeMat ));
			for(int i=0; i<sampleSize;i++)
			{
				for(int j=0; j< seqSize;j++)
				{
					out.write( Integer.toString(featmatrix[i][j]) + "\t");
				}
				out.write("\n");
			}
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("End of Writing WHOLE feature matrix ...");
	}

	void writeFeatureMatrixNotWorkForThisProblem()
	{
		try {

			BufferedWriter out = new BufferedWriter(new FileWriter(fnameFeatrue));
			for(int i=0; i<sampleSize;i++)
			{
				for(int windowIndex=0;windowIndex< totWindow;windowIndex++)
				{
					//        			System.out.println("Window no:"+ windowIndex );
					int startSeqIndex =     windowIndex* windowShift;
					int endSeqIndex   = startSeqIndex + windowSize - 1;
					if(endSeqIndex > seqSize  )
					{
						endSeqIndex = seqSize-1;
					}
					int sum = 0;
					for(int j=startSeqIndex; j<= endSeqIndex;j++)
					{
						sum += featmatrix[i][j] ;
					}
					out.write( sum + "\t");
				}
				out.write("\n");
			}
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}








}// main class end

