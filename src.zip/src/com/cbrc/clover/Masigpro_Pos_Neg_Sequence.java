package com.cbrc.clover;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.bean.FastaMult;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class Masigpro_Pos_Neg_Sequence {

	
	
	String fin_ID_FastaHead;
	String finFasta;
	String finDEG;
	
	String foutPos;
	String foutNeg;
	
	
	LinkedHashMap<String, String>  lhm_GeneID_FastaHeader = new LinkedHashMap<String, String>();
	FastaMult multFasta = new FastaMult();
	Vector<String> vect_DEG = new Vector<String>();
	
	void init( String fID_Head,String fasta,String finDG, String p, String n)
	{
		
		this.fin_ID_FastaHead = fID_Head;
		this.finFasta = fasta;
		this.finDEG = finDG;
		this.foutPos = p;
		this.foutNeg = n;
	}
	
	
	/*
	 *  key : TrxID
	 *  value : FastaHeader
	 *  
	 */
	void load_AllGene_Fastaheader_Map()
	{
		Vector<String> vect_Gencode_FastaHeader = CommonFunction.readlinesOfAfile(this.fin_ID_FastaHead);

		String tmp[];
		for(int i=0; i<vect_Gencode_FastaHeader.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vect_Gencode_FastaHeader.get(i));
			
			lhm_GeneID_FastaHeader.put(tmp[0], tmp[1]);
			
		}
		System.out.println("Tot Gene entry: "+  lhm_GeneID_FastaHeader.size());
	}
	
	void loadAllFasta(){
		multFasta = CommonFunction.fasta_readFasta_Multiplelines(this.finFasta);
		
		
	}
	
	void load_DEG()
	{
		Vector<String> vectTmp = CommonFunction.readlinesOfAfile(this.finDEG);
		String tmp[];
		
		for(int i=1; i<vectTmp.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectTmp.get(i));
			vect_DEG.add(tmp[1]);
		}
		System.out.println("Tot DEG entry: "+  vect_DEG.size() );
		
	}
	
	void seperate_Pos_Neg()
	{
//		Set set = multFasta.getLhmHeader_VectIndex().entrySet();
//		Iterator itr = set.iterator();
//        while(itr.hasNext()){
//            Map.Entry me = (Map.Entry) itr.next();
//            String id = (String)me.getKey();
//            int index =  (Integer)me.getValue();
//        }
		
		
		StringBuffer bufPos = new StringBuffer();
		StringBuffer bufNeg = new StringBuffer();
		

		String curDEGid, curFastaHead, curFastaSeq;
		int curMultIndex;
		
		// Postive
		LinkedHashSet<Integer> setPosIndex = new LinkedHashSet<Integer>();
		
		for(int i=0;  i<vect_DEG.size();i++)
		{
			curDEGid = vect_DEG.get(i);
			curFastaHead = lhm_GeneID_FastaHeader.get(curDEGid);
			curMultIndex = multFasta.getLhmHeader_VectIndex().get(curFastaHead);
			curFastaSeq = multFasta.getSeq().get(curMultIndex);
			
			bufPos.append(curFastaHead+"\n" + curFastaSeq + "\n");
			setPosIndex.add(curMultIndex);
		}
		
		
		// Negative
		for(int i=0;  i<multFasta.getSeq().size();i++)
		{
			if( ! setPosIndex.contains(i))
			{
				curFastaHead = multFasta.getHeader().get(i);
				curFastaSeq  = multFasta.getSeq().get(i);
				bufNeg.append(curFastaHead+"\n" + curFastaSeq + "\n");
			}
		}
		
		
		CommonFunction.writeContentToFile(this.foutPos, bufPos+"");
		CommonFunction.writeContentToFile(this.foutNeg, bufNeg+"");
		
	}
	
	
	void doProcessing()
	{
		load_AllGene_Fastaheader_Map();
		loadAllFasta();
		load_DEG();
		 
		seperate_Pos_Neg();
		
		
	}
	
	
	public static void main(String[] args) {
		
		Masigpro_Pos_Neg_Sequence obj = new Masigpro_Pos_Neg_Sequence();
		
		
//		obj.init("finalLncRNA.prom.bed.fastaheader","finalLncRNA.prom.bed.fasta","NFvsIFNG.DEG.4.24.DESEQ.sigGene", "pos.fasta","neg.fasta");
		obj.init(args[0],args[1],args[2],args[3], args[4]);
		
		obj.doProcessing();
		
	}
	
	
}
