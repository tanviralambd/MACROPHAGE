package com.cbrc.clover;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.constant.ConstantValue;

public class Hocomoco_Transfac_Clover {


	String fnmHocomoco;
	String fnmClover;
	
	void withoutInit()
	{
		
		fnmHocomoco = "./"+ "HOCOMOCOv9_AD_TRANSFAC.txt";
		fnmClover = "./" + "HOCOMOCOv9_AD.clover";
		
	}
	
	void init(String fir, String sec)
	{
		
		fnmHocomoco =  fir;
		fnmClover = sec;
	}
	
	
	Vector<String> A = new Vector<String>();
	Vector<String> C = new Vector<String>();
	Vector<String> G = new Vector<String>();
	Vector<String> T = new Vector<String>();
	
	
	void parseWPCMtoclover()
	{
		
		try {
			
			FileInputStream fstream = new FileInputStream(fnmHocomoco);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			BufferedWriter out = new BufferedWriter(new FileWriter(fnmClover));
			
			String befTrim;
			String strLine;
			String tmp[];
			String header=null;
			
			boolean fromInsect = true;
			
			
			StringBuffer allContent = new StringBuffer();
			int len;
			int val;
			String accNo=null, ID=null, NA=null;
			
			br.readLine() ; 
			br.readLine() ; 
			br.readLine() ; 
			
			while ((befTrim = br.readLine()) != null) {
				
				strLine = befTrim.trim();
				if(strLine.length() < 3)
					continue;
				
			
				// ACC 
				if (   strLine.startsWith("AC") )
				{
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					accNo = tmp[1];
				}

				// ID
				if (   strLine.startsWith("ID") )
				{
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					ID = tmp[1];
				}
				
				// NA
				if (   strLine.startsWith("NA") )
				{
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					NA = tmp[1];
				}

				
									
				
				if (   strLine.startsWith("P0")		)
				{
//					header = ">"+accNo+" "+ID ; //  +" "+ NA;
					header = ">"+ID ; //  +" "+ NA;
					
					allContent.append(header+"\n");
					
					while( ! (befTrim = br.readLine() ).startsWith("XX") )
					{
						
						strLine = befTrim.trim();
						tmp = ConstantValue.patWhiteSpace.split(strLine);
						
						A.add(tmp[1]);
						C.add(tmp[2]);
						G.add(tmp[3]);
						T.add(tmp[4]);
						
					}
					
					for(int i=0;  i<A.size() ;i++)
					{
						if(i< (A.size() - 1)){
							allContent.append(A.get(i) + "\t" + C.get(i) + "\t" + G.get(i) +"\t" + T.get(i) +"\n" );
						}
						
							
					}
					
//					for(int i=0;  i<C.size() ;i++)
//					{
//						if(i< (C.size() - 1))
//							allContent.append(C.get(i) + "\t");
//						else
//							allContent.append(C.get(i) + "\n");
//					}
//					
//					for(int i=0;  i<G.size() ;i++)
//					{
//						if(i< (G.size() - 1))
//							allContent.append(G.get(i) + "\t");
//						else
//							allContent.append(G.get(i) + "\n");
//					}
//					
//					for(int i=0;  i<T.size() ;i++)
//					{
//						if(i< (T.size() - 1))
//							allContent.append(T.get(i) + "\t");
//						else
//							allContent.append(T.get(i) + "\n");
//					}
//					
					
					A.clear();C.clear(); G.clear(); T.clear();
				
				} // loop around matrix 
				
				
				
				
			}
			
			
			
			out.write(allContent+"");
			
			out.close();
			fstream.close(); in.close(); br.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	void doProcessing()
	{
		
		parseWPCMtoclover();
		
	}
	
	public static void main(String[] args) {
		
		Hocomoco_Transfac_Clover obj = new Hocomoco_Transfac_Clover();
//		obj.withoutInit();
		obj.init(args[0], args[1]);
		obj.doProcessing();
	}
}
