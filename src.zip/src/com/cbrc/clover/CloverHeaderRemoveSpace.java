package com.cbrc.clover;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;

import com.cbrc.constant.ConstantValue;



public class CloverHeaderRemoveSpace {

	
	String fin, fOut;
	
	void withoutinit()
	{
		
		fin =  "subset.clover";
		fOut = "kaustfinal.subset.clover";
	}
	

	void init(String fir, String sec)
	{
		
		fin =  fir;
		fOut = sec;
	}

	
	void doProcessing()
	{
		removsSpaceFromHeader();
	}
	
	
	void removsSpaceFromHeader()
	{
		try {
			
		
				StringBuffer buffer = new StringBuffer();
			
				FileInputStream fstream = new FileInputStream(fin);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				BufferedWriter out = new BufferedWriter(new FileWriter(fOut));
				
				String strLine, withSpace, noSpace;
				
				while( ( strLine = br.readLine() )!=null)
				{
					if(strLine.length() < 3)
						continue;
					
					if(strLine.startsWith(">"))
					{
						withSpace = strLine;
						noSpace = withSpace.replaceAll("[\\s]+", "#");
						
						buffer.append(noSpace+"\n");
					}
					else
					{
						buffer.append(strLine+"\n");
					}
					
				}
				

				out.write(buffer + "") ;
				
				br.close(); in.close(); fstream.close();
				out.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		CloverHeaderRemoveSpace obj = new CloverHeaderRemoveSpace();
//		obj.withoutinit();
		obj.init(args[0], args[1]);
		obj.doProcessing();
	}
	
}
