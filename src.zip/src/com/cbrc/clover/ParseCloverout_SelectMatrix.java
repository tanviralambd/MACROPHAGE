package com.cbrc.clover;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import com.cbrc.constant.ConstantValue;

//import com.cbrc.bean.BED;
//import com.cbrc.bean.TRANSFACmap;


//import com.cbrc.container.ContainerTRANSFACmap;

public class ParseCloverout_SelectMatrix {

	
	double sigValue;
	
	
	String fnmCloverOutput1=null;
	String fnmOrigMatrix=null;
	
	// out
	String fnmSigMotifID=null;
	String fnmSigMotifMatrix=null;
	
	

	
	
	LinkedHashMap<String, String> lhm1 = new LinkedHashMap<String, String>();
//	LinkedHashMap<String, String> lhm2 = new LinkedHashMap<String, String>();

	void withoutinit()
	{
		
		
		this.sigValue = 0.05;
		this.fnmOrigMatrix    =  "kaustfinal.clover";
		this.fnmCloverOutput1 =  "DEG.prom.info.nurse.bed.bgforager.clovermap";
		
		
		// out
		this.fnmSigMotifID =  "sig.nurse.motifid";
		this.fnmSigMotifMatrix =  "kaustfinal.sig.clover";


	}

	
	void init( String sig ,  String allMatrixClover , String fnmCloverOutput1, String sigid1, String subsetMat  )
	{
		

		this.sigValue = Double.parseDouble(sig);
		this.fnmOrigMatrix =  allMatrixClover ; //"kaustfinal.clover";
		this.fnmCloverOutput1 = fnmCloverOutput1;
		
		
		// out
		this.fnmSigMotifID =  sigid1 ; //"sig.nurse.motifid";
		
		this.fnmSigMotifMatrix =  subsetMat ; //"kaustfinal.sig.clover";

	}


//	void parseSigMotifNamePvalueNOTUSED(String fnmCloverOut1, String fnmSigOut1 , String fnmCloverOut2, String fnmSigOut2 )
//	{
//
//		String tmp[];
//		String strLine=null;
//		String strLineBeforeTrim = null;
//		String promChrom , promStart, promEnd, promStrand;
//		String holder;
//		int posMinus;
//		int totSplit=0;
//		int needToConsiderLast=2; 
//		int totHeadField;
//		String curName,  hitScore, hitPval ;
//
//
//		try {
//
//			FileInputStream fstream = new FileInputStream(fnmCloverOut1);
//			DataInputStream in = new DataInputStream(fstream);
//			BufferedReader br = new BufferedReader(new InputStreamReader(in));
//
//			
//			FileInputStream fstream2 = new FileInputStream(fnmCloverOut2);
//			DataInputStream in2 = new DataInputStream(fstream2);
//			BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
//			
//			BufferedWriter bwr  = new BufferedWriter( new FileWriter( fnmSigOut1) );
//			BufferedWriter bwr2  = new BufferedWriter( new FileWriter( fnmSigOut2) );			
//
//			String motifID = new String();
//			StringBuffer buffer = new StringBuffer();
//
//			String curGeneKey, curGeneID ;
//
//			while ( (strLineBeforeTrim = br.readLine() ) != null ) {
//
//				strLine = strLineBeforeTrim.trim();
//				if(strLine.length() <4)
//					continue; // skip blank lines
//
//
//				if( !strLine.contains("Raw score"))
//				{
//					 br.readLine();
//					continue; // now start
//				}
//				br.readLine();/// read the next un-informative line	
//					 
//
//				while( (strLineBeforeTrim = br.readLine() ) != null )
//				{
//					strLine = strLineBeforeTrim.trim();
//					if(strLine.length() <4)
//						continue; // skip blank lines
//					if(strLine.startsWith("*** Motif"))
//						break; // end of motif p-value lines
//
//					tmp = ConstantValue.patWhiiteSpace.split(strLine );
//
////					totSplit = tmp.length;
////					totHeadField = totSplit - needToConsiderLast;
////
////					for(int i=0 ; i< totHeadField ; i++)
////					{
////						motifID.append(tmp[i]+"#");
////					}
////					curName = motifID+"";
////					motifID = null;
////					motifID = new StringBuffer();
////
////					hitScore= tmp[totSplit - needToConsiderLast] ;  
////					hitPval = tmp[totSplit - needToConsiderLast + 1] ; 
//					
//					motifID = tmp[0];
//					hitScore = tmp[1];
//					hitPval = tmp[2];
//					
//
//					if( Double.parseDouble(hitPval)<= this.sigValue )
//					{
//						lhm1.put(motifID, motifID+"\t"+hitScore + "\t" + hitPval) ;
////						buffer.append(curName+"\t"+hitScore + "\t" + hitPval + "\n") ;
//					}
//				}
//
//				break;
//
//			} // end of outer while
//			
//			
//			
//			while ( (strLineBeforeTrim = br2.readLine() ) != null ) {
//
//				strLine = strLineBeforeTrim.trim();
//				if(strLine.length() <4)
//					continue; // skip blank lines
//
//
//				if( !strLine.equals("Matrix"))
//					continue; // now start 
//
//				while( (strLineBeforeTrim = br2.readLine() ) != null )
//				{
//					strLine = strLineBeforeTrim.trim();
//					if(strLine.length() <4)
//						continue; // skip blank lines
//					if(strLine.startsWith("*** Motif"))
//						break; // end of motif p-value lines
//
//					tmp = ConstantValue.patWhiiteSpace.split(strLine );
//
////					totSplit = tmp.length;
////					totHeadField = totSplit - needToConsiderLast;
////
////					for(int i=0 ; i< totHeadField ; i++)
////					{
////						motifID.append(tmp[i]+"#");
////					}
////					curName = motifID+"";
////					motifID = null;
////					motifID = new StringBuffer();
//
////					hitScore= tmp[totSplit - needToConsiderLast] ;  
////					hitPval = tmp[totSplit - needToConsiderLast + 1] ; 
//
//					motifID = tmp[0];
//					hitScore = tmp[1];
//					hitPval = tmp[2];
//					
//					if( Double.parseDouble(hitPval)<= this.sigValue )
//					{
//						lhm2.put(motifID, motifID+"\t"+hitScore + "\t" + hitPval) ;
////						buffer.append(curName+"\t"+hitScore + "\t" + hitPval + "\n") ;
//					}
//				}
//
//				break;
//
//			} // end of outer while
//			
//			
//			System.out.println("First set has sig motif:" + lhm1.size());
//			System.out.println("Second set has sig motif:" + lhm2.size());
//			
//			// now remove common between them
//			Vector<String> common = new Vector<String>();
//			Set set = lhm1.entrySet();
//            Iterator itr = set.iterator();
//            while(itr.hasNext()){
//                Map.Entry me = (Map.Entry)itr.next();
//                String id = (String)me.getKey();
//                if(lhm2.containsKey(id))
//                {
//                	common.add(id);
//                	
//                }
//               
//            }
//			
//            for( int i=0  ;  i<common.size()  ; i++)
//            {
//            	lhm1.remove( common.get(i));
//            	lhm2.remove( common.get(i));
//            }
//            
//			System.out.println("After removal of COMMON First set has sig motif:" + lhm1.size());
//			System.out.println("After removal of COMMON Second set has sig motif:" + lhm2.size());
//
//			
//			//  now write
//			
//			set = lhm1.entrySet();
//            itr = set.iterator();
//            while(itr.hasNext()){
//                Map.Entry me = (Map.Entry)itr.next();
//                String id = (String)me.getKey();
//                bwr.write(lhm1.get(id)+"\n");
//            }
//			
//			set = lhm2.entrySet();
//            itr = set.iterator();
//            while(itr.hasNext()){
//                Map.Entry me = (Map.Entry)itr.next();
//                String id = (String)me.getKey();
//                bwr2.write(lhm2.get(id)+"\n");
//            }
//			
////			bwr.write(buffer+"");
//			bwr.close();
//			bwr2.close();
//			br.close(); 			in.close(); 			fstream.close();
//			br2.close(); 			in2.close(); 			fstream2.close();
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//
//	}
//	
//	

	
	
	void parseSigMotifNamePvalue(String fnmCloverOut1, String fnmSigOut1  )
	{

		String tmp[];
		String strLine=null;
		String strLineBeforeTrim = null;
		String promChrom , promStart, promEnd, promStrand;
		String holder;
		int posMinus;
		int totSplit=0;
		int needToConsiderLast=2; 
		int totHeadField;
		String curName,  hitScore, hitPval ;


		try {

			FileInputStream fstream = new FileInputStream(fnmCloverOut1);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			
		
			
			BufferedWriter bwr  = new BufferedWriter( new FileWriter( fnmSigOut1) );
						

			String motifID = new String();
			StringBuffer buffer = new StringBuffer();

			String curGeneKey, curGeneID ;

			lhm1 = parseCloverOutput(br);
			
			
			
			System.out.println("Number of sig motif:" + lhm1.size());
			
			
			Set set = lhm1.entrySet();
            Iterator itr = set.iterator();
			
			//  now write
			
			set = lhm1.entrySet();
            itr = set.iterator();
            while(itr.hasNext()){
                Map.Entry me = (Map.Entry)itr.next();
                String id = (String)me.getKey();
                bwr.write(lhm1.get(id)+"\n");
            }
			
			bwr.close();
		
			br.close(); 			in.close(); 			fstream.close();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}


	}
	
	
	
	LinkedHashMap<String, String> parseCloverOutput(BufferedReader br )
	{
		
		LinkedHashMap<String, String> lhmLocal = new LinkedHashMap<String, String>();
		
		String motifID = new String();
		StringBuffer buffer = new StringBuffer();

		String curGeneKey, curGeneID , strLineBeforeTrim, strLine;
		String hitScore, hitPval ;
		String tmp[];
		
		try {
			
			
			while ( (strLineBeforeTrim = br.readLine() ) != null ) {

				strLine = strLineBeforeTrim.trim();
				if(strLine.length() <4)
					continue; // skip blank lines


				if( !strLine.contains("Raw score"))
				{
					 br.readLine();
					continue; // now start
				}
				br.readLine();/// read the next un-informative line	
					 

				while( (strLineBeforeTrim = br.readLine() ) != null )
				{
					strLine = strLineBeforeTrim.trim();
					if(strLine.length() <4)
						continue; // skip blank lines
					if(strLine.startsWith("*** Motif"))
						break; // end of motif p-value lines

					tmp = ConstantValue.patWhiteSpace.split(strLine );

//					totSplit = tmp.length;
//					totHeadField = totSplit - needToConsiderLast;
	//
//					for(int i=0 ; i< totHeadField ; i++)
//					{
//						motifID.append(tmp[i]+"#");
//					}
//					curName = motifID+"";
//					motifID = null;
//					motifID = new StringBuffer();
	//
//					hitScore= tmp[totSplit - needToConsiderLast] ;  
//					hitPval = tmp[totSplit - needToConsiderLast + 1] ; 
					
					motifID = tmp[0];
					hitScore = tmp[1];
					hitPval = tmp[2];
					

					if( (Double.parseDouble(hitScore) >= 0.0 )&& ( Double.parseDouble(hitPval)<= this.sigValue ) )
					{
						lhmLocal.put(motifID, motifID+"\t"+hitScore + "\t" + hitPval) ;
//						buffer.append(curName+"\t"+hitScore + "\t" + hitPval + "\n") ;
					}
				}

				break;

			} // end of outer while
			
			System.out.println("LOCAL  set has sig motif:" + lhmLocal.size());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return lhmLocal;
		
	}
	
	void selectSubsetCloverMatrix(  String fnmAllMatrix, String fnmSubset)
	{
		
		try {
			
			FileInputStream fstreamProm = new FileInputStream(fnmAllMatrix);
			DataInputStream inProm = new DataInputStream(fstreamProm);
			BufferedReader brProm = new BufferedReader(new InputStreamReader(inProm));

			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnmSubset));
			
			
			StringBuffer finalBuffer = new StringBuffer();
			StringBuffer curBuf = new StringBuffer();
			String curLine;
			String curHeader;
			
			curLine = brProm.readLine();
			curHeader = curLine.substring(1);
			curBuf.append(curLine +"\n");
			
			while( (  curLine = brProm.readLine()) !=null)
			{
				if(curLine.length() < 3)
					continue;
				
				if(curLine.startsWith(">") ){
					
					if( lhm1.containsKey(curHeader)   )
						finalBuffer.append(curBuf+"\n");
					
					curHeader = curLine.substring(1);
					curBuf = null;
					curBuf = new StringBuffer();
					curBuf.append(curLine +"\n");
				}else
				{
					curBuf.append(curLine+"\n");
				}
				
			}
			
			
			bwr.write(finalBuffer+"");
			
			bwr.close();
			brProm.close() ; inProm.close();  fstreamProm.close();
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	void doProcessing()
	{

		/*
		 *  parse clover output to ==> find significant motifs
		 */
		
		parseSigMotifNamePvalue(this.fnmCloverOutput1 , this.fnmSigMotifID);
		
		selectSubsetCloverMatrix(  this.fnmOrigMatrix , this.fnmSigMotifMatrix);
		
		/*
		 *  parse clover output to ==> bed file
		 *  
		 */
		
//		loadPromoterGeneID();
//		parseHit_Bed();
		
		

		/*
		 *  select ONLY sig motif hit 
		 */
		
//		selectHitwithSigMotif_AboveScore();
		
		/*
		 *  Generate hit list GENE ==> TFBS for Abdullah hit map
		 */
		
//		writeGeneTFBSstatistics();

	}
	
	
	public static void main(String[] args) {

		ParseCloverout_SelectMatrix obj = new ParseCloverout_SelectMatrix();
		
		obj.init(args[0] , args[1] , args[2] ,args[3] , args[4]  ) ;
//		obj.init("0.05", "kaustfinal.clover", "nurse.clovermap", "nurse.sig.motifid", "nurse.sig.clover");
		
		obj.doProcessing();
	}

}
