package com.cbrc.hicReanlab;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MatrixToList {
	
	
	String fnmIn= "./ES/nij.chr19"; //  "./ES/uij.chr19";
	
	String fnmOut= fnmIn + ".out";
	
//	LinkedHashMap<Integer, Set<Integer>> lhm_id_set = new LinkedHashMap<Integer, Set<Integer>>() ;
	
	LinkedHashMap<Integer, Set<Integer>> lhm_id_set = new LinkedHashMap<Integer, Set<Integer>>() ;
	
	
	void readLine()
	{
		Vector<String> vect = CommonFunction.readlinesOfAfile(this.fnmIn);
		
		System.out.println( "total line: " + vect.size() );
		
		String curLine="";
		String tmp[];
		
//		int curValue;
		float curValue;
		
		for(int i=0 ; i<vect.size() ;i++)
		{
			
			curLine= vect.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			System.out.println( "total column : " + tmp.length );
			
			Set<Integer> setInteract = new LinkedHashSet<Integer>();
//			Set<Float> setInteract = new LinkedHashSet<Float>();
			
			
			
			
			for( int col=0 ; col < tmp.length ;col++)
			{
				// curValue = Integer.parseInt( tmp[col] );
				curValue = Float.parseFloat( tmp[col] );
				if(curValue != 0 )
				{
					setInteract.add( col+1 );
					
				}
				
				
			} // each column
			
			lhm_id_set.put( i+1 , setInteract) ; 
			
			
		} // each row
		
		
		
		
	}
	
	
	void writeInteraction()
	{
		
		StringBuffer buf = new StringBuffer();
		
		Set set = lhm_id_set.entrySet();
        System.out.println("Total Unique entry:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            
            Integer id = (Integer)me.getKey();
            Set setList = (Set) me.getValue();
            
            
            buf.append(id +"\t"+ setList.size() + "\t" );
            
            buf.append( setList.toString());
            
            buf.append("\n") ;
           
        }

		
		
		CommonFunction.writeContentToFile(this.fnmOut, buf+"");
		
	}
	
	void doProcessing()
	{
	
		readLine();
		writeInteraction();
		
	}
	
	public static void main(String[] args) {
		
		MatrixToList obj = new MatrixToList();
		
		obj.doProcessing();
		
	}

}
