package com.cbrc.hicReanlab;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class GeneToSegment {

	
	
	String fnmInp="refGene.mm9.NM.serial.bed"; // "finalLncRNA.bed"; // "test.bed" ; // "finalLncRNA.bed";
	
	String chrTest="chr1";
	String fnmOut=fnmInp +".segment";
	
	int segSize=40000;
	
	Vector<String> vect = new Vector<String>();
	LinkedHashMap<String, String> lhm_key_val = new LinkedHashMap<String, String>();
	
	
	void doProcessing()
	{
		makeSegment();
//		writeResult();
	}
	
	
	void writeResult()
	{
//		
//		StringBuffer mybuf = new StringBuffer();
//		
//		Set set = lhm_key_val.entrySet();
//        System.out.println("Total Unique entry:" + set.size() ) ;
//        Iterator itr = set.iterator();
//        while(itr.hasNext()){
//
//
//            Map.Entry me = (Map.Entry) itr.next();
//            String id = (String)me.getKey();
//            String info = (String) me.getValue();
//            
//            
//            mybuf.append(info+ "\n");
//           
//        }
//		
//		CommonFunction.writeContentToFile(this.fnmOut, mybuf+"");
		
	}
	
	
	void makeSegment()
	{
		
		vect = CommonFunction.readlinesOfAfile(this.fnmInp);
		
		String tmp[]; 		
		
		String chr,name;
		int start, end;
		
		int segStart, segEnd;
		
		
		StringBuffer buf = new  StringBuffer();
		
		for ( int i=0 ; i < vect.size() ; i++)
		{
			
			System.out.println("working for: " + i);
			
			tmp = ConstantValue.patTab.split(vect.get(i));
			
			chr     = tmp[0];			
			start   = Integer.parseInt( tmp[1] );
			end     = Integer.parseInt( tmp[2] );
			name    = tmp[3];
			
//			System.out.println("start: " + start + " end: "  +end);
			
//			if( !chr.equals(chrTest))
//				continue;
			
			
			segStart = (start / this.segSize)   + 1;
			segEnd   = (end   / this.segSize)   + 1;
			
//			System.out.println("start: " + segStart + " end: "  + segEnd);
			
			StringBuffer bufTmp = new StringBuffer();
			bufTmp.append( name + "," + chr + ",");
			
			
			
			for(int seg=segStart ; seg <= segEnd ; seg++)
			{
				
				if (seg ==segStart)
					bufTmp.append(seg);
				else
					bufTmp.append("," +seg);
				
				
			}
			buf.append(bufTmp + "\n");
			
//			lhm_key_val.put(name, bufTmp+"");
			
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, buf+"");
		
		
		
	}
	
	public static void main(String[] args) {
		
		
		GeneToSegment obj = new GeneToSegment();
		
		int res = 20 / 8;
		System.out.println( res );
		
		obj.doProcessing();
		
	}
	
	
}
