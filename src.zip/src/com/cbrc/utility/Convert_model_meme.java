package com.cbrc.utility;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;
import java.text.DecimalFormat;
import java.text.NumberFormat;


public class Convert_model_meme {

	String fNameIn  ;  
	String fNameOut ; 
	String headerFile;
	
	NumberFormat f ;

	void createHeaderFile( )
	{

		//		MEME version 4
		//
		//		ALPHABET= ACGT
		//
		//		strands: + -
		//
		//		Background letter frequencies
		//		A 0.29182 C 0.20818 G 0.20818 T 0.29182

		String version = "MEME version 4";
		String alphabet = "ALPHABET= ACGT";
		String strands = "strands: + -";
		String bgTile="Background letter frequencies";
		String bgInfo="A 0.25 C 0.25 G 0.25 T 0.25";


		headerFile = version + "\n\n" + alphabet + "\n\n" + strands + "\n\n" + bgTile + "\n\n" + bgInfo+ "\n\n" ;

	}

	void conv_model_To_meme(  String fnmin, String fnmout )
	{

		
		fNameIn  =  fnmin; 
		fNameOut = fnmout;     

		
		f = new DecimalFormat("#0.000000");
		f.setGroupingUsed(false);
		
		
		createHeaderFile();

		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			int motifCount=0;
			int motifLen=0;
			String motifID;
			String motifHeader;
			String motifCommonHeader="letter-probability matrix:";
			String strLine;
			String tmp[];
			Pattern p = Pattern.compile("[ :\\t]+");

			bout.write(headerFile+"\n") ;
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				
				if(strLine.startsWith("*"))
				{
					motifCount++;
					System.out.println("Start work for motif:"+motifCount);
					if(motifCount == 60)
						System.out.println("last");
					motifHeader=null;
					motifID=null;
				}
				strLine = brAllrna.readLine(); // ID
				tmp = p.split(strLine, 2);
				motifID = tmp[1];

				strLine = brAllrna.readLine(); // Consensus

				strLine = brAllrna.readLine(); // length
				tmp = p.split(strLine, 2);
				motifLen = Integer.parseInt(tmp[1] );


				strLine = brAllrna.readLine(); // Threshold
				strLine = brAllrna.readLine(); // Coverage
				strLine = brAllrna.readLine(); // BGCoverage
				strLine = brAllrna.readLine(); // source
				strLine = brAllrna.readLine(); // score


				motifHeader = motifCommonHeader + " alength= "+ 4 + " w= " + motifLen + " nsites= 17 E= 0" ; 


				strLine = brAllrna.readLine(); // A
				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector<Double> pwmA = new Vector<Double>();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmA.add(val);				
				}


				strLine = brAllrna.readLine(); // C
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector<Double> pwmC = new Vector<Double>();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmC.add(val);				
				}
				
				strLine = brAllrna.readLine(); // G
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector<Double> pwmG = new Vector<Double>();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmG.add(val);				
				}
				
				strLine = brAllrna.readLine(); // T
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector<Double> pwmT = new Vector<Double>();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmT.add(val);				
				}
				
				
				// normalize in usual method
				
				Vector<Double> pwmALL = new Vector<Double>();
				for(int i=0; i<pwmA.size() ;i++)
				{
					pwmALL.add( pwmA.get(i) +  pwmC.get(i) + pwmG.get(i) + pwmT.get(i)   );
				}
				
				for(int i=0; i<pwmA.size() ;i++)
				{
					 pwmA.set( i,  pwmA.get(i)/pwmALL.get(i)  ) ;
					 pwmC.set( i,  pwmC.get(i)/pwmALL.get(i)  ) ;
					 pwmG.set( i,  pwmG.get(i)/pwmALL.get(i)  ) ;
					 pwmT.set(i,  pwmT.get(i)/pwmALL.get(i)  ) ;
			
				}
				
				
				int len = pwmT.size();

				bout.write("MOTIF " + motifID +"\n");
				bout.write(motifHeader + "\n");

				for(int i=0;  i<len ;i++)
				{
					String a = f.format(pwmA.get(i) ); 
					String c = f.format(pwmC.get(i) ); 
					String g = f.format(pwmG.get(i) ); 
					String t = f.format(pwmT.get(i) ); 
					
					bout.write(a+ "\t" +c + "\t" + g  + "\t" + t + "\n" ) ;
				}

				bout.write("\n");

			}
			
			System.out.println("Tot motif:"+motifCount);

			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}finally
		{

		}

	}

	public static void main(String args[])
	{

		Convert_model_meme obj = new Convert_model_meme();

//		obj.conv_model_To_meme(  "topNCPFMminus05rankexamplar.model"  ,  "topNCPFMminus05rankexamplar.meme" );
		
//		obj.conv_model_To_meme(  "topPPFM.model"  ,  "topPPFM.meme" );
//		obj.conv_model_To_meme(  "topNPPFM.model"  ,  "topNPPFM.meme" );
		
//		obj.conv_model_To_meme(  "topCPFM.model"  ,  "topCPFM.meme" );
//		obj.conv_model_To_meme(  "topNCPFM.model"  ,  "topNCPFM.meme" );
		
		
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromC.stat.selected", "/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromC.stat.selected.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromNC.stat.selected", "/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromNC.stat.selected.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCwithrepeat/allCPFM.model", "/home/tanviralam/Desktop/CNCwithrepeat/allCPFM.model.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCwithrepeat/allNCPFM.model", "/home/tanviralam/Desktop/CNCwithrepeat/allNCPFM.model.meme");	
		

//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromC.stat.selected", "/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromC.stat.selected.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromNC.stat.selected", "/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromNC.stat.selected.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCnorepeat/allCPFM.model", "/home/tanviralam/Desktop/CNCnorepeat/allCPFM.model.meme");	
//		obj.conv_model_To_meme("/home/tanviralam/Desktop/CNCnorepeat/allNCPFM.model", "/home/tanviralam/Desktop/CNCnorepeat/allNCPFM.model.meme");	

		
		obj.conv_model_To_meme(args[0], args[1]);
//		obj.conv_model_To_meme(  "allNCPFM.model"  ,  "allNCPFM.meme" );
//		obj.conv_model_To_meme(  "rankDMFfromC.stat.selected"  ,  "selectedCPFM.meme" );
		
	}


}


