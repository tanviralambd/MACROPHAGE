package com.cbrc.utility;




import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.*;
import java.util.regex.Pattern;

public class TomtomToGO {



	public void checkComon( String fNameIn1 , String fNameIn2)
	{
		try {

			FileInputStream fstream1 = new FileInputStream(fNameIn1 );
			DataInputStream in1 = new DataInputStream(fstream1);
			BufferedReader brAllrna1 = new BufferedReader(new InputStreamReader(in1));


			FileInputStream fstream2 = new FileInputStream(fNameIn2 );
			DataInputStream in2 = new DataInputStream(fstream2);
			BufferedReader brAllrna2 = new BufferedReader(new InputStreamReader(in2 ));

			//			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet1 = new LinkedHashSet<String>();
			Set<String> mySet2 = new LinkedHashSet<String>();

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;

			while ((strLine = brAllrna1.readLine()) != null) {
				mySet1.add( strLine );
			}

			while ((strLine = brAllrna2.readLine()) != null) {
				mySet2.add( strLine );
			}

			Set<String > uni =  new LinkedHashSet<String>(mySet1);
			uni.addAll(mySet2) ;
			System.out.println( " Uni size: " + uni.size()) ; 

			Set<String > inters = new LinkedHashSet<String>(mySet1);
			inters.retainAll(mySet2);
			System.out.println( " Intersect size: " + inters.size())  ;


			//			bout.close();

			brAllrna1.close();
			in1.close();
			fstream1.close();

			brAllrna2.close();
			in2.close();
			fstream2.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public void writeTomtomTabDelimitted( String fNameIn , String fNameOut)
	{
		Pattern pat = Pattern.compile("[ \\s]+");
		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));
			String strLine;
			String tmp[];
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;			
				tmp = pat.split(strLine);				
				for(int i=0 ; i<tmp.length ; i++)
				{
					bout.write(tmp[i]+"\t");
				}
				bout.write("\n");
			}


			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	public void writeUniprotID( String fNameIn , String fNameOut)
	{
		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet = new LinkedHashSet<String>();

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;
			
			brAllrna.readLine(); // SKIP HEADER
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;

				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");

				while (stringTokenizer.hasMoreElements()) {

					cur = stringTokenizer.nextElement().toString() ;				
					i++;

					if(i==2)
						break;
				}

				indexUndScr = cur.lastIndexOf('_');
				mySet.add(cur.substring(0, indexUndScr));
			}

			Iterator<String> itr = mySet.iterator();
			while( itr.hasNext())
			{
				bout.write(  itr.next() +"\n");
			}

					

			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	
	public void writeQvalueSortedUniprotID( String fNameIn , String fNameOut)
	{
		try {
			Pattern patTab = Pattern.compile("[\\s]+");
			
			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet = new LinkedHashSet<String>();

			
			HashMap<String,Myclass> hMap = new HashMap<String,Myclass>();
			ValueComparator vcomp =  new ValueComparator(hMap);
			TreeMap<String,Myclass> sorted_map = new TreeMap(vcomp);
			
			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;
			String curTF = null;
			String curQval=null;
			String curKey = null;
			
			brAllrna.readLine(); // SKIP HEADER
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;
				tmp = patTab.split(strLine, 10);
				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");

				
				cur = tmp[1];
				indexUndScr = cur.lastIndexOf('_');
				curTF =  cur.substring(0, indexUndScr) ;
				
				curQval = tmp[5];
				
				
				curKey = genKeyName (curTF);
				
				if(hMap.containsKey(curKey))
				{
					Double d = hMap.get(curKey).getqVal();
					// update to  the smallest q-Value
					if(Double.parseDouble(curQval)<d)
						hMap.put( curKey ,    new Myclass(Double.parseDouble(curQval))) ;
				}else
				{
					hMap.put( curKey ,    new Myclass(Double.parseDouble(curQval))) ;
				}
			}

			for (String key:hMap.keySet()) {
				sorted_map.put(key, hMap.get(key));
			}
			
			Set set = sorted_map.entrySet(); 
			Iterator itr = set.iterator(); 
			while(itr.hasNext()) { 
				Map.Entry me = (Map.Entry)itr.next(); 
				bout.write( me.getKey() + "\t "  + ( (Myclass)me.getValue() ).getqVal()+ "\n" ); 
			} 		
			
			
//			Iterator<String> itr = mySet.iterator();
//			while( itr.hasNext())
//			{
//				bout.write(  itr.next() +"\n");
//			}

			/////////////////////////
			

//			for (int i=0;i<26;i++)
//			{					
//				char c =  (char)(65+i) ;
//				String s =Character.toString(c);
//				hMap.put( s,    new Myclass(myArrCount[i], i+65)) ;
//			}



//			System.out.println("Now building sortedmap ... ");
	
//			for (String key:hMap.keySet()) {
//				sorted_map.put(key, hMap.get(key));
//			}
//			System.out.println("End building sortedmap  ");

		// ******** IT WILL NOT WORK. STRANGE ************	
//			for (String key : sorted_map.keySet()) {
//			System.out.println("key" + key );
//			System.out.println("key/value: " + key + "/"+    ( (Myclass)sorted_map.get(key)  ).getLetter() );
//			}
			
//			int hit=0;
//			Set set = sorted_map.entrySet(); 
//			Iterator i = set.iterator(); 
//			while(i.hasNext()) { 
//				Map.Entry me = (Map.Entry)i.next(); 
//				hit = ( (Myclass)me.getValue() ).getCount() ;
//				if(hit>0)
//				System.out.println(me.getKey() + " "  +  hit ); 
//			} 		
			
			///////////////////////////////

			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	String genKeyName(String tmp)
	{
		return tmp+"_HUMAN";
	}
	
	public void writeTopTFHocomocoList(String fNameIn , String fNameOut)
	{


		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet = new LinkedHashSet<String>();

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;

			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;

				cur = strLine;

				indexUndScr = cur.lastIndexOf('_');
				mySet.add(cur.substring(0, indexUndScr));
			}

			Iterator<String> itr = mySet.iterator();
			while( itr.hasNext())
			{
				bout.write(  itr.next() +"\n");
			}


			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void doProcessing(String tomtomOut, String tomtomOutTab, String tomtomOutTF)
	{
		
		writeTomtomTabDelimitted(tomtomOut , tomtomOutTab);
//		writeUniprotID(tomtomOut, tomtomOutTF );
		
		writeQvalueSortedUniprotID( tomtomOut, tomtomOutTF );
		
		
//		checkComon("tomtomC_TF.txt", "tomtomNC_TF.txt") ;

		//		writeUniprotID("tomtomP.txt" , "tomtomP_TF.txt");
		//		writeUniprotID("tomtomNP.txt" , "tomtomNP_TF.txt");	
		//		checkComon("tomtomP_TF.txt", "tomtomNP_TF.txt") ;


		//		writeTopTFHocomocoList("rankTFBSfromC.name" , "rankTFBSfromC_TF.txt");
		//		writeTopTFHocomocoList("rankTFBSfromNC.name" , "rankTFBSfromNC_TF.txt");	
		//		checkComon("rankTFBSfromC_TF.txt", "rankTFBSfromNC_TF.txt") ;

	}

	
	class Myclass 
	{
		double  qVal;
		
		Myclass(double qV)
		{
			this.qVal = qV;
		}

		public double getqVal() {
			return qVal;
		}

		public void setqVal(double qVal) {
			this.qVal = qVal;
		}
		

	}
	class ValueComparator implements Comparator {

		Map base;
		public ValueComparator(Map base) {
			this.base = base;
		}

		public int compare(Object a, Object b) {
			
			Myclass obj1 = (Myclass) base.get(a);
			Myclass obj2 = (Myclass) base.get(b);
			
			if( obj1.getqVal() > obj2.getqVal()    ) {
				return 1;
			} else {
				return -1;
			}
		}
		
		
	}
	
	
	public static void main(String[] args) {

		TomtomToGO obj = new TomtomToGO();
		
//		obj.doProcessing("tomtomC.txt" , "tomtomC_tab.txt" ,"tomtomC_TF.txt" );
//		obj.doProcessing("tomtomNC.txt" , "tomtomNC_tab.txt" ,"tomtomNC_TF.txt" );
		
		obj.doProcessing(args[0], args[1], args[2]) ;
		
	}

}
