package com.cbrc.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import com.cbrc.constant.ConstantValue;

public class Encode_Hocomoco_mapping {


	String fnmEnc;
	String fnmHoc;
	String fnmMapping;


	/*
	 *  KEY - uniprot name
	 *  VAL - TF name
	 */
	LinkedHashMap<String, String> lhmEncode = new LinkedHashMap<String, String>();

	/*
	 *  KEY - uniprot name
	 *  VAL - uniprot name
	 */
	LinkedHashMap<String, String> lhmHoco = new LinkedHashMap<String, String>();


	void loadEncode()
	{
		try {
			FileInputStream fstream = new FileInputStream(fnmEnc);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;
			String tmp[];

			String curKey,curVal;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <2)
					continue;

				tmp = ConstantValue.patWhiteSpace.split(strLine);


				//				curKey = ConstantValue.patUNIPROT.split( tmp[1] )[0];
				curKey = tmp[1];

				if( lhmEncode.containsKey( curKey )){
					curVal = lhmEncode.get(curKey);
					lhmEncode.put(curKey, curVal + "," + tmp[0]);
				}else
				{
					lhmEncode.put(curKey, tmp[0]);
				}

			}
			System.out.println("Total Unique encode entry:" + lhmEncode.size() ) ;

			br.close();
			in.close();
			fstream.close();

		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	void loadHocomoco()
	{

		try {
			FileInputStream fstream = new FileInputStream(fnmHoc);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;
			String tmp[];

			String curKey,curVal;
			String holder;
			int totalTF;
			int prefixInd;
			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				//				curKey = tmp[0];
				curVal = tmp[0];
				prefixInd = curVal.indexOf('!');
				if(prefixInd <0)
				{
					prefixInd = curVal.indexOf('_');
				}

				tmp = ConstantValue.patHOCOMOCO.split(curVal.substring(0,prefixInd));
				totalTF = tmp.length ;
				for(int i=0 ; i<totalTF ; i++)
				{
					curKey = tmp[i]+ ConstantValue.hocomocoPostFix;

					if(lhmHoco.containsKey(curKey))
					{
						holder = lhmHoco.get(curKey);
						lhmHoco.put(curKey, holder+"," + curVal) ;
					}else{
						lhmHoco.put(curKey, curVal );
					}
				}


//				if( lhmHoco.containsKey(curKey)){
//
//				}else
//				{
//					lhmHoco.put(curKey, curVal);
//				}

			}

			System.out.println("Total Unique hocomoco entry:" + lhmHoco.size() ) ;

			br.close();
			in.close();
			fstream.close();

		}catch (Exception e) {
			e.printStackTrace();
		}
	}


	void printEnc_Hocomoco()
	{
		try {
			String tmp[];
			BufferedWriter bout = new BufferedWriter(new FileWriter(this.fnmMapping));
			StringBuffer buffer = new StringBuffer();
			Set set = lhmEncode.entrySet();

			Iterator itr = set.iterator();
			while(itr.hasNext()){
				Map.Entry me = (Map.Entry) itr.next();
				String uniprot = (String)me.getKey();
				String tfName = (String) me.getValue();


		


				buffer.append(tfName  + "\t" + uniprot + "\t" + lhmHoco.get(uniprot) + "\n" );
			}

			bout.write(buffer+"");		
			bout.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void doProcessing()
	{
		loadEncode();
		loadHocomoco();

		printEnc_Hocomoco();
	}

	void init(String fnmEnc, String fnmHoc, String fnmOut)
	{
		this.fnmEnc = fnmEnc;
		this.fnmHoc = fnmHoc;
		this.fnmMapping = fnmOut;
	}

	public static void main(String[] args) {

		Encode_Hocomoco_mapping obj = new Encode_Hocomoco_mapping();
		obj.init("encode_uniprot.txt", " hocomoco.txt", "encode_hocomoco.map");
		obj.doProcessing();
	}
}
