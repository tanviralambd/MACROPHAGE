package com.cbrc.utility;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;

import com.cbrc.bean.MotifDMF;
import com.cbrc.bean.MotifHOCOMOCO;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

//import edu.rit.pj.Comm;

public class LoadSelectedModelHocomoco {

	static Vector<MotifHOCOMOCO> vecHOCOMOCOmotif =  new Vector<MotifHOCOMOCO>();  



	public static void main(String[] args) {
		
		/*
		 *  id_Prefix_OR_full = 1  (only prefix ; ; used with human FOXP_HUMAN ); // For ENCODE overlap ChIP seq
		 *  id_Prefix_OR_full = 2  (check full name ; used with human FOXP_si );  // For selecting original motif
		 */
		int id_Prefix_OR_full = 2;
		
		
		loadModelsSelected("motifidOnlyDnase.txt", "tfbsP0005.model", "tfbsP0005SelectedCPS.model" , id_Prefix_OR_full);
//		loadModelsSelected("motifidChipSeqCPS.txt", "tfbsP0005.model", "tfbsP0005SelectedCPS.model" , id_Prefix_OR_full);
		
//		loadModelsSelected("motifidChipSeqREFPS.txt", "tfbsP0005.model", "tfbsP0005SelectedREFPS.model" , id_Prefix_OR_full);

		
	}


	/*
	 *  load all selected model by ID and print into a separate file
	 *   id.txt tfbsP0005.model  tfbsP0005Selected.model
	 */
	public static Vector<MotifHOCOMOCO> loadModelsSelected( String fnmID , String fnameAllMotif , String fnmOut , int choice)
	{
		vecHOCOMOCOmotif =  null;  
		vecHOCOMOCOmotif =  new Vector<MotifHOCOMOCO>();  
		
		
		doParsingSelected( fnmID ,  fnameAllMotif , fnmOut , choice);

		return vecHOCOMOCOmotif;
	}

	/*
	 *  id_Prefix_OR_full = 1  (only prefix ; ; used with human FOXP_HUMAN ); // For ENCODE overlap ChIP seq
	 *  id_Prefix_OR_full = 2  (check full name ; used with human FOXP_si );  // For selecting original motif
	 */
	static Vector<MotifHOCOMOCO> doParsingSelected( String fnameID , String fnameMotif , String fnmOut , int id_Prefix_OR_full)
	{

		String fnmIDselected="selected.id";
		
		 // 1 - prefix , 2- full 

		// Name of the ID / Prefix of  some motif
		LinkedHashMap<String, String> lhmMotifID = new LinkedHashMap<String, String>();
		int indexUnderscore=0;
		try {
			FileInputStream fstream = new FileInputStream(fnameID);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;


			while ((strLine = br.readLine()) != null) {

				if( strLine.length() < 3)
				{
					continue;
				}

				if(id_Prefix_OR_full == 1){
					/*
					 *  ONLY PREFIX BEFORE _HUMAN
					 */
					indexUnderscore = strLine.indexOf('_');
					lhmMotifID.put(strLine.substring(0, indexUnderscore) ,  "");
				}else
				{
					/*
					 *  FULL ID HOX_FI , HOX_SI are different
					 * 
					 */
					lhmMotifID.put( strLine ,  strLine);
				}




			}

			br.close();
			in.close();
			fstream.close();

		}catch (Exception e) {
			e.printStackTrace();
		}


		// all Hocomoco Motif
		vecHOCOMOCOmotif = null; 
		vecHOCOMOCOmotif = new Vector<MotifHOCOMOCO>();



		int motifCount=0;
		Pattern pat = Pattern.compile("[ \\s]+");
		String tmp, prev;

		try {
			FileInputStream fstream = new FileInputStream(fnameMotif);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnmOut));
			StringBuffer buf = new StringBuffer();
			StringBuffer bufID = new StringBuffer();

			String strLine;
			double thr;
			String id; 
			String sThr;
			String pval;
			String len;
			String idPrefix;

			while ((strLine = br.readLine()) != null) {
				if (strLine.startsWith("*")) {
					motifCount++;
					continue;
				}
				

				id =  pat.split( strLine)[1] ; // id
				len = pat.split( br.readLine() )[1]; // len
				pval = pat.split(br.readLine()  )[1]; // p-value
				sThr =  pat.split(br.readLine())[1] ; // threshold
				thr = Double.parseDouble(  sThr) ; // 

				strLine = br.readLine() ; //  A
				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector pwmA = new Vector();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmA.add(val);                 
				}
				strLine = br.readLine() ; //  C
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector pwmC = new Vector();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmC.add(val);                 
				}
				strLine = br.readLine() ; // G
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector pwmG = new Vector();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmG.add(val);                 
				}
				strLine = br.readLine() ; // T
				stringTokenizer = new StringTokenizer(strLine, " \t");
				Vector pwmT = new Vector();
				while (stringTokenizer.hasMoreElements()) {
					Double val = Double.parseDouble(stringTokenizer.nextElement().toString() );
					pwmT.add(val);                 
				}

				if(id_Prefix_OR_full == 1)
				{
					/*
					 *  PREFIX OF _HUMAN BASED
					 */
					indexUnderscore = id.indexOf('_');
					idPrefix =  id.substring(0, indexUnderscore);
				}else
				{
					/*
					 *  NO PREFIX, WHOLE ID
					 */
					idPrefix = id;
				}




				if (  lhmMotifID.containsKey(idPrefix) )
				{
					vecHOCOMOCOmotif.add( new MotifHOCOMOCO( id ,  pval ,  thr, pwmA, pwmC, pwmG, pwmT)  );
					System.out.println( "added:"+ (vecHOCOMOCOmotif.size())+ id);

					tmp = ( (MotifHOCOMOCO)vecHOCOMOCOmotif.get(vecHOCOMOCOmotif.size()-1) ).toStringHOCOMOCOmotif()   ;
					prev= lhmMotifID.get(idPrefix);
//					if(prev.length() >3){
//					
//						lhmMotifID.put(idPrefix, prev+"\n"+tmp);
//					}else
//					{
//						lhmMotifID.put(idPrefix, tmp);
//					}
					
					lhmMotifID.put(idPrefix, tmp);
					//					buf.append( tmp +"\n" ) ;
				}



			}
			System.out.println( "No motif in vector:" + vecHOCOMOCOmotif.size());


//			Set set = lhmMotifID.entrySet();
//			System.out.println("Total Unique entry:" + set.size() ) ;
//			Iterator itr = set.iterator();
//			while(itr.hasNext()){
//				Map.Entry me = (Map.Entry) itr.next();
//				String motifid = (String)me.getKey();
//				String matrix = (String) me.getValue();
//				buf.append( matrix +"\n" ) ;
//			}

			for(int tanv=0; tanv<vecHOCOMOCOmotif.size();tanv++)
			{
				buf.append(vecHOCOMOCOmotif.get(tanv).toStringHOCOMOCOmotif()+"\n");
				bufID.append(vecHOCOMOCOmotif.get(tanv).getMotifid()+"\n");
			}
			
			CommonFunction.writeContentToFile(fnmIDselected, bufID+"");
			
			bwr.write(buf+"");
			bwr.close();
			br.close();			in.close(); 			fstream.close();

		} catch (Exception e) {

			e.printStackTrace();
		}
		return vecHOCOMOCOmotif;



	}


}
