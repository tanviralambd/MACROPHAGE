package com.cbrc.utility;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Vector;

import com.cbrc.bean.BedFormat;
import com.cbrc.common.CommonFunction;

public class Convert_Bed_GFF {

	String fnameBED;
	String fnameGFF;
	
	void init(String fnmB, String fnmG)
	{
		this.fnameBED = fnmB;
		this.fnameGFF = fnmG;
	}
	
	void doProcessing()
	{
		
		Vector<BedFormat> vectBed = CommonFunction.readBedfile(this.fnameBED);
		
		String group;
		String strandX=".";
		StringBuffer buffer = new StringBuffer();
		
		for(int i=0 ; i<vectBed.size() ; i++)
		{
			BedFormat bNow = vectBed.get(i);
			group = bNow.getChrom() ;
			buffer.append( bNow.getChrom() +"\t"+ "peak" + "\t"+"ChIPSeq"+ "\t"+ bNow.getStart()  + "\t" + bNow.getEnd() + "\t"+ bNow.getScore() +"\t"+ strandX + "\t"+ "."+ "\t"+ group  +"\n");
			
		}
		
		
		try {
		
			BufferedWriter bwr = new BufferedWriter(new FileWriter(this.fnameGFF));
			bwr.write(buffer+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static void main(String[] args) {
		
		Convert_Bed_GFF obj = new Convert_Bed_GFF();
		obj.init("/home/KAUST/alamt/CNC/Track/data/GATA3.withname.bed", "/home/KAUST/alamt/CNC/Track/data/GATA3.withname.gff");
		obj.doProcessing();
		
	}
	
}
