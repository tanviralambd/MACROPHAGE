package com.cbrc.utility;




import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.*;
import java.util.regex.Pattern;

import com.cbrc.bean.MotifDMF;
import com.cbrc.common.CommonFunction;
import com.cbrc.common.LoadModelDMF;
import com.cbrc.constant.ConstantValue;


/*
 *  FIND MOST SIMILAR MATCH OF A KNOWN TFBS motif
 *  take 1 match per KNOWN TFBS
 */
public class TomtomToGOUsingRanking {

	Vector<MotifDMF> vecDMFmotif ;
	/*
	 *  key    --> TFid
	 *  value --> DMFmotif
	 */
	LinkedHashMap<String, MyclassTF_dmfMotif> lhMapResult = new LinkedHashMap<String, MyclassTF_dmfMotif>();
	/*
	 *  key    ==> DMFID
	 *  value ==> DMVmotif
	 */
	LinkedHashMap<String, MotifDMF> lhmDMFmotif = new LinkedHashMap<String, MotifDMF>();;

	double simThr;
	
	
	public void writeTomtomTabDelimitted( String fNameIn , String fNameOut)
	{
		Pattern pat = Pattern.compile("[ \\s]+");
		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));
			String strLine;
			String tmp[];
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;			
				tmp = pat.split(strLine);				
				for(int i=0 ; i<tmp.length ; i++)
				{
					bout.write(tmp[i]+"\t");
				}
				bout.write("\n");
			}


			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	public void writeUniprotID( String fNameIn , String fNameOut)
	{
		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet = new LinkedHashSet<String>();

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;

			brAllrna.readLine(); // SKIP HEADER
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;

				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");

				while (stringTokenizer.hasMoreElements()) {

					cur = stringTokenizer.nextElement().toString() ;				
					i++;

					if(i==2)
						break;
				}

				indexUndScr = cur.lastIndexOf('_');
				mySet.add(cur.substring(0, indexUndScr));
			}

			Iterator<String> itr = mySet.iterator();
			while( itr.hasNext())
			{
				bout.write(  itr.next() +"\n");
			}



			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


    class ValueComparator implements Comparator {

        LinkedHashMap  base;
        public ValueComparator(LinkedHashMap hMap) {
            this.base = hMap;
        }

        public int compare(Object a, Object b) {

        	MyclassTF_dmfMotif obj1 = (MyclassTF_dmfMotif) base.get(a);
        	MyclassTF_dmfMotif obj2 = (MyclassTF_dmfMotif) base.get(b);

            if( obj1.getMotif().getDistanceValue()  > obj2.getMotif().getDistanceValue()    ) {
                return 1;
            }  else {
            	
            	 if( obj1.getMotif().getDistanceValue()  < obj2.getMotif().getDistanceValue()    )
            	 {
            		 return -1;
            	 }
            	// equal, so check qVal
            	 if( obj1.getQvalue()  >  obj2.getQvalue()    )
            		 return 1;
            	 else
            		 return -11;
            }
        }

    }

    public class MyclassTF_dmfMotif
    {
    	double pvalue;
    	double evalue;      
		double qvalue; 
		MotifDMF  motif;
        
        public MyclassTF_dmfMotif(double pvalue, double evalue, double qvalue,
        		MotifDMF motif) {
			super();
			this.pvalue = pvalue;
			this.evalue = evalue;
			this.qvalue = qvalue;
			this.motif = motif;
		}
//		public MyclassTF_dmfMotif( double qvalue, DMFmotif motif) {
//            super();
//            this.qvalue = qvalue;
//            this.motif = motif;
//        }
		public double getQvalue() {
			return qvalue;
		}
		public void setQvalue(double qvalue) {
			this.qvalue = qvalue;
		}
		public MotifDMF getMotif() {
			return motif;
		}
		public void setMotif(MotifDMF motif) {
			this.motif = motif;
		}
		public double getPvalue() {
			return pvalue;
		}
		public void setPvalue(double pvalue) {
			this.pvalue = pvalue;
		}
		public double getEvalue() {
			return evalue;
		}
		public void setEvalue(double evalue) {
			this.evalue = evalue;
		}

     }
    
   	public void writeRankingBasedUniprotID( String fNameIn , String fNameOut)
	{
		try {
			Pattern patTab = Pattern.compile("[\\s]+");

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;
			String curTF = null;
			String curDMFID = null;
			
			Double curPval=null;
			Double curEval=null;
			Double curQval=null;
			String curKeyTF = null;

			brAllrna.readLine(); // SKIP HEADER
			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;
				tmp = patTab.split(strLine, 10);
				StringTokenizer stringTokenizer = new StringTokenizer(strLine, " \t");

				curDMFID = tmp[0];

				cur = tmp[1];
				indexUndScr = cur.lastIndexOf('_') ;
				curTF = cur ; // cur.substring(0, indexUndScr) ; 

				curPval = Double.parseDouble(tmp[3]);
				curEval = Double.parseDouble(tmp[4]);
				curQval = Double.parseDouble( tmp[5] );

				curKeyTF =  curTF ; //genKeyName (curTF);

				if(lhMapResult.containsKey(curKeyTF))
				{
					MyclassTF_dmfMotif existingDMF = lhMapResult.get(curKeyTF);
					MotifDMF newDMF= lhmDMFmotif.get(curDMFID );
					
					
//					// update to  the DMFID with HIGHEST RANKING
//					if( (newDMF !=null)  &&  ( existingDMF  != null)  )
//					{
//						if(  newDMF.getDistanceValue() <    existingDMF.getMotif().getDistanceValue() )
//						{
//							lhMapTF.put( curKeyTF ,    new MyclassTF_dmfMotif( Double.parseDouble(curQval ),  lhmDMFmotif.get( curDMFID )  )  ) ;
//						}						
//					}
					
					// update to  the DMFID with HIGHEST Q-VALUE SIMILARITY
					if( (newDMF !=null)  &&  ( existingDMF  != null)  )
					{
						if(  curPval <    existingDMF.getQvalue() )
						{
							lhMapResult.put( curKeyTF ,    new MyclassTF_dmfMotif( curPval, curEval, curQval, lhmDMFmotif.get( curDMFID )  )  ) ;
						}						
					}				
					
				}else
				{					
					lhMapResult.put( curKeyTF ,   new MyclassTF_dmfMotif( curPval , curEval, curQval, lhmDMFmotif.get( curDMFID )  )   ) ;
				}
			}

			
			/*
			 *  now sort based on Rankdistance
			 */
			
//	         2.  // NOW SORTING IS DONE
			ValueComparator vcomp =  new ValueComparator(lhMapResult);
			TreeMap sorted_map = new TreeMap(vcomp);
	        for (String key:lhMapResult.keySet()) {
	            sorted_map.put(key, lhMapResult.get(key));
	        }
			
			
			/*
			 *  now just write
			 */
			StringBuffer buffer = new StringBuffer();
			String header="TFid\tDenovoMotifID\tpValueSimilarity\tqValueSimilarity\tpValueOverrepresentation\tDistancefromIdealPoint\n" ;
			buffer.append(header);
			
			Set set = sorted_map.entrySet(); 
			Iterator itr = set.iterator(); 
			while(itr.hasNext()) { 
				Map.Entry me = (Map.Entry)itr.next(); 
				MyclassTF_dmfMotif now = (MyclassTF_dmfMotif) me.getValue() ;
				if(now !=null)
				{
					if ( now.getQvalue() <= simThr)
						buffer.append( me.getKey() + "\t"  + ((MotifDMF)now.getMotif()).getMotifid() + "\t" + now.getPvalue()+  "\t" + now.getQvalue()+"\t"+ CommonFunction.formatterScientific.format(		((MotifDMF)now.getMotif()).getScore()  )+ "\t" + ((MotifDMF)now.getMotif()).getDistanceValue()+ "\n" ); 
				} 		
			}
			bout.write(buffer+"");

			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}




	String genKeyName(String tmp)
	{
		return tmp+"_HUMAN";
	}

	public void writeTopTFHocomocoList(String fNameIn , String fNameOut)
	{


		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bout = new BufferedWriter(new FileWriter(fNameOut));

			Set<String> mySet = new LinkedHashSet<String>();

			int i=0;
			int indexUndScr;
			String strLine;
			String tmp[];
			String cur=null;

			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;
				i = 0;

				cur = strLine;

				indexUndScr = cur.lastIndexOf('_');
				mySet.add(cur.substring(0, indexUndScr));
			}

			Iterator<String> itr = mySet.iterator();
			while( itr.hasNext())
			{
				bout.write(  itr.next() +"\n");
			}


			bout.close();
			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}



	public void doProcessing(String tomtomOut, String tomtomOutTab, String tomtomOutTF , String fnameModel, String  xs, String ys , double simT)
	{
		this.simThr = simT;
		 double x = Double.parseDouble(xs);
		 double y = Double.parseDouble(ys);
		writeTomtomTabDelimitted(tomtomOut , tomtomOutTab);
		
		// previous version just check qvalue. NOT USED ANY MORE
		//		writeUniprotID(tomtomOut, tomtomOutTF );

		vecDMFmotif = LoadModelDMF.loadModels_WithDistance( fnameModel ,x , y);
		for(int i=0 ; i< vecDMFmotif.size()  ;i++)
		{
			lhmDMFmotif.put(vecDMFmotif.get(i).getMotifid(), vecDMFmotif.get(i)) ;
		}
		writeRankingBasedUniprotID( tomtomOut, tomtomOutTF );



	}


	public static void main(String[] args) {

		TomtomToGOUsingRanking obj = new TomtomToGOUsingRanking();

//		String myfold = ConstantValue.filePrefixLinux;
//		String tomtomoutput=    myfold +  "tomtomC.txt";
//		String model=  myfold + "allCPFM.model";	 //   "test.model"; //
//		String tab = myfold + "tomtomC_tab.txt"  ;
//		String matchRank = myfold + "tomtomC_TF.txt";	
//		obj.doProcessing( tomtomoutput ,  tab , matchRank , model , "1.0" , "0.0" );
		
//		obj.doProcessing("tomtomC.txt" , "tomtomC_tab.txt" ,"tomtomC_TF.txt" , "allCPFM.model" , "1.0" , "0.0" );	
//		obj.doProcessing("tomtomNC.txt" , "tomtomNC_tab.txt" ,"tomtomNC_TF.txt" , "allNCPFM.model" , "0.0" , "1.0" );
		
//		obj.doProcessing("tomtomC2013.txt" , "tomtomC2013_tab.txt" ,"tomtomC2013_TF.txt" , "allPos.nonredundant.model" , "1.0" , "0.0" , 0.05 );
//		obj.doProcessing("tomtomNC2013.txt" , "tomtomNC2013_tab.txt" ,"tomtomNC2013_TF.txt" , "allNeg.nonredundant.model" , "0.0" , "1.0" , 0.05 );
		obj.doProcessing(args[0], args[1], args[2] , args[3] , args[4] , args[5] , Double.parseDouble(args[6]) ) ;
		
//		CommonFunction.doAllSetOperation("tomtomC2013_TF.txt", "tomtomNC2013_TF.txt");
		
//		int i  = 30217541;
//		System.out.println(i);
//		System.out.println( CommonFunction.callFisherExactTest(3028499 ,	33949501	,16080459	,30217541) ); 
//		System.out.println( CommonFunction.callFisherExactTest(1 ,	7 , 4	,  4) ); 
	}

}

