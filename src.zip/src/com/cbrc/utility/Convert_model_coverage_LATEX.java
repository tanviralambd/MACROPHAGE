package com.cbrc.utility;



import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;
import java.text.DecimalFormat;
import java.text.NumberFormat;


public class Convert_model_coverage_LATEX {

	String fNameIn  ;  
	String fNameOut ; 

	NumberFormat f ;
	void Convert_model_coverage_LATEX(  String fnmin, String fnmout )
	{
		fNameIn  =  fnmin; 
		fNameOut = fnmout;     
		f = new DecimalFormat("#0.000000");
		f.setGroupingUsed(false);

		try {

			FileInputStream fstream = new FileInputStream(fNameIn);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brAllrna = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bwr = new BufferedWriter(new FileWriter(fNameOut));


			StringBuffer buffer = new StringBuffer();
			int motifCount=0;
			int motifLen=0;
			String motifID;
			String motifHeader;
			String motifCommonHeader="letter-probability matrix:";
			String strLine;
			String tmp[];
			StringBuffer bufferLine=new StringBuffer();
			Pattern pat = Pattern.compile("[ :\\s]+");


			while ((strLine = brAllrna.readLine()) != null) {

				if( strLine.length() <5)
					continue;

				if(strLine.startsWith("*"))
				{
					motifCount++;
					System.out.println("Start work for motif:"+motifCount);

					motifHeader=null;
					motifID=null;
					bufferLine = new StringBuffer();
				}
				strLine = brAllrna.readLine(); // ID
				tmp = pat.split(strLine, 2);
				motifID = tmp[1];
				bufferLine.append(tmp[1] + "\t");

				strLine = brAllrna.readLine(); // Consensus

				strLine = brAllrna.readLine(); // length
				tmp = pat.split(strLine, 2);
				motifLen = Integer.parseInt(tmp[1] );


				strLine = brAllrna.readLine(); // Threshold

				strLine = brAllrna.readLine(); // Coverage
				tmp = pat.split(strLine, 2);
				bufferLine.append(tmp[1] + "\t");

				strLine = brAllrna.readLine(); // BGCoverage
				tmp = pat.split(strLine, 2);
				bufferLine.append(tmp[1] + "\t");

				strLine = brAllrna.readLine(); // source
				strLine = brAllrna.readLine(); // score

				// skip 4 line for matrix.

				brAllrna.readLine(); // A
				brAllrna.readLine(); // C
				brAllrna.readLine(); // G
				brAllrna.readLine(); // T


				buffer.append(bufferLine+ "\n");
			}


			bwr.write( buffer+"");
			System.out.println("Tot motif:"+motifCount);

			bwr.close();

			brAllrna.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}finally
		{

		}

	}

	public static void main(String args[])
	{

		Convert_model_coverage_LATEX obj = new Convert_model_coverage_LATEX();

	
//				obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromC.stat.selected", "/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromC.stat.selected.coverage");	
//				obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromNC.stat.selected", "/home/tanviralam/Desktop/CNCwithrepeat/rankDMFfromNC.stat.selected.coverage");	
//				obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCwithrepeat/allCPFM.model", "/home/tanviralam/Desktop/CNCwithrepeat/allCPFM.model.coverage");	
		//		obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCwithrepeat/allNCPFM.model", "/home/tanviralam/Desktop/CNCwithrepeat/allNCPFM.model.coverage");	


				obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromC.stat.selected", "/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromC.stat.selected.coverage");	
				obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromNC.stat.selected", "/home/tanviralam/Desktop/CNCnorepeat/rankDMFfromNC.stat.selected.coverage");	
		//		obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCnorepeat/allCPFM.model", "/home/tanviralam/Desktop/CNCnorepeat/allCPFM.model.coverage");	
		//		obj.Convert_model_coverage_LATEX("/home/tanviralam/Desktop/CNCnorepeat/allNCPFM.model", "/home/tanviralam/Desktop/CNCnorepeat/allNCPFM.model.coverage");	



//		obj.Convert_model_coverage_LATEX(args[0], args[1]);
		
	}


}


