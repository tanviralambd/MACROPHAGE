package com.cbrc.replicatereport;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SubSelectReplicateValues {

	String fnmUniqNames;
	String fnmAllReplicates;
	String fnmSelectedReplicates;
	
	
	
	LinkedHashMap<String, String> lhm_Trx_TrxCage = new LinkedHashMap<String, String>();
	
	void loadUniueTrx()
	{
		Vector<String > vectUniq = CommonFunction.readlinesOfAfile(this.fnmUniqNames);
		String tmp[];
		for( int i=0; i<vectUniq.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectUniq.get(i));
			lhm_Trx_TrxCage.put(tmp[0], vectUniq.get(i));
			
		}
		
		System.out.println( " Total unique Trx in file: " + lhm_Trx_TrxCage.size());
		
	}
	
	
	void subselect()
	{
		LinkedHashMap<String, String> lhm_OrderedTrx_TrxCage = new LinkedHashMap<String, String>();
		StringBuffer bufRes = new StringBuffer();
		String tmp[];
		
		Vector<String> allResult = CommonFunction.readlinesOfAfile(this.fnmAllReplicates);
		
		bufRes.append( "\t"+ allResult.get(0) + "\n");
		
		String TrxWithQuote , TrxWithoutQuote;
		for(int i=1; i<allResult.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(allResult.get(i));
			TrxWithQuote = tmp[0];
			TrxWithoutQuote = TrxWithQuote.substring(1,TrxWithQuote.length()-1);
			
			if(lhm_Trx_TrxCage.containsKey(TrxWithoutQuote))
			{
//				lhm_OrderedTrx_TrxCage.put(TrxWithoutQuote, lhm_Trx_TrxCage.get(TrxWithoutQuote) + "\t" + allResult.get(i)   );
				lhm_OrderedTrx_TrxCage.put(TrxWithoutQuote,  allResult.get(i)   );
//				bufRes.append( allResult.get(i) + "\n");
				
			}
			
			
		}
		
		
		/*
		 *  For making the result in same order of unique.txt
		 */
		Set set = lhm_Trx_TrxCage.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry) itr.next();
			
//			bufRes.append(me.getKey() + "\t" +me.getValue() + "\n");
			
			bufRes.append(lhm_OrderedTrx_TrxCage.get(me.getKey()) + "\n");
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmSelectedReplicates, bufRes+"");
		
		
	}
	
	void doProcessing()
	{
		
		loadUniueTrx();
		subselect();
		
		
	}
	
	
	
	
	
	public SubSelectReplicateValues(String fnmUniqNames,
			String fnmAllReplicates, String fnmSelectedReplicates) {
		super();
		this.fnmUniqNames = fnmUniqNames;
		this.fnmAllReplicates = fnmAllReplicates;
		this.fnmSelectedReplicates = fnmSelectedReplicates;
	}





	public static void main(String[] args) {
		
		String fold_NS="./ReportChangedPvalue/ReplicateReportGeneration/";
		//String fold_NS_Mixed="./ReportChangedPvalue/ReplicateReportGenerationMixed/";
		String fold_NS_Mixed="./ReportChangedPvalueMixed/ReplicateReportGeneration/";
		
		
		String fold= fold_NS; // fold_NS_Mixed;
		
		String fnmUniqNames= fold + "uniqueTrx.txt";
		
//		String fnmAllReplicates = fold + "allTrxIFNG.table.txt.tagcount.replicates.TPM";
//		String fnmAllReplicates = fold + "allTrxIL413.table.txt.tagcount.replicates.TPM";
		String fnmAllReplicates = fold + "allTrxNONSTIM.table.txt.tagcount.replicates.TPM";
		
		String fnmSelectedReplicates = fnmAllReplicates + ".selected" ;
		
		SubSelectReplicateValues obj = new SubSelectReplicateValues( fnmUniqNames, fnmAllReplicates,fnmSelectedReplicates);
		
		
		obj.doProcessing();
	}
	
	
}
