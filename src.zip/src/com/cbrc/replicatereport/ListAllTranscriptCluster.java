package com.cbrc.replicatereport;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;



import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ListAllTranscriptCluster {

	String fullpath="./ReportChangedPvalue/ReplicateReportGeneration/";
	String fnmTrxClusterIfng=this.fullpath+"NFvsIFNG.allTime.deg.withMtb.clusterid";
	String fnmTrxClusterIl413=this.fullpath+"NFvsIL413.allTime.deg.withMtb.clusterid";
	String fnmTrxClusterNosim=this.fullpath+"NoStim.allTime.deg.withMtb.clusterid";
	
	Vector<String> merge = new Vector<String>();
	
	
	
	void doProcessing()
	{
		mergeAll();
		writeUnique();
	}
	
	
	void writeUnique()
	{
		
		StringBuffer bufRes = new StringBuffer();
		String tmp[];
		LinkedHashMap<String, String> lhmResult = new LinkedHashMap<String, String>();
		
		String curKey,curVal;
		for( int i=0; i<merge.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(merge.get(i));
			curKey = tmp[0] + "#" + tmp[1];
			curVal = merge.get(i);
			
			if(lhmResult.containsKey(curKey))
			{
				System.out.println("Already exist: " + curKey);
			}else
			{
				lhmResult.put(curKey, curVal);
			}
		}
		
		System.out.println("Total unique entry in all three after merging :" + lhmResult.size() );
		
		Set set = lhmResult.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry) itr.next();
			
//			bufRes.append(me.getKey() + "\t" +me.getValue() + "\n");
			
			bufRes.append(me.getValue() + "\n");
			
		}
		
		CommonFunction.writeContentToFile(this.fullpath+"uniqueTrx.txt", bufRes + "");
		
	}
	
	
	void mergeAll()
	{
		Vector<String> vectIfng = CommonFunction.readlinesOfAfile(this.fnmTrxClusterIfng);
		Vector<String> vectIl413 = CommonFunction.readlinesOfAfile(this.fnmTrxClusterIl413);
		Vector<String> vectNostim = CommonFunction.readlinesOfAfile(this.fnmTrxClusterNosim);
		
		
		
		Vector<String> curVect;
		
		curVect = vectIfng;		
		for(int i=1; i<curVect.size();i++)
		{
			merge.add(curVect.get(i));			
		}
		
		curVect = vectIl413;		
		for(int i=1; i<curVect.size();i++)
		{
			merge.add(curVect.get(i));			
		}
		
		
		curVect = vectNostim;		
		for(int i=1; i<curVect.size();i++)
		{
			merge.add(curVect.get(i));			
		}
		
		
		System.out.println("Total entry in all three after merging :" + merge.size());
		
	}
	
	
	public static void main(String[] args) {
		
		ListAllTranscriptCluster obj = new ListAllTranscriptCluster();
		
		obj.doProcessing();
		
		
	}
	
}


