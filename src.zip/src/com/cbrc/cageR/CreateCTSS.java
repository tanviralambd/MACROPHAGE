package com.cbrc.cageR;

import java.util.LinkedHashMap;
import java.util.Vector;
import java.util.regex.Pattern;

import com.cbrc.bean.BedFormat;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

import java.util.*;



public class CreateCTSS {


	String fnmBED;
	String fnmExpression;

	String fnmCTSSoutput;

	String extCTSSmap=".CTSSmapping";
	//	String extCTSSmap=".CTSSmapping";

	LinkedHashMap<String, BedFormat> lhm_trxName_bed     = new LinkedHashMap<String, BedFormat>();
	LinkedHashMap<String, Double>    lhm_trxName_expVal  = new LinkedHashMap<String, Double>();
	LinkedHashMap<String, Integer>    lhm_trxName_1basedIndex_inGTSS  = new LinkedHashMap<String, Integer>();


	class ExpReplica implements Comparable<ExpReplica>{


		double valReplica;


		public ExpReplica(double valReplica) {
			super();
			this.valReplica = valReplica;
		}


		public int compareTo(ExpReplica obj) {

			return (this.valReplica > obj.valReplica ) ? 1  :  -1 ;
		}


		public double getValReplica() {
			return valReplica;
		}


		public void setValReplica(double valReplica) {
			this.valReplica = valReplica;
		} 

	} 


	void loadBED()
	{
		String tmp[];

		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(this.fnmBED);
		BedFormat myBed;

		//		StringBuffer bufCTSS = new StringBuffer();

		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectBedStr.get(i));
			myBed = new BedFormat(tmp[0], tmp[1], tmp[2], tmp[3] , tmp[4 ], tmp[5] , i);

			lhm_trxName_bed.put(myBed.getName(), myBed);

			//			bufCTSS.append(myBed.getName()+"\t" + myBed.getChrom()+"\t" +myBed.getTss()+"\t" +myBed.getStrand()+"\t" +  "\n") ;
		}

		//		CommonFunction.writeContentToFile(this.fnmBED+ extCTSSmap, bufCTSS+""); 

	}


	void loadExpFile_Take_Median_value()
	{
		String tmp[];

		Vector<String> vectExpr = CommonFunction.readlinesOfAfile(this.fnmExpression);
		double finalValue=0;
		int listSize;

		// First line is header, So, skip it

		for(int i=1;i<vectExpr.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectExpr.get(i));

			List myArrayList = new ArrayList();

			for(int c=1; c<tmp.length;c++)
			{
				myArrayList.add(new ExpReplica(Double.parseDouble(tmp[c]) ) );
			}

			Collections.sort( myArrayList  );

			listSize=myArrayList.size();

			if(listSize==1)
			{
				finalValue = ( (ExpReplica)myArrayList.get(0) ).getValReplica() ;

			}else if(listSize%2 ==0) // even - select the big one
			{
				finalValue =  ( (ExpReplica)myArrayList.get(listSize/2) ).getValReplica() ;
			}else // odd - take the middle one
			{
				finalValue =  ( (ExpReplica)myArrayList.get(listSize/2) ).getValReplica() ;
			}

			//			System.out.println(tmp[0]+ "\t"+ finalValue);

			lhm_trxName_expVal.put(tmp[0], finalValue);

			lhm_trxName_1basedIndex_inGTSS.put(tmp[0], i);


		}

	}

	// Chrom | TSS | Strand | OneExpreseoinValue
	void createGTSS()
	{
		StringBuffer resultBufCTSS = new StringBuffer();

		Set set = lhm_trxName_expVal.entrySet();

		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String trxID = (String)me.getKey();

			Double val = (Double) me.getValue();
			int val_int= val.intValue();

			BedFormat curBed = (BedFormat)lhm_trxName_bed.get(trxID);

			resultBufCTSS.append(curBed.getChrom()+"\t" +curBed.getTss()+"\t" +curBed.getStrand()+"\t" + val_int + "\n");
		}




		CommonFunction.writeContentToFile(this.fnmCTSSoutput, resultBufCTSS+"");
	}




	// TrxName | Row_index_1based in .CTSS file | 

	void createCTSSmapping()
	{

		StringBuffer resultBufCTSSmappping = new StringBuffer();

		Set set = lhm_trxName_bed.entrySet();

		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String trxID = (String)me.getKey();

			int val_indexInCTSS = (Integer) lhm_trxName_1basedIndex_inGTSS.get(trxID);

			resultBufCTSSmappping.append(trxID+"\t" + val_indexInCTSS+ "\n");
		}




		CommonFunction.writeContentToFile(this.fnmBED+ extCTSSmap , resultBufCTSSmappping+"");
	}



	void doProcessing()
	{
		loadBED();

		loadExpFile_Take_Median_value();

		createGTSS();
		createCTSSmapping();
	}

	void init(String fnmBed, String fnmExp , String output)
	{
		this.fnmBED = fnmBed;
		this.fnmExpression= fnmExp;
		this.fnmCTSSoutput = output;

	}


	public static void main(String[] args) {
		CreateCTSS obj = new CreateCTSS();
				obj.init(args[0] , args[1] , args[2]);

		//		obj.init("finalLncRNA.bed" , "expvalue.txt" , "outMedian.txt");

//		obj.init("./finalLncRNA.bed" , "./mouse_macrophage_TB_infection_IL4-IL13.counts.csv.matrix.6.6.withoutMtb" , "./mouse_macrophage_TB_infection_IL4-IL13.counts.csv.matrix.6.6.withoutMtb.CTSS");
		obj.doProcessing();

	}



}
