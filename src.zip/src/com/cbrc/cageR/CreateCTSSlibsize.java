package com.cbrc.cageR;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.common.CommonMathFunction;
import com.cbrc.constant.ConstantValue;

public class CreateCTSSlibsize {

	String finLib;
	String foutLibsize;
	
	
	
	
	public CreateCTSSlibsize(String finLib, String foutLibsize) {
		super();
		this.finLib = finLib;
		this.foutLibsize = foutLibsize;
	}

	void doProcessing()
	{
		Vector<String> vect = CommonFunction.readlinesOfAfile(this.finLib);
		String tmp[];
		// skip the first line as it is header
		String curLine = vect.get(1);
		tmp = ConstantValue.patWhiteSpace.split(curLine);
		Vector<Double> vectLib = new Vector<Double>();
		for(int i=0; i<tmp.length;i++)
		{
			vectLib.add( Double.parseDouble(tmp[i]));
		}
		
		CommonMathFunction obj = new CommonMathFunction();
		double myMedian = obj.getTheMedian_NoAverage(vectLib);
		
		CommonFunction.writeContentToFile(this.foutLibsize, myMedian+"");
		
	}
	
	public static void main(String[] args) {
		
		CreateCTSSlibsize obj = new CreateCTSSlibsize(args[0], args[1]);
		
//		CreateCTSSlibsize obj = new CreateCTSSlibsize("mouse_macrophage_TB_infection_IL13.counts.csv.120.120.libsize.withoutMtb", "mouse_macrophage_TB_infection_IL13.counts.csv.120.120.libsize.withoutMtb.CTSS");
		obj.doProcessing();
		
	}
}
