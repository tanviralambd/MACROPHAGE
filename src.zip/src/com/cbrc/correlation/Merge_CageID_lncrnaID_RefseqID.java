package com.cbrc.correlation;


import java.util.LinkedHashMap;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class Merge_CageID_lncrnaID_RefseqID {



	String fnmCageLncrna;
	String fnmCageRefseq;
	String fnmOut;



	LinkedHashMap<String, String> lhm_cage_lncRNA = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> lhm_cage_Refseq = new LinkedHashMap<String, String>();

	void loadCAGE_lncRNA()
	{
		lhm_cage_lncRNA = CommonFunction.readlinesOfAfile_asMap_uniqueValue( this.fnmCageLncrna, 0, 1);

		System.out.println("In cage lncRNA ,  unique cage id:" + lhm_cage_lncRNA.size() );
	}


	/*
	 *  1-6: Bed 6 filed : CAGE
	 *  7-12: Bed 6 field  :Refseq
	 *  13  : th column : distance
	 */
	void loadCAGE_refseq()
	{
		Vector<String> vectBED = CommonFunction.readlinesOfAfile(this.fnmCageRefseq);

		String tmp[];
		String cageID, refseqID, distance;
		for( int i=0 ; i< vectBED.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectBED.get(i));
			cageID = tmp[3];
			refseqID = tmp[9];
			distance = tmp[12];

			if( lhm_cage_Refseq.containsKey(cageID))
			{
				System.out.println("Already exist cage:" + cageID);
			}else
			{
				lhm_cage_Refseq.put(cageID, refseqID);
			}


		}

		System.out.println("In cage Refseq ,  unique cage id:" + lhm_cage_Refseq.size() );

	}


	void writeResult()
	{

		Vector<String> vectResult = CommonFunction.joinMapaKey_MapbKey( lhm_cage_lncRNA, lhm_cage_Refseq);

		StringBuffer bufResult = new StringBuffer();
		for( int i=0 ; i<vectResult.size() ;i++)
		{
			bufResult.append( vectResult.get(i) + "\n");
		}


		CommonFunction.writeContentToFile(this.fnmOut	,  bufResult+"" );

	}

	void doProcessing()
	{


		loadCAGE_lncRNA();
		loadCAGE_refseq();

		writeResult();

	}




	


	public Merge_CageID_lncrnaID_RefseqID(String fnmCageLncrna,
			String fnmCageRefseq, String fnmOut) {
		super();
		this.fnmCageLncrna = fnmCageLncrna;
		this.fnmCageRefseq = fnmCageRefseq;
		this.fnmOut = fnmOut;
	}


	public static void main(String[] args) {


		Merge_CageID_lncrnaID_RefseqID obj = new Merge_CageID_lncrnaID_RefseqID(args[0], args[1] , args[2] );

		obj.doProcessing();

	}


}
