package com.cbrc.correlation;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


import com.cbrc.common.CommonFunction;

public class SubselectExpresseionLncRNA {

	String fnmMapping;
	String fnmExpr;
	
	String fnmOut;
	
	
	LinkedHashMap<String, Set <String>> lhm_cage_lncRNA = new LinkedHashMap<String, Set <String>> ();
	LinkedHashMap<String, String> lhm_lncRNA_Expression = new LinkedHashMap<String, String>();
	
	
	void loadCAGE_lncRNA()
	{
		lhm_cage_lncRNA = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated( this.fnmMapping, 0, 1);

		System.out.println("In cage lncRNA ,  unique cage id:" + lhm_cage_lncRNA.size() );
	}
	
	
	
	
	void loadExpression()
	{
		lhm_lncRNA_Expression = CommonFunction.readlinesOfAfile_asMap_EachLine( this.fnmExpr, 0 );

		System.out.println("total unique lncRNA " + lhm_lncRNA_Expression.size() );
	}
	
	
	void writeResult()
	{
//		Vector<String> vectResult = CommonFunction.joinMapaKey_MapbKey( lhm_cage_lncRNA, lhm_cage_Refseq);
		
		StringBuffer bufResult = new StringBuffer();
		String tmpLncRNA[];
		
		
		Set set = lhm_cage_lncRNA.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()){

			Set setlncRNA;
			String cageID, curlncRNAID;
			String curValue;
			
			Map.Entry me = (Map.Entry) itr.next();
			cageID = (String)me.getKey();
			setlncRNA = (Set<String>) me.getValue();
			
			String[] arr = (String[]) setlncRNA.toArray(new String[setlncRNA.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			 {
				curlncRNAID = arr[c];
				
				
				if(lhm_lncRNA_Expression.containsKey(curlncRNAID))
				{
					curValue = (String) lhm_lncRNA_Expression.get(curlncRNAID);
					
					bufResult.append(cageID + "\t" + curValue + "\n");
//					bufResult.append( curValue + "\n");
					
					break;
				}else
				{
					curValue = "None";
				}

				
				
			} 

		} 
		
		CommonFunction.writeContentToFile(this.fnmOut	,  bufResult+"" );
	}
	
	
	public SubselectExpresseionLncRNA(String fnmMapping, String fnmExpr,
			String fnmOut) {
		super();
		this.fnmMapping = fnmMapping;
		this.fnmExpr = fnmExpr;
		this.fnmOut = fnmOut;
	}

	void doProcessing()
	{
		loadCAGE_lncRNA();
		loadExpression();
		
		writeResult();
		
	}
	
	public static void main(String[] args) {
		
		SubselectExpresseionLncRNA obj = new SubselectExpresseionLncRNA(args[0], args[1], args[2]);
		
		obj.doProcessing();
		
		
	}
	
	
}
