package com.cbrc.correlation;



import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;


import com.cbrc.common.CommonFunction;

public class SubselectExpresseionRefseq {

	String fnmMapping;
	String fnmExpr;
	
	String fnmOut;
	
	
	LinkedHashMap<String, Set <String>> lhm_cage_Refseq = new LinkedHashMap<String, Set <String>> ();
	LinkedHashMap<String, String> lhm_Refseq_Expression = new LinkedHashMap<String, String>();
	
	
	void loadCAGE_lncRNA()
	{
		lhm_cage_Refseq = CommonFunction.readlinesOfAfile_asMap_setValueCommaSemicolonSeperated( this.fnmMapping, 0, 2);

		System.out.println("In cage Refseq ,  unique cage id:" + lhm_cage_Refseq.size() );
	}
	
	
	
	
	void loadExpression()
	{
		lhm_Refseq_Expression = CommonFunction.readlinesOfAfile_asMap_EachLine( this.fnmExpr, 0 );

		System.out.println("total unique lncRNA " + lhm_Refseq_Expression.size() );
	}
	
	
	void writeResult()
	{
//		Vector<String> vectResult = CommonFunction.joinMapaKey_MapbKey( lhm_cage_lncRNA, lhm_cage_Refseq);
		
		StringBuffer bufResult = new StringBuffer();
		String tmpLncRNA[];
		
		
		Set set = lhm_cage_Refseq.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()){

			Set setRefseq;
			String cageID, curRefseqID;
			String curValue;
			
			Map.Entry me = (Map.Entry) itr.next();
			cageID = (String)me.getKey();
			setRefseq = (Set<String>) me.getValue();
			
			String[] arr = (String[]) setRefseq.toArray(new String[setRefseq.size()]);
			int setSize = arr.length;
			for(int c=0; c < setSize;c++)
			 {
				curRefseqID = arr[c];
				
				
				if(lhm_Refseq_Expression.containsKey(curRefseqID))
				{
					curValue = (String) lhm_Refseq_Expression.get(curRefseqID);
					
					bufResult.append(cageID + "\t" + curValue + "\n");
//					bufResult.append( curValue + "\n");
					
					
					break;
				}else
				{
					curValue = "None";
				}
			} 

		} 
		
		CommonFunction.writeContentToFile(this.fnmOut	,  bufResult+"" );
	}
	
	
	public SubselectExpresseionRefseq(String fnmMapping, String fnmExpr,
			String fnmOut) {
		super();
		this.fnmMapping = fnmMapping;
		this.fnmExpr = fnmExpr;
		this.fnmOut = fnmOut;
	}

	void doProcessing()
	{
		loadCAGE_lncRNA();
		loadExpression();
		
		writeResult();
		
	}
	
	public static void main(String[] args) {
		
		SubselectExpresseionRefseq obj = new SubselectExpresseionRefseq(args[0], args[1], args[2]);
		
		obj.doProcessing();
		
		
	}
	
	
}
