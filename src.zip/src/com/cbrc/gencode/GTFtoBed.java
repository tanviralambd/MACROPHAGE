package com.cbrc.gencode;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;


/*
 *  EXCEPTION FOR THE EXON-order
 *  In GENCODE, 
 *  for +ve strand, first exon comes first in their GTF file
 *  for -ve strand, first exon comes last in their GTF file
 */
public class GTFtoBed {

	
	String fnmGTF;
	String fnmBed;
	
	void doProcessing()
	{
		readTranscript();
	}
	
	void readTranscript()
	{
		Vector<String> gffLines = CommonFunction.readlinesOfAfile(this.fnmGTF);
		String tmp[];
		int totTranscrpt=0,totGene=0;
		Vector<Integer> vectExonStart =  new Vector<Integer>();
		Vector<Integer> vectExonEnd =  new Vector<Integer>();
		
		int chrStart=0;
		String curStrand="";
		String name,score="0";
		StringBuffer buf = new StringBuffer();
		
		String mandatory6="", rest6="";
		StringBuffer rest6buf= new StringBuffer();
		
		int skipHeadline=5;
		for(int i=skipHeadline; i<gffLines.size() ;i++)
		{
			
			tmp = ConstantValue.patWhiteSpace.split(gffLines.get(i));
			
			if(tmp[2].equals("gene") ){
				totGene++;
			}
			else if(tmp[2].equals("transcript") ){
				totTranscrpt++;
				
				name = tmp[11].substring(1, tmp[11].length()-2);
				if(rest6.length()>0 ){
					
					// form the last 6 fields
					

					if(curStrand.charAt(0)=='+')
					{
						
						rest6buf.append(vectExonStart.get(0) + "\t" + vectExonEnd.get(0) + "\t" + "255,0,0" + "\t" + vectExonStart.size() +"\t");
						
						for(int l=0;l<vectExonStart.size();l++)
						{
							if(l==vectExonStart.size()-1)
								rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l) +1  )  +"" );
							else
								rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l) +1  )  +"," );
							
						}
						
						rest6buf.append("\t");
						
						for(int l=0;l<vectExonStart.size();l++)
						{
							if(l==vectExonStart.size()-1)
								rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"" );
							else
								rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"," );
							
						}
					}else
					{
						
						rest6buf.append(vectExonStart.get( vectExonStart.size()-1 ) + "\t" + vectExonEnd.get( vectExonStart.size()-1 ) + "\t" + "255,0,0" + "\t" + vectExonStart.size() +"\t");
						
						for(int l= vectExonStart.size()-1; l>=0;l--)
						{
							if(l== 0 )
								rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"" );
							else
								rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"," );
							
						}
						
						rest6buf.append("\t");
						
						for(int l= vectExonStart.size()-1; l>=0;l--)
						{
							if(l== 0)
								rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"" );
							else
								rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"," );
							
						}
						
					}
					

					
					
					// APPEND TO mandatory6
					buf.append(mandatory6+ "\t"+ rest6buf + "\n");
					
					
					
					// reset ALL
					mandatory6="";
					rest6="";
					rest6buf= new StringBuffer();
					vectExonStart = new Vector<Integer>();
					vectExonEnd = new Vector<Integer>();
				}
				
				chrStart = Integer.parseInt(tmp[3]);
				curStrand = tmp[6] ;
				mandatory6=tmp[0]+"\t" + (chrStart-1) + "\t"  + tmp[4] + "\t"  +  name+ "\t" + score + "\t" + curStrand  ;
				
			}else if(tmp[2].equals("exon") ){
				
				vectExonStart.add(Integer.parseInt(tmp[3]));
				vectExonEnd.add(Integer.parseInt(tmp[4]));
				
				rest6 = vectExonStart.size()+"";
				
			}
			
			
					
		}
		
		////////////////////////////////////  for last entry ///////////////////////////////////////
		// form the last 6 fields
		if(curStrand.charAt(0)=='+')
		{
			
			rest6buf.append(vectExonStart.get(0) + "\t" + vectExonEnd.get(0) + "\t" + "255,0,0" + "\t" + vectExonStart.size() +"\t");
			
			for(int l=0;l<vectExonStart.size();l++)
			{
				if(l==vectExonStart.size()-1)
					rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"" );
				else
					rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"," );
				
			}
			
			rest6buf.append("\t");
			
			for(int l=0;l<vectExonStart.size();l++)
			{
				if(l==vectExonStart.size()-1)
					rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"" );
				else
					rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"," );
				
			}
		}else
		{
			
			rest6buf.append(vectExonStart.get( vectExonStart.size()-1 ) + "\t" + vectExonEnd.get( vectExonStart.size()-1 ) + "\t" + "255,0,0" + "\t" + vectExonStart.size() +"\t");
			
			for(int l= vectExonStart.size()-1; l>=0;l--)
			{
				if(l== 0 )
					rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"" );
				else
					rest6buf.append( ( vectExonEnd.get(l)-vectExonStart.get(l)  +1 )  +"," );
				
			}
			
			rest6buf.append("\t");
			
			for(int l= vectExonStart.size()-1; l>=0;l--)
			{
				if(l== 0)
					rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"" );
				else
					rest6buf.append( ( vectExonStart.get(l) - chrStart )  +"," );
				
			}
			
		}

		// APPEND TO mandatory6
		buf.append(mandatory6+ "\t"+ rest6buf + "\n");
		
		
		System.out.println("Total gene: " + totGene + "  Total transcript: " + totTranscrpt);
		
		CommonFunction.writeContentToFile(this.fnmBed, buf+"");
	}
	
	
	
	public GTFtoBed(String fnmGTF, String fnmBed) {
		super();
		this.fnmGTF = fnmGTF;
		this.fnmBed = fnmBed;
	}




	public static void main(String[] args) {
		
		GTFtoBed obj = new GTFtoBed(args[0] , args[1]);
		
//		GTFtoBed obj = new GTFtoBed("gencode.mouse.v1.long_noncoding_RNAs.gtf" , "gencode.mouse.v1.long_noncoding_RNAs.gtf.bed");
		
		
		obj.doProcessing();
		
	}
	
}
