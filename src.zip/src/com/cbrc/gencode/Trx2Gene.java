package com.cbrc.gencode;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;


public class Trx2Gene{

	
	String fnmGTF;
	String fnmOut;
	
	void doProcessing()
	{
		readTranscript();
	}
	
	void readTranscript()
	{
		Vector<String> gffLines = CommonFunction.readlinesOfAfile(this.fnmGTF);
		String tmp[];
		int totTranscrpt=0,totGene=0;
		Vector<Integer> vectExonStart =  new Vector<Integer>();
		Vector<Integer> vectExonEnd =  new Vector<Integer>();
		
		int chrStart=0;
		String curStrand="";
		String trxName,geneName,score="0";
		StringBuffer buf = new StringBuffer();
		
		String mandatory6="", rest6="";
		StringBuffer rest6buf= new StringBuffer();
		
		int skipHeadline=5;
		for(int i=skipHeadline; i<gffLines.size() ;i++)
		{
			
			tmp = ConstantValue.patWhiteSpace.split(gffLines.get(i));
			
			if(tmp[2].equals("gene") ){
				totGene++;
			}
			else if(tmp[2].equals("transcript") ){
				totTranscrpt++;
				
				geneName = tmp[9].substring(1, tmp[11].length()-2);
				trxName = tmp[11].substring(1, tmp[11].length()-2);
				
				mandatory6=  trxName+ "\t" + geneName + "\n";
				
				buf.append(mandatory6);
				
			}else if(tmp[2].equals("exon") ){
				

				
			}
			
			
			
					
		}
		
		

		
		
		
		System.out.println("Total gene: " + totGene + "  Total transcript: " + totTranscrpt);
		
		CommonFunction.writeContentToFile(this.fnmOut, buf+"");
	}
	
	
	
	public Trx2Gene(String fnmGTF, String fnmBed) {
		super();
		this.fnmGTF = fnmGTF;
		this.fnmOut = fnmBed;
	}




	public static void main(String[] args) {
		
//		Trx2Gene obj = new Trx2Gene(args[0] , args[1]);
		
		Trx2Gene obj = new Trx2Gene("gencode.v2.long_noncoding_RNAs.gtf" , "gencode.v2.long_noncoding_RNAs.gtf.trx2gene");
		
		
		obj.doProcessing();
		
	}
	
}

