package com.cbrc.ontologizer;

import java.util.Vector;

import com.cbrc.folderoperation.FolderOperations;

import com.cbrc.common.CommonFunction;

public class Command_CallOntologizer_Cellspecific {

	String foldResultsCAGE;
	String foldInputTFTcoFName;
	String foldOutNameInCellline;
	
	
	String fnmBGabspath;
	String commnadOutPrefix;
	String fnmHeaderShell;
	
	
	public Command_CallOntologizer_Cellspecific(String foldResultsCAGE,
			String foldInputTFTcoFName, String foldOutNameInCellline) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.foldInputTFTcoFName = foldInputTFTcoFName;
		this.foldOutNameInCellline = foldOutNameInCellline;
	}

	
	
	




	public Command_CallOntologizer_Cellspecific(String foldResultsCAGE,
			String foldInputTFTcoFName, String foldOutNameInCellline,
			String fnmBGabspath, String commnadOutPrefix, String headerShell) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.foldInputTFTcoFName = foldInputTFTcoFName;
		this.foldOutNameInCellline = foldOutNameInCellline;
		this.fnmBGabspath = fnmBGabspath;
		this.commnadOutPrefix = commnadOutPrefix;
		this.fnmHeaderShell = headerShell;
	}








	void doProcessing()
	{
		
		/*
		 *  Iterate over all folders
		 */
		String curCelllineFolder ,curInputFolderCell, curOutputFolderCell;
		String curCellName;
		
		StringBuffer bufResult = new StringBuffer();
		
		StringBuffer bufMaster = new StringBuffer();
		
		
		Vector<String> vectFolderCellline = FolderOperations.listFiles_Dir(foldResultsCAGE);
		
		
		String finalName;
		Vector<String> vectInputFilesCell;
		String bgFile;
		String outputFoldFor_OneInput; 
		
		String onto_InputfileAbspath, onto_BGfileAbspath , onto_outputFold , onto_InputfilenamePrefix;
		
		String headString= CommonFunction.readlinesOfAfileAsBuffer(this.fnmHeaderShell);
		
		bufMaster.append(headString+"\n\n\n");
		
		for(int i=0; i< vectFolderCellline.size() ;i++) // vectFolderCellline.size()
		{
			
			bufResult = new StringBuffer();
			bufResult.append(headString+"\n\n\n") ;
			
			
			curCellName =  vectFolderCellline.get(i);
			curCelllineFolder = this.foldResultsCAGE+ "/" + vectFolderCellline.get(i) + "/";
			System.out.println("Working for cellline "  + curCelllineFolder);

			
			curInputFolderCell =  curCelllineFolder + "/" + this.foldInputTFTcoFName + "/";
			
			curOutputFolderCell = curCelllineFolder + "/" + this.foldOutNameInCellline;
			FolderOperations.create_new_folder(curOutputFolderCell);
			
			
			/*
			 *  Generate Script for All CellLine
			 */
			
			vectInputFilesCell = FolderOperations.listFiles_Files(curInputFolderCell);
			for(int inp=0 ; inp<vectInputFilesCell.size() ;inp++)
			{
				
				onto_InputfileAbspath = curInputFolderCell + "/" +vectInputFilesCell.get(inp);
				onto_BGfileAbspath = this.fnmBGabspath;
				
				onto_InputfilenamePrefix = getFileNameWitout_Extension(onto_InputfileAbspath) ;
				onto_outputFold = curOutputFolderCell + "/" + onto_InputfilenamePrefix;
				
				
				
				bufResult.append(
						" sbatch callerOntologizerPROmiRNA_Cellspecific.sh  " + "\t" +
						onto_InputfileAbspath  + "\t" +
						onto_BGfileAbspath + "\t" +
						onto_outputFold + "\t" +
						onto_InputfilenamePrefix + "\n")
						
						;
				
				
			}
			
			finalName= this.commnadOutPrefix + curCellName + ".sh";
			CommonFunction.writeContentToFile( finalName, bufResult+"");
			
			bufMaster.append(" sbatch  " + finalName + "\n") ;
			
		}// End of 1 cell line
		
		
		
		CommonFunction.writeContentToFile( this.commnadOutPrefix + "Master.sh" , bufMaster+"");
	}
	
	
	String getFileNameWitout_Extension(String absPath)
	{
		String result="";
		int lastSlash = absPath.lastIndexOf('/');
		int lastDot = absPath.lastIndexOf('.');
		
		result = absPath.substring(lastSlash+1, lastDot);
		return result;
	}
	
	
	public static void main(String[] args) {
		
		
		Command_CallOntologizer_Cellspecific obj = new Command_CallOntologizer_Cellspecific(
				
				args[0] , args[1] , args[2] , args[3], args[4] , args[5] );
		
		
		obj.doProcessing();
		
		
	}
}
