package com.cbrc.ontologizer;

import java.util.Vector;

import com.cbrc.folderoperation.FolderOperations;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/*
 *  Read microRNA| List of TF,TcoF and make seperate file for each microRNA
 */
public class MakeInputFiles {

	String fnmAllGeneInput;
	String foldOut;
	
	
	
	
	public MakeInputFiles(String fnmAllGeneInput, String foldOut) {
		super();
		this.fnmAllGeneInput = fnmAllGeneInput;
		this.foldOut = foldOut;
	}



	void doProcessing()
	{
		
		FolderOperations.create_new_folder(this.foldOut)  ;
		
		Vector<String> vect_ID_Protein = CommonFunction.readlinesOfAfile(this.fnmAllGeneInput);
		
		String curMicroRNAid ; 
		String curListTF_TcoF;
		String curOutputFile;
		String tmp[] , tmpProts[];
		
		
		
		for(int i= 0; i<vect_ID_Protein.size();i++)
		{

			// Just for testcase
//			if(i>2)
//				break;
			
			tmp = ConstantValue.patWhiteSpace.split(vect_ID_Protein.get(i));
			
			curMicroRNAid = tmp[0];
			curListTF_TcoF = tmp[1];
			curOutputFile = this.foldOut + "/" +curMicroRNAid + ".input";
			
//			System.out.println("Calling with:  " + curMicroRNAid + "\t" + curListTF_TcoF + "\t" + curOutputFile);
			
//			if( !FolderOperations.isFileExistInFolder(curOutputFile))
			if(true)
			{
				
				StringBuffer resBuf = new StringBuffer();
				
				tmpProts = ConstantValue.patSemiColonComma.split(curListTF_TcoF);
				
				for(int k=0; k<tmpProts.length;k++)
				{
					resBuf.append(tmpProts[k]+"\n");
				}
				
				CommonFunction.writeContentToFile(curOutputFile, resBuf+"");
			}else
			{
				System.out.println("No need to call:  " + curOutputFile  + "  exists already");
			}
			
			
		}
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		MakeInputFiles obj = new MakeInputFiles(args[0] , args[1]);
		
//		MakeInputFiles obj = new MakeInputFiles("tmp.out" , "./res" );
		obj.doProcessing();
	}
	
}
