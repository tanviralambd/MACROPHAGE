package com.cbrc.ontologizer;

public class FilterOntologizer {


	public static boolean isPassing_GO_FilterOfDescription( String description)
	{
		boolean isOk = true;

		if( 	description.contains("root") ||  
				description.contains("cellular_component") || 
				description.contains("molecular_function")|| 
				description.contains("biological_process") ||
				description.contains("transcription") ||
				description.contains("translation")  ||
				
				// This part is blocked recently; Need to run again all test.
				description.contains("macromolecule") 	|| 
				description.contains("promoter") || 
				description.contains("binding") || 
				description.contains("replication") 




				)
		{

			isOk = false;
		}

		return isOk;
	}

}
