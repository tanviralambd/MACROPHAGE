package com.cbrc.ontologizer;



import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.folderoperation.FolderOperations;

public class Command_CallOntologizer_AllThenSplit {

	String foldInputTFTcoFName;
	String foldResultOntologizer;


	String fnmBGabspath;

	String foldSplitCommand;
	String commnadOutPrefix;
	String fnmHeaderShell;
	int totalJobPerScript;






	public Command_CallOntologizer_AllThenSplit(
			String foldInputTFTcoFName,
			String foldResultOntologizer, String fnmBGabspath,
			String foldSplitCommand, String commnadOutPrefix,
			String fnmHeaderShell, int totalJobPerScript) {
		super();
		this.foldInputTFTcoFName = foldInputTFTcoFName;
		this.foldResultOntologizer = foldResultOntologizer;
		this.fnmBGabspath = fnmBGabspath;
		this.foldSplitCommand = foldSplitCommand;
		this.commnadOutPrefix = commnadOutPrefix;
		this.fnmHeaderShell = fnmHeaderShell;
		this.totalJobPerScript = totalJobPerScript;
	}


	void doProcessing()
	{

		FolderOperations.create_new_folder(this.foldSplitCommand);

		/*
		 *  Iterate over all folders
		 */
		String curCelllineFolder ,curInputFolderCell, curOutputFolderCell;
		String curCellName;

		StringBuffer bufSplittedCommands = new StringBuffer();

		StringBuffer bufAllCelllineCommand = new StringBuffer();




		String finalNameSplit;
		Vector<String> vectInputFilesCell;

		String onto_InputfileAbspath, onto_BGfileAbspath , onto_outputFold , onto_InputfilenamePrefix;

		String headString= CommonFunction.readlinesOfAfileAsBuffer(this.fnmHeaderShell);

		bufAllCelllineCommand.append(headString+"\n\n\n");

		int totalCommand=0 , totalSplit=1;


		curInputFolderCell =   this.foldInputTFTcoFName + "/";

		curOutputFolderCell =  this.foldResultOntologizer;
		FolderOperations.create_new_folder(curOutputFolderCell);


		/*
		 *  Iterate over 1 CellLine
		 */

		vectInputFilesCell = FolderOperations.listFiles_Files(curInputFolderCell);
		for(int inp=0 ; inp<vectInputFilesCell.size() ;inp++)
		{

			onto_InputfileAbspath = curInputFolderCell + "/" +vectInputFilesCell.get(inp);
			onto_BGfileAbspath = this.fnmBGabspath;

			onto_InputfilenamePrefix = getFileNameWitout_Extension(onto_InputfileAbspath) ;
			onto_outputFold = curOutputFolderCell + "/" + onto_InputfilenamePrefix;



			bufSplittedCommands.append(
					" sh  ../callerOntologizerPROmiRNA_Cellspecific.sh   " + "\t" +
							onto_InputfileAbspath  + "\t" +
							onto_BGfileAbspath + "\t" +
							onto_outputFold + "\t" +
							onto_InputfilenamePrefix + "\n") ;


			totalCommand++;

			if( (totalCommand % this.totalJobPerScript ) == 0 )
			{
				finalNameSplit = this.foldSplitCommand + "/" + this.commnadOutPrefix +  totalSplit + ".sh";
				CommonFunction.writeContentToFile( finalNameSplit, ( headString+"\n\n\n" + bufSplittedCommands+"" ));
				bufAllCelllineCommand.append(" sbatch  " + finalNameSplit + "\n") ;
				totalSplit++;
				bufSplittedCommands = new StringBuffer();
			}

		}


		// For the last bulk beyond JOBSperSCRIPT
		finalNameSplit =  this.foldSplitCommand + "/" + this.commnadOutPrefix +  totalSplit + ".sh";
		CommonFunction.writeContentToFile( finalNameSplit, ( headString+"\n\n\n" + bufSplittedCommands+"" ));
		bufAllCelllineCommand.append(" sbatch  " + finalNameSplit + "\n") ;
		totalSplit++;
		bufSplittedCommands = new StringBuffer();

		CommonFunction.writeContentToFile( this.foldSplitCommand + "/" +  this.commnadOutPrefix + "AllCommand.sh" , bufAllCelllineCommand+"");
		
		
		
	}


	String getFileNameWitout_Extension(String absPath)
	{
		String result="";
		int lastSlash = absPath.lastIndexOf('/');
		int lastDot = absPath.lastIndexOf('.');

		result = absPath.substring(lastSlash+1, lastDot);
		return result;
	}


	public static void main(String[] args) {


		Command_CallOntologizer_AllThenSplit obj = new Command_CallOntologizer_AllThenSplit(

				args[0] , args[1] , args[2] , args[3], args[4] , args[5] , Integer.parseInt(args[6]));


		obj.doProcessing();



	}
}
