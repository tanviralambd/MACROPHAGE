
package com.cbrc.ontologizer;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Vector;
import java.util.Set;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ParseResultRefseq_MakeList_Uniprot_GO {

	
	String fnmInResultFromOnto;
	String fnmOutList;
	
	
	LinkedHashMap<String, Set<String> > lhm_uniprot_goidlist = new LinkedHashMap<String, Set<String>>();
	
	public ParseResultRefseq_MakeList_Uniprot_GO(String fnmInResultFromOnto,
			String fnmOutList) {
		super();
		this.fnmInResultFromOnto = fnmInResultFromOnto;
		this.fnmOutList = fnmOutList;
	}


	void doProcessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmInResultFromOnto);
		StringBuffer resBuf = new StringBuffer();
		String tmp[];
		int noColumn, indexHyphen , indexUnderscore;
		String curUniProtname="" ,curGOid;
		
		int skipHeaderLines=1;
		
		for(int i= skipHeaderLines; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			noColumn = tmp.length;
			curGOid = tmp[1];
			
			
			indexHyphen = tmp[0].indexOf('-');
			indexUnderscore = tmp[0].indexOf('_');
			
			// Change the column "table-NM_030671" 
			if(indexHyphen>0)
			{
				curUniProtname = tmp[0].substring( indexHyphen+1 );
			}
			
			
			if( lhm_uniprot_goidlist.containsKey(curUniProtname))
			{
				
				lhm_uniprot_goidlist.get(curUniProtname).add(curGOid);
			}else
			{
				
				
				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(curGOid);
				lhm_uniprot_goidlist.put(curUniProtname, tmpSet);
			}
			
			
			
			// Add all column into Buffer
//			for(int c=0; c<noColumn-1;c++)
//			{
//				resBuf.append(tmp[c] + "\t" );
//			}
//			resBuf.append(tmp[noColumn-1]  + "\n");
			
			
			
		}
		
		  Set setUni = lhm_uniprot_goidlist.entrySet();
          System.out.println("Total Unique UNIprot name :" + setUni.size() ) ;
          Iterator itr = setUni.iterator();
          while(itr.hasNext()){


              Map.Entry me = (Map.Entry) itr.next();
              String uniName = (String)me.getKey();
              Set goSet = (Set) me.getValue();
              
              resBuf.append( uniName +  "\t" );
              
              
              String[] arr = (String[]) goSet.toArray(new String[goSet.size()]);
              int setSize = arr.length;
              for(int c=0; c < setSize;c++)
               {
                if(c==setSize-1)
                	resBuf.append(arr[c]+"\n");
                else
                	resBuf.append(arr[c]+ ConstantValue.seperatorList);

              } 
             
              
              
          }
		
		
		
		
		CommonFunction.writeContentToFile(this.fnmOutList, resBuf+"");
	}
	
	
	public static void main(String[] args) {
		
		ParseResultRefseq_MakeList_Uniprot_GO obj = new ParseResultRefseq_MakeList_Uniprot_GO(args[0], args[1]);
		
//		ParseResultRefseq_MakeList_Uniprot_GO obj = new ParseResultRefseq_MakeList_Uniprot_GO("GO.adj.0.05", "GO.adj.0.05.GOlist" );
		
		
		obj.doProcessing();
		
	}
	
}

