package com.cbrc.ontologizer;


import java.util.Vector;

import com.cbrc.folderoperation.FolderOperations;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/*
 *  Read microRNA| List of TF,TcoF and make seperate file for each microRNA
 */
public class MakeInputFiles_CellSpecific {

	String foldResultsCAGE;
	String fnmAllGeneInput;
	String foldOut;
	
	
	

	public MakeInputFiles_CellSpecific(String foldResultsCAGE,
			String fnmAllGeneInput, String foldOut) {
		super();
		this.foldResultsCAGE = foldResultsCAGE;
		this.fnmAllGeneInput = fnmAllGeneInput;
		this.foldOut = foldOut;
	}

	void doProcessing()
	{
		
		/*
		 *  Iterate over all folders
		 */
		String curCelllineFolder;
		Vector<String> vectFolder = FolderOperations.listFiles_Dir(foldResultsCAGE);
		
		for(int i=0; i< vectFolder.size() ;i++) // vectFolder.size()
		{
			curCelllineFolder = this.foldResultsCAGE+ "/" + vectFolder.get(i) + "/";
			System.out.println("Splitting TF-TcoF for "  + curCelllineFolder);

			
			splitFor1cell( curCelllineFolder,  curCelllineFolder + "/" + this.fnmAllGeneInput);
			
		}
	}

	void splitFor1cell(String curCelllineFold, String fnmTflist1cell)
	{
		String resultWplitFold = curCelllineFold + "/" + this.foldOut; 
		FolderOperations.create_new_folder(resultWplitFold)  ;
		
		Vector<String> vect_ID_Protein = CommonFunction.readlinesOfAfile(fnmTflist1cell);
		
		String curMicroRNAid ; 
		String curListTF_TcoF;
		String curOutputFile;
		String tmp[] , tmpProts[];
		
		
		
		for(int i= 0; i<vect_ID_Protein.size();i++)
		{

			// Just for testcase
//			if(i>2)
//				break;
			
			tmp = ConstantValue.patWhiteSpace.split(vect_ID_Protein.get(i));
			
			curMicroRNAid = tmp[0];
			curListTF_TcoF = tmp[1];
			curOutputFile = resultWplitFold + "/" +curMicroRNAid + ".input";
			
			System.out.println("Creading file:  " + curOutputFile);
			
//			if( !FolderOperations.isFileExistInFolder(curOutputFile))
			if(true)
			{
				
				StringBuffer resBuf = new StringBuffer();
				
				tmpProts = ConstantValue.patSemiColonComma.split(curListTF_TcoF);
				
				for(int k=0; k<tmpProts.length;k++)
				{
					resBuf.append(tmpProts[k]+"\n");
				}
				
				CommonFunction.writeContentToFile(curOutputFile, resBuf+"");
				
				
				
			}else
			{
				System.out.println("No need to call:  " + curOutputFile  + "  exists already");
			}
			
			
		}
		
		
	}
	
	
	
	public static void main(String[] args) {
		
		MakeInputFiles_CellSpecific obj = new MakeInputFiles_CellSpecific(args[0] , args[1] , args[2]);
		
//		MakeInputFiles_CellSpecific obj = new MakeInputFiles_CellSpecific("tmp.out" , "./res" );
		obj.doProcessing();
	}
	
}

