package com.cbrc.ontologizer;



import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Vector;

import com.cbrc.folderoperation.FolderOperations;
import com.cbrc.ontologizer.ParseFilter_ParentChild.MyInnerGO;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MergeResultAdjDifferentFolder_CellSpecific {


	String fnmListGO;
	String foldResultsCAGE;
	String foldResultName;
	String inputExt;
	double thrPvalAdj;
	String foldOutput;

	LinkedHashMap<String, MyInnerGO> lhm_goid_go = new LinkedHashMap<String, MergeResultAdjDifferentFolder_CellSpecific.MyInnerGO>();
	Vector<String> vectAllFnameAbsolutePath ;

	
	


	public MergeResultAdjDifferentFolder_CellSpecific(String fnmListGO,
			String foldResultsCAGE, String foldResultName, String inputExt,
			double thrPvalAdj, String foldOutput) {
		super();
		this.fnmListGO = fnmListGO;
		this.foldResultsCAGE = foldResultsCAGE;
		this.foldResultName = foldResultName;
		this.inputExt = inputExt;
		this.thrPvalAdj = thrPvalAdj;
		this.foldOutput = foldOutput;
	}


	class MyInnerGO
	{
		String id;
		String desc;
		String category;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getDesc() {
			return desc;
		}
		public void setDesc(String desc) {
			this.desc = desc;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public MyInnerGO(String id, String desc, String category) {
			super();
			this.id = id;
			this.desc = desc;
			this.category = category;
		}

	}

	void loadAllGO(String fnmGOList)
	{
		Vector<String> vectListGO = CommonFunction.readlinesOfAfile(this.fnmListGO);
		String curLine;
		String tmp[];

		String id, desc, category;

		for(int i=0; i<vectListGO.size();i++)
		{
			curLine = vectListGO.get(i);
			tmp = ConstantValue.patTab.split(curLine);


			id = tmp[0];
			desc = tmp[1];
			category = tmp[2];
			if(lhm_goid_go.containsKey(id))
			{
				System.out.println("Already exist: " + id);
			}else
			{
				lhm_goid_go.put(id, new MyInnerGO(id, desc, category));
			}

		}

		System.out.println("Total Go term " + lhm_goid_go.size());

	}

	void loadAllFileNamesOfAcell(String curCellCAGEAbspath)
	{
		vectAllFnameAbsolutePath = new Vector<String>();
		String absPathDirectoryGOresults,absPathDirectoryRNAs;

		Vector<String> vectRNANames = new Vector<String>();
		Vector<String> vectDirFileNames = new Vector<String>();


		absPathDirectoryGOresults = curCellCAGEAbspath + "/"  +  this.foldResultName +"/"  ;
		vectRNANames = FolderOperations.listFiles_Dir( absPathDirectoryGOresults  );	
		
		System.out.println("Total RNA in this GO output result of this cell : " + vectRNANames.size());

		for(int d=0; d<vectRNANames.size();d++)
		{
			absPathDirectoryRNAs = absPathDirectoryGOresults + "/"+ vectRNANames.get(d)  ;
			//			System.out.println("Cur dire  is: " +  absPathDir );

			// Now take the files inside folder
			vectDirFileNames = FolderOperations.listAllFilesInDirectoryBasedOnExtensions( absPathDirectoryRNAs , this.inputExt);

			//			System.out.println("Cur dire contains matching file: " +  vectDirFileNames.size() );

			for(int j=0; j<vectDirFileNames.size();j++)
			{
				vectAllFnameAbsolutePath.add(absPathDirectoryRNAs + "/" +  vectDirFileNames.get(j)) ;
			}

		}


		System.out.println( "Ultimately we get RNAfile for this cellLine : " + vectAllFnameAbsolutePath.size() ) ;

	}

	void mergeAdjusted_Write(String curCellName)
	{

		String goID, goDesc , goCategory;;
		int totBGSample;
		int totBGtHit;
		int totTargetSample;
		int totTargetHit;
		double pvalue;
		double pvalueAdj;
		double pvalueMin;

		String BONFERRONI,	FDR,	BY,	HOMMEL,	HOLM,	HOCHBERG;

		String curFnameAbsPath="",fileNameShort , fnameWithoutExt;
		String curHeader="";
		String curLine;
		String tmp[];

		Path p ;
		int index0based_AdjPvalueStart = 12;

		StringBuffer buf = new StringBuffer();

		Vector<String> vectCurFileContent;
		boolean selectIt=false;

		double curAdjVal;


		for(int i=0; i<vectAllFnameAbsolutePath.size();i++)
		{

			curFnameAbsPath =  vectAllFnameAbsolutePath.get(i);


			if(i%1000 ==0)
			{
				System.out.println("Processing fileno: "+ (i+1)  + "  fileName: "+ curFnameAbsPath);
			}

			p = Paths.get(curFnameAbsPath);
			fileNameShort = p.getFileName().toString();
			fnameWithoutExt = fileNameShort.substring(0,   fileNameShort.lastIndexOf(this.inputExt));
			//			System.out.println("Checking file : "+ ( curFnameAbsPath)  );

			vectCurFileContent = CommonFunction.readlinesOfAfile(curFnameAbsPath);

			//			curHeader = "miRNA"+ "\t" +  "GOID"+ "\t" + vectCurFileContent.get(0);

			curHeader = "RNA"+ "\t" +  "GO" + "\t"  + "Description"+ "\t"  + "Category"+ "\t" 
					+ "Count_Hit"	+ "\t"  + "Total_target" +  "\t"  + "BG_Hit"	+ "\t"  + "Total_BG" 
					+ "\t"  + "Pvalue" + "\t"  +  "BONFERRONI"	+ "\t"  + 	"FDR"	+ "\t"  + 	"BY"	+ "\t"   
					+ "\t"  +  "HOMMEL"	+ "\t"  + 	"HOLM"	+ "\t"  + 	"HOCHBERG" ;

			for(int ind=1; ind<vectCurFileContent.size() ;ind++)
			{

				curLine = vectCurFileContent.get(ind) ;
				tmp = ConstantValue.patTab.split(curLine);

				selectIt=false;
				for(int check=index0based_AdjPvalueStart;  check<tmp.length; check++)
				{
					curAdjVal = Double.parseDouble(tmp[check]);
					if( curAdjVal <= this.thrPvalAdj )
					{
						selectIt = true;
						break;
					}
				}

				if( selectIt )
				{

					goID = tmp[0];
					totBGSample = Integer.parseInt( tmp[1] );
					totBGtHit = Integer.parseInt( tmp[2] );


					totTargetSample = Integer.parseInt(  tmp[3] );
					totTargetHit = Integer.parseInt( tmp[4] );

					pvalue  = Double.parseDouble(  tmp[9] );
					pvalueAdj   = Double.parseDouble( tmp[10]);
					pvalueMin = Double.parseDouble(tmp[11]);


					BONFERRONI= tmp[12];
					FDR= tmp[13];
					BY= tmp[14];
					HOMMEL= tmp[15];
					HOLM= tmp[16];
					HOCHBERG= tmp[17];

					if(lhm_goid_go.containsKey(goID))
					{
						goDesc     = ((MyInnerGO)lhm_goid_go.get(goID)).getDesc();
						goCategory = ((MyInnerGO)lhm_goid_go.get(goID)).getCategory();

					}else
					{
						goDesc="None";
						goCategory="None";
					}



					//	buf.append( fileNameShort + "\t" + curLine + "\n");


					//	if( ! goCategory.equals("cellular_component")) // if you want to avoid cellular component

					// Vlad want to include them.

					{

						if(FilterOntologizer.isPassing_GO_FilterOfDescription(goDesc))
						{

							buf.append(fnameWithoutExt + "\t" +goID + "\t"  + goDesc+ "\t"  + goCategory+ "\t" 
									+ totTargetHit	+ "\t"  + totTargetSample+ "\t" + totBGtHit	+ "\t"  + totBGSample + "\t"   
									+ pvalue+ "\t"	+  BONFERRONI	+ "\t"  + 	FDR	+ "\t"  + 	BY	+ "\t"   
									+ "\t"  +  HOMMEL	+ "\t"  + 	HOLM	+ "\t"  + 	HOCHBERG + "\n");

						}
					}

				}


			}


		}

		String finalFileNameForCell = this.foldOutput + "/"+ ("GO_"+ curCellName + "." + this.thrPvalAdj );
								  
		
		System.out.println("Writing output in: " + finalFileNameForCell );

		CommonFunction.writeContentToFile( finalFileNameForCell,  curHeader + "\n" + buf+"");
		
		
	}


	void workForOneCellLine( String curCellName, String absPathCell)
	{
		loadAllFileNamesOfAcell(absPathCell);
		mergeAdjusted_Write(curCellName);

	}

	void workForAllCellLine()
	{


		FolderOperations.create_new_folder(this.foldOutput) ;

		String curInputFolderCellAbspath , curCellName;

		Vector<String> vectFolderCellline = FolderOperations.listFiles_Dir(foldResultsCAGE);



		/*
		 *  Iterate over all folders
		 */
		int totCell = vectFolderCellline.size();
		for(int i=0; i< totCell ;i++) // vectFolderCellline.size()
		{
			curCellName = vectFolderCellline.get(i);
			curInputFolderCellAbspath = this.foldResultsCAGE + "/" +  curCellName + "/" ;

			System.out.println("Working for cellline: " + curInputFolderCellAbspath);

			workForOneCellLine( curCellName ,  curInputFolderCellAbspath);
		}


	}



	void doProcessing()
	{
		loadAllGO(this.fnmListGO);
		workForAllCellLine();
		System.out.println("Merge finished ...");
	}


	public static void main(String[] args) {

		MergeResultAdjDifferentFolder_CellSpecific obj = new MergeResultAdjDifferentFolder_CellSpecific(  args[0],  args[1], args[2] , args[3], Double.parseDouble( args[4])  , args[5] );

		obj.doProcessing();
		
		//		MergeResultAdjDifferentFolder_CellSpecific obj = new MergeResultAdjDifferentFolder_CellSpecific( "./today/",  "-Parent-Child-Union-Bonferroni.txt.adj", "final.adj" , Double.parseDouble( "0.05") , "go-basic.obo.tsv" );




		// table-hsa-mir-139#4-Parent-Child-Union-Westfall-Young-Single-Step.txt.filter
		// table-hsa-mir-203#2-Parent-Child-Union-Bonferroni.txt.filter
		// table-hsa-mir-203#3-Parent-Child-Union-Bonferroni.txt.filter

//		
	

	}



}
