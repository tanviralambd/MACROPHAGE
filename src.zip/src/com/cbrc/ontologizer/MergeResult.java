package com.cbrc.ontologizer;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;

import com.cbrc.folderoperation.FolderOperations;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MergeResult {

	String inputDir;
	String inputExt;
	String fnmMerged;
	double thrPvalAdj;
	
	
	int thrHITintarget;
	

	public MergeResult(String inputDir, String inputExt, String fnmMerged,
			double thrPvalAdj) {
		super();
		this.inputDir = inputDir;
		this.inputExt = inputExt;
		this.fnmMerged = fnmMerged;
		this.thrPvalAdj = thrPvalAdj;
		
		System.out.println(this.inputDir );
		System.out.println(this.inputExt );
		System.out.println(this.fnmMerged  );
		System.out.println(this.thrPvalAdj  );
		
		
		
	}


	Vector<String> vectFname = new Vector<String>();
	void loadAllFname()
	{
		vectFname = FolderOperations.listAllFilesInDirectoryBasedOnExtensions(this.inputDir, this.inputExt );	
		System.out.println("Total file matching ext is: " + vectFname.size());
		
	}
	
	void merge()
	{
		String curFnameAbsPath="",fileNameShort;
		String curHeader="";
		String curLine;
		String tmp[];
		
		Path p ;
		int index0based_AdjPvalue = 10;
		
		StringBuffer buf = new StringBuffer();
		
		Vector<String> vectCurFileContent;
		
		for(int i=0; i<vectFname.size();i++)
		{
			curFnameAbsPath = this.inputDir+ "/"+ vectFname.get(i);
			
			p = Paths.get(curFnameAbsPath);
			fileNameShort = p.getFileName().toString();
			
			System.out.println("Checking file : "+ ( curFnameAbsPath)  );
			
			vectCurFileContent = CommonFunction.readlinesOfAfile(curFnameAbsPath);
			
			if( vectCurFileContent.size() > 0){
				curHeader = "miRNA"+ "\t" + vectCurFileContent.get(0);
				for(int ind=1; ind<vectCurFileContent.size() ;ind++)
				{
					
					curLine = vectCurFileContent.get(ind) ;
					tmp = ConstantValue.patTab.split(curLine);
					if( Double.parseDouble(tmp[index0based_AdjPvalue]) <= this.thrPvalAdj )
					{
					
						buf.append( fileNameShort + "\t" + curLine + "\n");
					}
					
					
				}
			}
			
		}
		
		
		
		CommonFunction.writeContentToFile(this.fnmMerged, curHeader + "\n" + buf+"");
	}

	void doProcessing()
	{
		loadAllFname();
		merge();
	}


	public static void main(String[] args) {
		
		MergeResult obj = new MergeResult(  args[0],  args[1], args[2] ,  Double.parseDouble( args[3])   );
		
//		MergeResult obj = new MergeResult( "./today/",  "-Parent-Child-Union-Bonferroni.txt.filter", "final.filter" , Double.parseDouble( "0.05")  );
		
//		MergeResult obj = new MergeResult( "./result/",  ".0.05", "final.filter" , Double.parseDouble( "0.05")  );
		
		
		
		// table-hsa-mir-139#4-Parent-Child-Union-Westfall-Young-Single-Step.txt.filter
		// table-hsa-mir-203#2-Parent-Child-Union-Bonferroni.txt.filter
		// table-hsa-mir-203#3-Parent-Child-Union-Bonferroni.txt.filter
		
		obj.doProcessing();
		
	}
	
	
	
}
