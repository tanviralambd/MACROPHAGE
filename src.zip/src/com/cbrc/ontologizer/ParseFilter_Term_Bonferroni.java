package com.cbrc.ontologizer;

import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import javax.sql.CommonDataSource;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ParseFilter_Term_Bonferroni {


	String fnameInput;
	String fnmOut;



	class MyValueComparator implements Comparator {

		LinkedHashMap  base;
		public MyValueComparator(LinkedHashMap hMap) {
			this.base = hMap;
		}

		public int compare(Object a, Object b) {

			MyInnerclass obj1 = (MyInnerclass) base.get(a);
			MyInnerclass obj2 = (MyInnerclass) base.get(b);

			if( obj1.getTotTargetHit() > obj2.getTotTargetHit()    ) {
				return -1;
			}  else {
				return 1;
			}
		}

	}

	class MyInnerclass
	{
		String goID;


		int totBGSample;
		int totBGtHit;


		int totTargetSample;
		int totTargetHit;

		double pvalue;
		double pvalueAdj;
		double pvalueMin;
		
		String goDesc;


		public String getGoID() {
			return goID;
		}
		public void setGoID(String goID) {
			this.goID = goID;
		}
		public int getTotBGSample() {
			return totBGSample;
		}
		public void setTotBGSample(int totBGSample) {
			this.totBGSample = totBGSample;
		}
		public int getTotBGtHit() {
			return totBGtHit;
		}
		public void setTotBGtHit(int totBGtHit) {
			this.totBGtHit = totBGtHit;
		}
		public int getTotTargetSample() {
			return totTargetSample;
		}

		public void setTotTargetSample(int totTargetSample) {
			this.totTargetSample = totTargetSample;
		}

		public int getTotTargetHit() {
			return totTargetHit;
		}

		public void setTotTargetHit(int totTargetHit) {
			this.totTargetHit = totTargetHit;
		}

		public double getPvalue() {
			return pvalue;
		}
		public void setPvalue(double pvalue) {
			this.pvalue = pvalue;
		}
		public double getPvalueAdj() {
			return pvalueAdj;
		}

		public void setPvalueAdj(double pvalueAdj) {
			this.pvalueAdj = pvalueAdj;
		}
		public double getPvalueMin() {
			return pvalueMin;
		}

		public void setPvalueMin(double pvalueMin) {
			this.pvalueMin = pvalueMin;
		}

		public String getGoDesc() {
			return goDesc;
		}
		public void setGoDesc(String goDesc) {
			this.goDesc = goDesc;
		}







		public MyInnerclass(String goID, int totTargetHit, String goDesc) {
			super();
			this.goID = goID;
			this.totTargetHit = totTargetHit;
			this.goDesc = goDesc;
		}







		public MyInnerclass(String goID, int totBGSample, int totBGtHit,
				int totTargetSample, int totTargetHit, double pvalue,
				double pvalueAdj, double pvalueMin, String goDesc) {
			super();
			this.goID = goID;
			this.totBGSample = totBGSample;
			this.totBGtHit = totBGtHit;
			this.totTargetSample = totTargetSample;
			this.totTargetHit = totTargetHit;
			this.pvalue = pvalue;
			this.pvalueAdj = pvalueAdj;
			this.pvalueMin = pvalueMin;
			this.goDesc = goDesc;
		}

	





	}


	public ParseFilter_Term_Bonferroni(String fnameInput, String fnmOut) {
		super();
		this.fnameInput = fnameInput;
		this.fnmOut = fnmOut;
	}

	void doProcessing()
	{

		String tmp[];

		////////////////////////////////////////////////HASH MAP /////////////


		LinkedHashMap lhMap = new LinkedHashMap();
		MyValueComparator vcomp =  new MyValueComparator(lhMap);
		TreeMap sorted_map = new TreeMap(vcomp);

		//  1. First insert valus into orig hashmap loop ....

		String goID;


		int totBGSample;
		int totBGtHit;


		int totTargetSample;
		int totTargetHit;

		double pvalue;
		double pvalueAdj;
		double pvalueMin;
		

		String goDesc;


		Vector <String> vectAll = CommonFunction.readlinesOfAfile(this.fnameInput);

		for(int i=1; i< vectAll.size() ; i++) {

			tmp = ConstantValue.patTab.split( vectAll.get(i) );


			goID = tmp[0];
			totBGSample = Integer.parseInt( tmp[1] );
			totBGtHit = Integer.parseInt( tmp[2] );


			totTargetSample = Integer.parseInt(  tmp[3] );
			totTargetHit = Integer.parseInt( tmp[4] );

			pvalue  = Double.parseDouble(  tmp[5] );
			pvalueAdj   = Double.parseDouble( tmp[6]);
			pvalueMin = Double.parseDouble(tmp[7]);
			
			goDesc = tmp[8];


//			lhMap.put( goID ,    new MyInnerclass( goID,totTargetHit, goDesc )  ) ;
			
			
			
			lhMap.put( goID ,    new MyInnerclass( goID,totBGSample, totBGtHit,
					            totTargetSample,totTargetHit, pvalue,
					            pvalueAdj , pvalueMin , goDesc)  ) ;
			
			
			
			
			
		}


		//  2.  // NOW SORTING IS DONE
		for (String key:(Set<String>)lhMap.keySet() ) {
			sorted_map.put(key, lhMap.get(key));
		}

		//  3. Write sorted values      
		StringBuffer bufResult = new StringBuffer();
		
		String resultHeader= "GO" + "\t"  + "Description"+ "\t"  
				+ "Count_Hit"	+ "\t"  + "Percentage_Hit" 
				+ "\t"  + "Pvalue" + "\t"  + "Pvalue_Adj" ;
		bufResult.append( resultHeader + "\n");
		
		MyInnerclass inner;
		Set set = sorted_map.entrySet();
		Iterator i = set.iterator();
		while(i.hasNext()) {
			Map.Entry me = (Map.Entry)i.next();
			inner =  (MyInnerclass)me.getValue()  ;

			
			goDesc = inner.getGoDesc();
			
			if(FilterOntologizer.isPassing_GO_FilterOfDescription(goDesc))
			{
			
				bufResult.append(inner.getGoID() + "\t"  + inner.getGoDesc()+ "\t"  
						+ inner.getTotTargetHit()	+ "\t"  + ( (double)inner.getTotTargetHit()/inner.getTotTargetSample()) 
						+ "\t"  + inner.getPvalue() + "\t"  + inner.getPvalueAdj() + "\n");
						
			}
			
			
			
			
			//			System.out.println( inner.getRankDistance() + "\t"  +           inner.getMotif().getId() );             
		}

		

//		String goID, int totBGSample, int totBGtHit,
//		int totTargetSample, int totTargetHit, double pvalue,
//		double pvalueAdj, double pvalueMin, String goDesc)
		
		CommonFunction.writeContentToFile(this.fnmOut, bufResult+"");

	}

	public static void main(String[] args) {


		ParseFilter_Term_Bonferroni obj = new ParseFilter_Term_Bonferroni(args[0] , args[1]);
//		ParseFilter_Term_Bonferroni obj = new ParseFilter_Term_Bonferroni( "table-hsa-let-7a-1-Term-For-Term-Bonferroni.txt" ,  "table-hsa-let-7a-1-Term-For-Term-Bonferroni.txt.tsv" );


		obj.doProcessing();


	}

}
