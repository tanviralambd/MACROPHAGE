package com.cbrc.ontologizer;



import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import javax.sql.CommonDataSource;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ParseFilter_ParentChild {


	String fnameInput;
	String fnmOut;
	String fnmListGO;
	double pvalAdjThr;



	class MyValueComparator implements Comparator {

		LinkedHashMap  base;
		public MyValueComparator(LinkedHashMap hMap) {
			this.base = hMap;
		}

		public int compare(Object a, Object b) {

			MyInnerclass obj1 = (MyInnerclass) base.get(a);
			MyInnerclass obj2 = (MyInnerclass) base.get(b);

			if( obj1.getTotTargetHit() > obj2.getTotTargetHit()    ) {
				return -1;
			}  else {
				return 1;
			}
		}

	}

	class MyInnerclass
	{
		String goID;


		int totBGSample;
		int totBGtHit;


		int totTargetSample;
		int totTargetHit;

		double pvalue;
		double pvalueAdj;
		double pvalueMin;

		String goDesc;
		String goCategory;


		public String getGoID() {
			return goID;
		}
		public void setGoID(String goID) {
			this.goID = goID;
		}
		public int getTotBGSample() {
			return totBGSample;
		}
		public void setTotBGSample(int totBGSample) {
			this.totBGSample = totBGSample;
		}
		public int getTotBGtHit() {
			return totBGtHit;
		}
		public void setTotBGtHit(int totBGtHit) {
			this.totBGtHit = totBGtHit;
		}
		public int getTotTargetSample() {
			return totTargetSample;
		}

		public void setTotTargetSample(int totTargetSample) {
			this.totTargetSample = totTargetSample;
		}

		public int getTotTargetHit() {
			return totTargetHit;
		}

		public void setTotTargetHit(int totTargetHit) {
			this.totTargetHit = totTargetHit;
		}

		public double getPvalue() {
			return pvalue;
		}
		public void setPvalue(double pvalue) {
			this.pvalue = pvalue;
		}
		public double getPvalueAdj() {
			return pvalueAdj;
		}

		public void setPvalueAdj(double pvalueAdj) {
			this.pvalueAdj = pvalueAdj;
		}
		public double getPvalueMin() {
			return pvalueMin;
		}

		public void setPvalueMin(double pvalueMin) {
			this.pvalueMin = pvalueMin;
		}

		public String getGoDesc() {
			return goDesc;
		}
		public void setGoDesc(String goDesc) {
			this.goDesc = goDesc;
		}


		public String getGoCategory() {
			return goCategory;
		}
		public void setGoCategory(String goCategory) {
			this.goCategory = goCategory;
		}
		public MyInnerclass(String goID, int totTargetHit, String goDesc) {
			super();
			this.goID = goID;
			this.totTargetHit = totTargetHit;
			this.goDesc = goDesc;
		}
		public MyInnerclass(String goID, int totBGSample, int totBGtHit,
				int totTargetSample, int totTargetHit, double pvalue,
				double pvalueAdj, double pvalueMin, String goDesc,
				String goCategory) {
			super();
			this.goID = goID;
			this.totBGSample = totBGSample;
			this.totBGtHit = totBGtHit;
			this.totTargetSample = totTargetSample;
			this.totTargetHit = totTargetHit;
			this.pvalue = pvalue;
			this.pvalueAdj = pvalueAdj;
			this.pvalueMin = pvalueMin;
			this.goDesc = goDesc;
			this.goCategory = goCategory;
		}


	}



	LinkedHashMap lhMap = new LinkedHashMap();
	MyValueComparator vcomp =  new MyValueComparator(lhMap);
	TreeMap sorted_map = new TreeMap(vcomp);

	class MyInnerGO
	{
		String id;
		String desc;
		String category;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getDesc() {
			return desc;
		}
		public void setDesc(String desc) {
			this.desc = desc;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public MyInnerGO(String id, String desc, String category) {
			super();
			this.id = id;
			this.desc = desc;
			this.category = category;
		}

	}


	LinkedHashMap<String, MyInnerGO> lhm_goid_go = new LinkedHashMap<String, ParseFilter_ParentChild.MyInnerGO>();



	void loadAllGO(String fnmGOList)
	{
		Vector<String> vectListGO = CommonFunction.readlinesOfAfile(this.fnmListGO);
		String curLine;
		String tmp[];

		String id, desc, category;

		for(int i=0; i<vectListGO.size();i++)
		{
			curLine = vectListGO.get(i);
			tmp = ConstantValue.patTab.split(curLine);


			id = tmp[0];
			desc = tmp[1];
			category = tmp[2];
			if(lhm_goid_go.containsKey(id))
			{
				System.out.println("Already exist: " + id);
			}else
			{
				lhm_goid_go.put(id, new MyInnerGO(id, desc, category));
			}

		}

		System.out.println("Total Go term " + lhm_goid_go.size());

	}

	void loadAndSortOntologizerResult(String fnmInput)
	{

		//  1. First insert valus into orig hashmap loop ....

		String goID;


		int totBGSample;
		int totBGtHit;


		int totTargetSample;
		int totTargetHit;

		double pvalue;
		double pvalueAdj;
		double pvalueMin;


		String goDesc , goCategory;
		String tmp[];

		Vector <String> vectAll = CommonFunction.readlinesOfAfile(this.fnameInput);

		for(int i=1; i< vectAll.size() ; i++) {

			tmp = ConstantValue.patTab.split( vectAll.get(i) );


			goID = tmp[0];
			totBGSample = Integer.parseInt( tmp[1] );
			totBGtHit = Integer.parseInt( tmp[2] );


			totTargetSample = Integer.parseInt(  tmp[3] );
			totTargetHit = Integer.parseInt( tmp[4] );

			pvalue  = Double.parseDouble(  tmp[9] );
			pvalueAdj   = Double.parseDouble( tmp[10]);
			pvalueMin = Double.parseDouble(tmp[11]);


			// goDesc = tmp[8];
			if(lhm_goid_go.containsKey(goID))
			{
				goDesc     = ((MyInnerGO)lhm_goid_go.get(goID)).getDesc();
				goCategory = ((MyInnerGO)lhm_goid_go.get(goID)).getCategory();

			}else
			{
				goDesc="None";
				goCategory="None";
			}






			lhMap.put( goID ,    new MyInnerclass( goID,totBGSample, totBGtHit,
					totTargetSample,totTargetHit, pvalue,
					pvalueAdj , pvalueMin , goDesc ,goCategory)  ) ;



		}


		//  2.  // NOW SORTING IS DONE
		for (String key:(Set<String>)lhMap.keySet() ) {
			sorted_map.put(key, lhMap.get(key));
		}



		System.out.println("Total Mapping term " + lhMap.size());
	}


	void writeFilteredResultWithThreshold(String fnmOu)
	{

		String goDesc, curCategory;
		String tmp[];
		double curPvalAdj;
		//  3. Write sorted values      
		StringBuffer bufResult = new StringBuffer();

		String resultHeader= "GO" + "\t"  + "Description"+ "\t"  + "Category"+ "\t" 
				+ "Count_Hit"	+ "\t"  + "Percentage_Hit" 
				+ "\t"  + "Pvalue" + "\t"  + "Pvalue_Adj" ;
		bufResult.append( resultHeader + "\n");

		MyInnerclass inner;
		Set set = sorted_map.entrySet();
		Iterator i = set.iterator();
		while(i.hasNext()) {
			Map.Entry me = (Map.Entry)i.next();
			inner =  (MyInnerclass)me.getValue()  ;


			goDesc = inner.getGoDesc();
			curCategory = inner.getGoCategory();
			curPvalAdj = inner.getPvalueAdj();

			if(FilterOntologizer.isPassing_GO_FilterOfDescription(goDesc))
			{

				

					if( curPvalAdj <= this.pvalAdjThr)
					{
						if( ! curCategory.equals("cellular_component"))
						{

							bufResult.append(inner.getGoID() + "\t"  + inner.getGoDesc()+ "\t"  + inner.getGoCategory()+ "\t" 
									+ inner.getTotTargetHit()	+ "\t"  + ( (double)inner.getTotTargetHit()/inner.getTotTargetSample()) 
									+ "\t"  + inner.getPvalue() + "\t"  + inner.getPvalueAdj() + "\n");


						}

					}


			}




			//			System.out.println( inner.getRankDistance() + "\t"  +           inner.getMotif().getId() );             
		}



		//		String goID, int totBGSample, int totBGtHit,
		//		int totTargetSample, int totTargetHit, double pvalue,
		//		double pvalueAdj, double pvalueMin, String goDesc)

		CommonFunction.writeContentToFile(fnmOu, bufResult+"");
	}





	public ParseFilter_ParentChild(String fnameInput, String fnmOut,
			String fnmListGO, double pvalAdjThr) {
		super();
		this.fnameInput = fnameInput;
		this.fnmOut = fnmOut;
		this.fnmListGO = fnmListGO;
		this.pvalAdjThr = pvalAdjThr;
	}

	void doProcessing()
	{

		// load GO description
		loadAllGO(this.fnmListGO);

		//	Load data into sorted HASH MAP  
		loadAndSortOntologizerResult(this.fnameInput);

		// write filtered data
		writeFilteredResultWithThreshold(this.fnmOut);



	}

	public static void main(String[] args) {


		ParseFilter_ParentChild obj = new ParseFilter_ParentChild(args[0] , args[1] , args[2]  , Double.parseDouble( args[3] )  );
		//		ParseFilter_ParentChild obj = new ParseFilter_ParentChild( "table-hsa-mir-139#4-Parent-Child-Union-Westfall-Young-Single-Step.txt" ,  
		//				"table-hsa-mir-139#4-Parent-Child-Union-Westfall-Young-Single-Step.txt.filter" , "go-basic.obo.tsv" , Double.parseDouble("0.1")  );


		obj.doProcessing();


	}

}

