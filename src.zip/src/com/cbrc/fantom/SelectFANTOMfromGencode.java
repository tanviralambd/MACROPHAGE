package com.cbrc.fantom;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SelectFANTOMfromGencode {

	
	String fnmFANTOMid;
	String fnmAllGencodeTrx;
	String foutAllFantomTrx;
	
	
	Set<String> setFantomID = new LinkedHashSet<String>();
	
	
	void init(String fantomID, String gencode, String out)
	{
		this.fnmFANTOMid = fantomID;
		this.fnmAllGencodeTrx = gencode;
		this.foutAllFantomTrx = out;
	}
	
	void doProcessing()
	{
	
		
		setFantomID= CommonFunction.readlinesOfAfileInSet(this.fnmFANTOMid);
		System.out.println("Total Unique Fantom lncRNA ID:"+setFantomID.size());
		
		Vector<String> vectGencode = CommonFunction.readlinesOfAfile(this.fnmAllGencodeTrx);
		
		String tmp[];
		StringBuffer bufResult = new StringBuffer();
		
		for(int i=0; i<vectGencode.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectGencode.get(i));
			if(setFantomID.contains(tmp[3] ))
			{
				bufResult.append( vectGencode.get(i) +"\n");
			}
			
		}
		
		
		CommonFunction.writeContentToFile(this.foutAllFantomTrx, bufResult+"");
	}
	
	
	
	public static void main(String[] args) {
		
		SelectFANTOMfromGencode obj = new SelectFANTOMfromGencode();
		
		obj.init(args[0], args[1], args[2]);
		
		obj.doProcessing();
		
	}
}
