package com.cbrc.functionreport;

import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SelectGOtermsBasedonID {

	String fnmAllGoerms;
	String fnmIDs;
	
	String fnmOut;
	
	
	public SelectGOtermsBasedonID(String fnmAllGoerms, String fnmIDs,
			String fnmOut) {
		super();
		this.fnmAllGoerms = fnmAllGoerms;
		this.fnmIDs = fnmIDs;
		this.fnmOut = fnmOut;
	}


	void doProcessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAllGoerms);
		
		Set<String> setIDs = CommonFunction.readlinesOfAfileInSet(this.fnmIDs);
		
		
		String tmp[];
		StringBuffer bufRes = new StringBuffer();
		
		String rnaid, goID, goDess, goType,pval,FDR;
		
		
		String header = "Trx" + "\t" 
				+ "GO" + "\t"
				+ "Description" + "\t"
				+ "Type" + "\t"
				+ "Pvalue" + "\t"
				+  "FDR"  ;
		
		for(int i=0; i< vectAll.size() ;i++)
		{
			
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			rnaid = tmp[0];
			goID = tmp[1];
			goDess = tmp[2];
			goType = tmp[3];
			
			pval=tmp[8];
			FDR = tmp[10];
			
			
			if(setIDs.contains( rnaid))
			{
				bufRes.append( rnaid + "\t" 
							+ goID + "\t"
							+ goDess + "\t"
							+ goType + "\t"
							+ pval + "\t"
							+ FDR + "\n" 
						);
			}
			
			
		}
		
		
		
		CommonFunction.writeContentToFile(this.fnmOut,header + "\n" +  bufRes+"");
		
		
	}
	
	
	public static void main(String[] args) {
		
		String fold="./FunctionReport/";
		
		int selectGo=3; // Ifng, Il413, Mtbonly
		int upDownSpecific=3; // 1 - up ; 2 - down ; 3- Specific
	
		String fileInputIDs= ""; 
		String goAll="";
		
		switch (selectGo) {
		case 1:
			goAll=  "GO.IFNgMtb.txt"; 
			
			if(upDownSpecific==1)
			{
				fileInputIDs=  "IFNgMtb.txt.up.id";
			}else if(upDownSpecific==2)
			{
				fileInputIDs=  "IFNgMtb.txt.down.id";
			}else if(upDownSpecific==3)
			{
				fileInputIDs=  "IFNgMtb.txt.specific.id.RNAid";
			}
			
			break;
		case 2:
			goAll=   "GO.IL413Mtb.txt";
			
			if(upDownSpecific==1)
			{
				fileInputIDs=  "IL413Mtb.txt.up.id";
			}else  if(upDownSpecific==2)
			{
				fileInputIDs=  "IL413Mtb.txt.down.id";
			}else if(upDownSpecific==3)
			{
				fileInputIDs=  "IL413Mtb.txt.specific.id.RNAid";
			}
			
			break;
		case 3:
			goAll=  "GO.MtbOnly.txt";
			
			if(upDownSpecific==1)
			{
				fileInputIDs=  "MtbOnly.txt.up.id";
			}else  if(upDownSpecific==2)
			{
				fileInputIDs=  "MtbOnly.txt.down.id";
			}else if(upDownSpecific==3)
			{
				fileInputIDs=  "MtbOnly.txt.specific.id.RNAid";
			}
			
			break;
		default:
			break;
		}
		
		
		
		
		
//		SelectGOtermsBasedonID obj = new SelectGOtermsBasedonID(args[0], args[1], args[2]);
		
		SelectGOtermsBasedonID obj = new SelectGOtermsBasedonID(
				fold+ goAll, fold+fileInputIDs, fold+fileInputIDs+".GO" );
		
		obj.doProcessing();
		
	}
	
	
}
