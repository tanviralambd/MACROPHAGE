package com.cbrc.functionreport;




import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SelectStimulationSpecificID {

	
	String fnmAll;
	String fnmSelectedSpecific;
	String fnmOut;
	
	
	
	
	
	public SelectStimulationSpecificID(String fnmAll,
			String fnmSelectedSpecific, String fnmOut) {
		super();
		this.fnmAll = fnmAll;
		this.fnmSelectedSpecific = fnmSelectedSpecific;
		this.fnmOut = fnmOut;
	}







	LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();

	
	void doProcessing()
	{
		loadSpecific();
		loadAll();
	}
	
	
	void loadSpecific()
	
	{
	
		lhm_Key_value = CommonFunction.readlinesOfAfile_asMap_EachLine(this.fnmSelectedSpecific, 0);
		
	}
	
	void loadAll(){
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAll);
		
		String tmp[];
		String cage,rna;
	
		
		
		StringBuffer bufRes = new StringBuffer();

		Set<String> setSpecificRNA = new LinkedHashSet<String>();

		
		
		
		
		for( int i=0 ;  i<  vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			rna = tmp[0];
			cage = tmp[1];
			
			
			if(lhm_Key_value.containsKey(cage))
			{
				
				String tmpRNA [] = ConstantValue.patSemiColon_Comma.split( rna);
				for( int r = 0 ; r< tmpRNA.length ; r++)
				{
					setSpecificRNA.add(tmpRNA[r]);
				}
				
//				setSpecificRNA.add( rna);
				
				
			}
		}

		
		/*
		 *  Write RNAid set
		 */
		
		String[] arr = (String[]) setSpecificRNA.toArray(new String[setSpecificRNA.size()]);
		int setSize = arr.length;
		for(int c=0; c < setSize;c++)
		 {
		  if(c==setSize-1)
			  bufRes.append(arr[c]+"\n");
		  else
			  bufRes.append(arr[c]+"\n");

		} 
		
		CommonFunction.writeContentToFile(this.fnmOut,   bufRes+"");
	
		
		
		
	}
	
	
	
	



	public static void main(String[] args) {
		
//		SelectUpDownRegulatedID obj = new SelectUpDownRegulatedID(args[0], args[1], args[2]);
		
		
		
		String fold="./FunctionReport/";
		String fileInput="";
		
		int type= 1;
		switch (type) {
			case 1:
				fileInput=  "IFNgMtb.txt" ;
			break;
			case 2:
				fileInput=  "IL413Mtb.txt"; 
				break;
			case 3:
				fileInput= "MtbOnly.txt"; 
				break;
				

			default:
				break;
		}
		  
		
		SelectStimulationSpecificID obj = new SelectStimulationSpecificID(
				fold+fileInput, 
				fold+fileInput+".specific.id",
				fold+fileInput+".specific.id.RNAid");
		
		
		
		obj.doProcessing();
		
		
	}
	
	
}
