package com.cbrc.functionreport;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SelectUpDownRegulatedID {

	
	String fnmAll;
	String fnmSelectedUP;
	String fnmSelectedDOWN;
	
	
	
	void doProcessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAll);
		
		String tmp[];
		int index, totalPointFC, totalUp, totalDown;
		String cage,rna;
		double timepointsFC[];
		
		StringBuffer allUp = new StringBuffer();
		StringBuffer allDown = new StringBuffer();
		Vector<String> vectAllUp = new Vector<String>();
		Vector<String> vectAllDown = new Vector<String>();
		
		
		
		
		for( int i=0 ;  i<  vectAll.size() ;i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			rna = tmp[0];
			cage = tmp[1];
			
			totalPointFC = tmp.length -2 ; 
			timepointsFC = new double[totalPointFC  ];
			
			
			index=0;
			totalUp=0;totalDown=0;
			
			for( int k=2;  k<tmp.length ;k++)
			{
				timepointsFC[index] = Double.parseDouble( tmp[k] );
				
				
				
				if( timepointsFC[index] >= 0 && timepointsFC[index]>= 2.00 )
				{
					totalUp++;
				}else if ( timepointsFC[index] < 0 && timepointsFC[index]  < -2.00  )
				{
					totalDown++;
				}
				
				index++;
			}
			
			if(totalUp == totalPointFC)
			{
				vectAllUp.add(rna);
				
				
			}else if( totalDown == totalPointFC)
			{
				vectAllDown.add(rna);
				
				
			}
			
			
			
		}
		
		
		// Write results

		for( int i=0 ;  i<  vectAllUp.size() ;i++)
		{
			tmp = ConstantValue.patSemiColon_Comma.split( vectAllUp.get(i));
			
			for( int j=0 ; j< tmp.length;j++)
			{
				allUp.append(tmp[j] + "\n");
			}
			
		}

		
		for( int i=0 ;  i<  vectAllDown.size() ;i++)
		{
			tmp = ConstantValue.patSemiColon_Comma.split( vectAllDown.get(i));
			
			for( int j=0 ; j< tmp.length;j++)
			{
				allDown.append(tmp[j] + "\n");
			}
			
		}
		
		
		
		CommonFunction.writeContentToFile(this.fnmSelectedUP,   allUp+"");
		CommonFunction.writeContentToFile(this.fnmSelectedDOWN, allDown+"");
		
		
		
	}
	
	
	
	
	public SelectUpDownRegulatedID(String fnmAll, String fnmSelectedUP,
			String fnmSelectedDOWN) {
		super();
		this.fnmAll = fnmAll;
		this.fnmSelectedUP = fnmSelectedUP;
		this.fnmSelectedDOWN = fnmSelectedDOWN;
	}




	public static void main(String[] args) {
		
//		SelectUpDownRegulatedID obj = new SelectUpDownRegulatedID(args[0], args[1], args[2]);
		
		
		
		String fold="./FunctionReport/";
		String fileInput="";
		
		int type= 3;
		switch (type) {
			case 1:
				fileInput=  "IFNgMtb.txt" ;
			break;
			case 2:
				fileInput=  "IL413Mtb.txt"; 
				break;
			case 3:
				fileInput= "MtbOnly.txt"; 
				break;
				

			default:
				break;
		}
		  
		
		SelectUpDownRegulatedID obj = new SelectUpDownRegulatedID(
				fold+fileInput, 
				fold+fileInput+".up.id", 
				fold+fileInput+".down.id"  );
		
		
		
		obj.doProcessing();
		
		
	}
	
	
}
