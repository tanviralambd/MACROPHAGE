package com.cbrc.cageHarukazu;



import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;


/*
 *  1. Make the header Readable
 *  2. Handle Replicate
 *  3. Remove the entry with None
 *   
 */

public class AnnotationToMatrixReadable {

	String finAnnotation;
	String foutMatrix;
	
	String finLibUnreadble;
	String foutLibReadble;

	

	int startT,endT;
	
	int totalWithoutAll=0;
	int totalWithAll=0;

	Vector<String > vectOne;
	Vector<String > vectLibFile;
	
	String readableHeader;

	String newLabel="";

	LinkedHashSet<String> setReplica = new LinkedHashSet<String>();
	
	LinkedHashSet<String> setReplicaFromLib = new LinkedHashSet<String>();
	
	
	int getReplicaNo(String prefix)
	{
		int repNo=0 , curNo=0;
		String curHead;
		Iterator itr = setReplica.iterator();
		while( itr.hasNext())
		{
			curHead = (String)itr.next();
			if(curHead.startsWith(prefix))
			{
				repNo++;
			}
		 	
		}
		
		return repNo+1;
	}
	
	int getReplicaNo_libsize(String prefix)
	{
		int repNo=0 , curNo=0;
		String curHead;
		Iterator itr = setReplicaFromLib.iterator();
		while( itr.hasNext())
		{
			curHead = (String)itr.next();
			if(curHead.startsWith(prefix))
			{
				repNo++;
			}
		 	
		}
		
		return repNo+1;
	}
	
	
	void libsize_Unreadable_Readable()
	{
		

		this.totalWithoutAll=0;
		this.totalWithAll=0;

		vectLibFile = CommonFunction.readlinesOfAfile(this.finLibUnreadble);

		/*
		 *   1st line : library name UnReadable
		 */
		String firstLine = vectLibFile.get(0);
		String tmp[] = ConstantValue.patTab.split(firstLine);

		int totColumn = tmp.length; //  values...
		int timePointsColumn[] = new int[totColumn];
		int timePointsCount=0;
		String newColName="";
		int replicaNo;
		String finalColName="";

		
		/// YOU CAN ALSO USE READABLE HEADER FROM ANNOTATION: JUST 1 LINE CODE 
		// bufResult.append(readableHeader+"\n");
		
		/// from UNREADABLE FILE
		
		StringBuffer bufHead = new StringBuffer();
		for(int i=0;i<tmp.length;i++)
		{
				if(tmp[i].startsWith("count"))
			{
				newColName= getNewHeader(tmp[i]);
				timePointsColumn[timePointsCount] = Integer.parseInt(ConstantValue.patUnderscore.split(newColName)[2] ) ;

				if  ( timePointsColumn[ timePointsCount] >= startT  &&   timePointsColumn[ timePointsCount] <= endT ){ // If you want to select only data within Range
					
					replicaNo = getReplicaNo_libsize(newColName);
					finalColName = newColName+"_"+replicaNo ;
					bufHead.append( finalColName+"\t");
					setReplicaFromLib.add(finalColName);
				}
				
				timePointsCount++;
				
			}
		}
		
		
		
		StringBuffer bufResult = new StringBuffer();
		bufResult.append(bufHead+"\n");
		
				
		/*
		 *   2nd line : library Size
		 */
		//  TimePoints values...
		int startTimepoint_index0based=0;

		for(int i=1;i< vectLibFile.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectLibFile.get(i)); 

			
			// append Time Points
			for(int k=startTimepoint_index0based; k<tmp.length ;k++){

				if  ( timePointsColumn[k-startTimepoint_index0based] >= startT  &&   timePointsColumn[k-startTimepoint_index0based] <= endT ){ // If you want to select only data within Range
					
					bufResult.append(tmp[k] +"\t");
					
				}

			}

			
			bufResult.append("\n");

		}

		CommonFunction.writeContentToFile(foutLibReadble, bufResult+"");
		
		
	}
	
	void init(String f1, String fo , String st, String en , String finLibsizeUnreadable, String foutLibsizeReadable) {

		this.finAnnotation =f1;
		this.foutMatrix = fo;
		this.startT = Integer.parseInt(st);
		this.endT = Integer.parseInt(en);
		
		this.finLibUnreadble = finLibsizeUnreadable;
		this.foutLibReadble = foutLibsizeReadable;
	}
	
	
	/*
	 *  1. Make the heade readable
	 *  2. Select only column within range
	 */
	void annotTomatrix() { //(String f1, String fo , String st, String en) {

//		this.fin1 =f1;
//		this.fout = fo;
//		this.startT = Integer.parseInt(st);
//		this.endT = Integer.parseInt(en);

		this.totalWithoutAll=0;
		this.totalWithAll=0;

		vectOne = CommonFunction.readlinesOfAfile(this.finAnnotation);

		/*
		 *  Change header
		 */
		String firstLine = vectOne.get(0);
		String tmp[] = ConstantValue.patTab.split(firstLine);
		String tmpRepNo[];
		Matcher m;

		int totColumn = tmp.length; // GENEID | CLUSTERID |  values...
		int timePointsColumn[] = new int[totColumn-2];
		int timePointsCount=0;
		String newColName="";
		int replicaNo;
		String finalColName="" , colNameUnReadable , curMatch;

		StringBuffer bufHead = new StringBuffer();
		for(int i=0;i<tmp.length;i++)
		{
			if(i==1) // skip the gene names column
				continue;
			colNameUnReadable = tmp[i];
			if(tmp[i].startsWith("count"))
			{
				
				newColName= getNewHeader(colNameUnReadable);
				timePointsColumn[timePointsCount] = Integer.parseInt(ConstantValue.patUnderscore.split(newColName)[2] ) ;

				if  ( timePointsColumn[ timePointsCount] >= startT  &&   timePointsColumn[ timePointsCount] <= endT ){ // If you want to select only data within Range
					
					// new method
					m=  ConstantValue.patReplicaFantom.matcher(colNameUnReadable) ;
					if (m.find()) {

				        curMatch = m.group();
				        int indexDot = curMatch.indexOf('.');
				        replicaNo = Integer.parseInt(curMatch.substring(1, indexDot));
				        finalColName = newColName+"_"+replicaNo ;
				        bufHead.append( finalColName+"\t");
				    }
					
					// previous Method
//					tmpRepNo = ConstantValue.patReplicaFantom.split(colNameUnReadable);
//					replicaNo = getReplicaNo(newColName);
//					finalColName = newColName+"_"+replicaNo ;
//					bufHead.append( finalColName+"\t");
//					setReplica.add(finalColName);
					
				}
				
				timePointsCount++;
				
			}else
			{
				bufHead.append(colNameUnReadable+"\t");
			}
		}
		readableHeader = bufHead.toString();
		readableHeader.trim();
		
		//		System.out.println(res);
		//		for(int k=0;  k<timePointsColumn.length;k++)
		//		{
		//			System.out.print(timePointsColumn[k] + "\t" );
		//		}


		StringBuffer bufResult = new StringBuffer();
		bufResult.append(readableHeader+"\n");



		/*
		 *  Remove None and handle all values: 2nd to last line
		 */
		// GENEID | CLUSTERID |  TimePoints values...
		int startTimepoint_index0based=2;

		for(int i=1;i< vectOne.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectOne.get(i)); 

			// Skip the no CAGE mapping : None N/A cases 
//			if(tmp[1].equals(ConstantValue.noneStr)) 
//			{
//				continue;
//			}

			// append GeneID
			bufResult.append(tmp[0] +"\t");


			// append Time Points
			for(int k=startTimepoint_index0based; k<tmp.length ;k++){

				if  ( timePointsColumn[k-startTimepoint_index0based] >= startT  &&   timePointsColumn[k-startTimepoint_index0based] <= endT ){ // If you want to select only data within Range
					
//					if(k==tmp.length-1)
//						bufResult.append(tmp[k] +"\n");
//					else
						
					bufResult.append(tmp[k] +"\t");
					
					
				}

			}

			
			bufResult.append("\n");

		}

		CommonFunction.writeContentToFile(this.foutMatrix, bufResult+"");

	}


	String getNewHeader (String prevHeader)
	{

		boolean found=false;
		Matcher m;

		// 0 hr
		m=  ConstantValue.pat_without_0hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[0];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_0hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[0];
			found = true;
			//			return found;
		}

		// 2 hr
		m=  ConstantValue.pat_without_2hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[1];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_2hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[1];
			found = true;
			//			return found;
		}



		// 4 hr
		m=  ConstantValue.pat_without_4hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[2];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_4hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[2];
			found = true;
			//			return found;
		}




		// 6 hr
		m=  ConstantValue.pat_without_6hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[3];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_6hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[3];
			found = true;
			//			return found;
		}




		// 12 hr
		m=  ConstantValue.pat_without_12hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[4];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_12hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[4];
			found = true;
			//			return found;
		}




		// 24 hr
		m=  ConstantValue.pat_without_24hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[5];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_24hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[5];
			found = true;
			//			return found;
		}




		// 28 hr
		m=  ConstantValue.pat_without_28hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[6];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_28hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[6];
			found = true;
			//			return found;
		}




		// 36 hr
		m=  ConstantValue.pat_without_36hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[7];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_36hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[7];
			found = true;
			//			return found;
		}




		// 48 hr
		m=  ConstantValue.pat_without_48hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[8];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_48hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[8];
			found = true;
			//			return found;
		}




		// 72 hr
		m=  ConstantValue.pat_without_72hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[9];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_72hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[9];
			found = true;
			//			return found;
		}




		// 120 hr
		m=  ConstantValue.pat_without_120hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_Without[10];
			found = true;
			//			return found;
		}
		m=  ConstantValue.pat_with_120hr.matcher(prevHeader) ;
		if(m.find())
		{
			newLabel = ConstantValue.head_With[10];
			found = true;
			//			return found;
		}







		return newLabel;

	}


	void calculateCount(String hour, Pattern patWithout, Pattern pat)
	{
		int totHitWith=0;
		int totHitWithout=0;



		totHitWithout=0;
		for(int i=0; i<vectOne.size();i++)
		{
			Matcher m=  patWithout.matcher(vectOne.get(i)) ;
			if(m.find())
			{
				//				System.out.println(vectOne.get(i) + "#####" + m.groupCount());
				totHitWithout++;
				//				System.out.println(m.group());
			}
		}
		totalWithoutAll+=totHitWithout;


		totHitWith=0;
		for(int i=0; i<vectOne.size();i++)
		{
			Matcher m=  pat.matcher(vectOne.get(i)) ;
			if(m.find())
			{
				//				System.out.println(vectOne.get(i) + "#####" + m.groupCount());
				totHitWith++;
				//				System.out.println(m.group());
			}
		}
		totalWithAll+=totHitWith;

		//		System.out.println("Total hit found hour: "+ hour + ":\t"+ totHitWithout + "/" + totHitWith);

		System.out.println(totHitWithout + "/" + totHitWith);
	}

	void doProcessing()
	{
		annotTomatrix();
		libsize_Unreadable_Readable();
		
		
	}
	
	public static void main(String[] args) {
		AnnotationToMatrixReadable obj = new AnnotationToMatrixReadable();

		/*
		 *  Non-Stimulated
		 */

		// mouse_macrophage_TB_infection_non-stimulated.counts.csv.header
//		obj.init("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.annotation" ,"mouse_macrophage_TB_infection_non-stimulated.counts.csv.matrix.24.120" , "24" , "120" );

		/*
		 *  Alternative
		 */
		//		obj.changerHeader("mouse_macrophage_TB_infection_IL4.counts.csv.matrix" ,"out.txt"  );
		//		obj.changerHeader("mouse_macrophage_TB_infection_IL13.counts.csv.matrix" ,"out.txt"  );
		//		obj.changerHeader("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.matrix" ,"out.txt"  );

		/*
		 *  classical
		 */
		//		obj.changerHeader("mouse_macrophage_TB_infection_IFNg.counts.csv.matrix" ,"out.txt"  );

		
		obj.init("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.annotation" , "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.matrix.24.24"    , "24" , "24",
		      "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.libUnreadable" , "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.matrix.24.24.lib");

		
//		obj.init(args[0], args[1] ,args[2] , args[3] , args[4] , args[5]);
		obj.doProcessing();
		
				

	}
}

