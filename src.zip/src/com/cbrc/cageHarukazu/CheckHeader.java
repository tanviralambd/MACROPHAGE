package com.cbrc.cageHarukazu;



import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class CheckHeader {

	String fin1;
	String fin2;
	
	String fout;
	
	int totalWithoutAll=0;
	int totalWithAll=0;
	
	Vector<String > vectOne;
	Vector<String > vectTwo ;
	
	void makeHeaderList(String f1, String fo) {
		
		this.fin1 =f1;
		this.fout = fo;
		
		this.totalWithoutAll=0;
		this.totalWithAll=0;
		
		vectOne = CommonFunction.readlinesOfAfile(this.fin1);
		
		System.out.println("\n ************"+ fin1 + "***************");

		calculateCount("0", ConstantValue.pat_without_0hr, ConstantValue.pat_with_0hr);
		
		calculateCount("2", ConstantValue.pat_without_2hr, ConstantValue.pat_with_2hr);
		calculateCount("4", ConstantValue.pat_without_4hr, ConstantValue.pat_with_4hr);
		calculateCount("6", ConstantValue.pat_without_6hr, ConstantValue.pat_with_6hr);
		calculateCount("12", ConstantValue.pat_without_12hr, ConstantValue.pat_with_12hr);
		calculateCount("24", ConstantValue.pat_without_24hr, ConstantValue.pat_with_24hr);
		System.out.println("--------------------------------------");
		calculateCount("28", ConstantValue.pat_without_28hr, ConstantValue.pat_with_28hr);
		calculateCount("36", ConstantValue.pat_without_36hr, ConstantValue.pat_with_36hr);
		calculateCount("48", ConstantValue.pat_without_48hr, ConstantValue.pat_with_48hr);
		calculateCount("72", ConstantValue.pat_without_72hr, ConstantValue.pat_with_72hr);
		calculateCount("120", ConstantValue.pat_without_120hr, ConstantValue.pat_with_120hr);
		System.out.println("===========================================");
		
		System.out.println("Total  found Without:"+ totalWithoutAll + ":\t With:"+ totalWithAll);
		
		

		
	}
	
	
	void calculateCount(String hour, Pattern patWithout, Pattern pat)
	{
		int totHitWith=0;
		int totHitWithout=0;
		

		
		totHitWithout=0;
		for(int i=0; i<vectOne.size();i++)
		{
			Matcher m=  patWithout.matcher(vectOne.get(i)) ;
			if(m.find())
			{
//				System.out.println(vectOne.get(i) + "#####" + m.groupCount());
				totHitWithout++;
//				System.out.println(m.group());
			}
		}
		totalWithoutAll+=totHitWithout;
		
		
		totHitWith=0;
		for(int i=0; i<vectOne.size();i++)
		{
			Matcher m=  pat.matcher(vectOne.get(i)) ;
			if(m.find())
			{
//				System.out.println(vectOne.get(i) + "#####" + m.groupCount());
				totHitWith++;
//				System.out.println(m.group());
			}
		}
		totalWithAll+=totHitWith;
		
//		System.out.println("Total hit found hour: "+ hour + ":\t"+ totHitWithout + "/" + totHitWith);
		
		System.out.println("Testing hour:"+ hour + "\t NoLibWithoutMtb: " + totHitWithout + "\t NoLibWithMtb: "+ totHitWith);
	}
	
	public static void main(String[] args) {
		CheckHeader obj = new CheckHeader();
		
//		obj.makeHeaderList(args[0], args[1] , args[2]);
		
		/*
		 *  Classical
		 */
		
		// mouse_macrophage_TB_infection_IFNg.counts.csv
		
		/*
		 * Alternative
		 */
		
		// mouse_macrophage_TB_infection_IL4.counts.csv.header
		// "mouse_macrophage_TB_infection_IL13.counts.csv.header"
		// "mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header"
		
		
		/*
		 *  Non-Stimulated
		 */
		
		// mouse_macrophage_TB_infection_non-stimulated.counts.csv.header
		obj.makeHeaderList("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.header" ,"out.txt"  );
		
		/*
		 *  Alternative
		 */
//		obj.makeHeaderList("mouse_macrophage_TB_infection_IL4.counts.csv.header" ,"out.txt"  );
//		obj.makeHeaderList("mouse_macrophage_TB_infection_IL13.counts1.csv.header" ,"out.txt"  );
//		obj.makeHeaderList("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header" ,"out.txt"  );
//		
//		/*
//		 *  classical
//		 */
//		obj.makeHeaderList("mouse_macrophage_TB_infection_IFNg.counts.csv.header" ,"out.txt"  );
		
		
	}
}

