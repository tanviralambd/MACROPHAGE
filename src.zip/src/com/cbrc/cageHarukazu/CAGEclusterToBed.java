package com.cbrc.cageHarukazu;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/*
 *  Input: File with 1 column. Fromat: chr10:100051839..100051903,-
 *  Output: BED format clusters
 */
public class CAGEclusterToBed {

	
	String fnmCageClst;
	String fnmBedOut;
	
	
	
	void doProcessing()
	{
		Vector<String> vectCAGEclst = CommonFunction.readlinesOfAfile(this.fnmCageClst);
		System.out.println("Total cluster:"+vectCAGEclst.size());
		
		StringBuffer buf = new StringBuffer();
		String tmp[];
		String curLine;
		
		for(int i=0; i<vectCAGEclst.size()  ;i++)
		{
			if(vectCAGEclst.get(i).startsWith("chr")) // some line is header. So, not start with chr
			{
			
				tmp = ConstantValue.patFantom5Cage.split( vectCAGEclst.get(i) );
				curLine = tmp[0] + "\t" + (Integer.parseInt(tmp[1])-1)  + "\t" + tmp[2]   + "\t" + vectCAGEclst.get(i)   + "\t" + "0"   + "\t" + tmp[3]  ;
				buf.append(curLine+"\n");
				
			}
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmBedOut, buf+"");
		
	}
	
	
	
	public CAGEclusterToBed(String fnmCageClst, String fnmBedOut) {
		super();
		this.fnmCageClst = fnmCageClst;
		this.fnmBedOut = fnmBedOut;
	}



	public static void main(String[] args) {
		
		CAGEclusterToBed obj = new CAGEclusterToBed(args[0], args[1]);
		obj.doProcessing();
	}
}
