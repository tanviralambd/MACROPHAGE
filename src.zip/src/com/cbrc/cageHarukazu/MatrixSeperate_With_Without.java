package com.cbrc.cageHarukazu;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MatrixSeperate_With_Without {

	
	String fin;
	
	String suffWith;
	String suffWithout;
	
	
		
	void doProcessingMakeSerialReplicate(String fnm , String sufWith, String sufWihtout)
	{
		this.fin = fnm;
		this.suffWith = sufWith;
		this.suffWithout = sufWihtout;				
		
		Vector<String> vectMat = CommonFunction.readlinesOfAfile(this.fin);
		
		
		
		LinkedHashSet<Integer> setWith_columnIdx = new LinkedHashSet<Integer>();
		LinkedHashSet<Integer> setWithOut_columnIdx = new LinkedHashSet<Integer>();
		
		LinkedHashMap<Integer, Integer> lhmWithout_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();
		LinkedHashMap<Integer, Integer> lhmWith_replicaNo_ColumnIdx = new LinkedHashMap<Integer, Integer>();
		
		String curColName="" ,curReplicaName="";
		
		
		/*
		 *  Manage Header/1st Line
		 */
		String firstLine = vectMat.get(0);
		String tmp[];
		tmp = ConstantValue.patWhiteSpace.split(firstLine);
		
		for(int i=0; i<tmp.length;i++)
		{
			curColName = tmp[i];
			
			
			if(tmp[i].startsWith("With_"))
			{
				setWith_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWith_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);
				
			}else if ( tmp[i].startsWith("Without_"))
			{
				setWithOut_columnIdx.add( i ) ;
				curColName = tmp[i];
				curReplicaName = curColName.substring(curColName.lastIndexOf('_')  + 1);
				lhmWithout_replicaNo_ColumnIdx.put(  Integer.parseInt(curReplicaName), i);
				
			}
		}
		
		int totReplica_With     = lhmWith_replicaNo_ColumnIdx.size();
		int totReplica_Without  = lhmWithout_replicaNo_ColumnIdx.size();
		
		
		/*
		 *  Rewrite 1st to Last Line
		 */
		StringBuffer bufWith = new StringBuffer();
		StringBuffer bufWithout = new StringBuffer();
		String trxName;
		int selectedColumn;
		
		for(int i=0; i<vectMat.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectMat.get(i));
			trxName = tmp[0];
			bufWith.append(trxName);
			bufWithout.append(trxName);
			
			for(int k=1; k<= totReplica_With;k++)
			{
				selectedColumn = lhmWith_replicaNo_ColumnIdx.get(k) ; 
				bufWith.append("\t" + tmp[ selectedColumn  ]);
			}
			
			
			for(int k=1; k<= totReplica_Without;k++)
			{
				selectedColumn = lhmWithout_replicaNo_ColumnIdx.get(k) ; 
				bufWithout.append("\t" + tmp[ selectedColumn  ]);
			}
			

			
			bufWith.append("\n");
			bufWithout.append("\n");
			
			
		}
		
		CommonFunction.writeContentToFile(this.fin+ this.suffWith     , bufWith+"");
		CommonFunction.writeContentToFile(this.fin+ this.suffWithout  , bufWithout+"");
		
		
		
		
		
	}
	
	
	public static void main(String[] args) {
		
		MatrixSeperate_With_Without obj = new MatrixSeperate_With_Without();
//		obj.doProcessingMakeSerialReplicate(args[0], args[1] , args[2]);
		
//		obj.doProcessingMakeSerialReplicate("mouse_macrophage_TB_infection_IL13.counts.csv.matrix.6.6" , ".withMtb" , ".withoutMtb") ; //("mouse_macrophage_TB_infection_IFNg.counts.csv.matrix.28.28");
		obj.doProcessingMakeSerialReplicate("mouse_macrophage_TB_infection_non-stimulated.counts1.csv.matrix.24.24" , ".withMtb" , ".withoutMtb") ; 
	}
	
	
	
}
