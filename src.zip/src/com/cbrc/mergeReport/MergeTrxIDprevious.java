package com.cbrc.mergeReport;

import java.lang.invoke.ConstantCallSite;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.sql.CommonDataSource;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MergeTrxIDprevious {

	
	String fnmInput;
	String fnmOut;
	
	
	void doProcessing()
	{
		
		Vector<String> vectInp = CommonFunction.readlinesOfAfile(this.fnmInput);
		
		LinkedHashMap<String, String> lhm_CAGEid_description = new LinkedHashMap<String, String>();
		
		String tmp[] , tmpName[];
		
		String curTrx, curCage;
		String curDesc;
		
		for( int i=0; i<vectInp.size();i++)
		{
			curDesc = vectInp.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curDesc);
			
			curTrx = tmp[0];
			curCage = tmp[1];
			
			if(lhm_CAGEid_description.containsKey(curCage))
			{
				tmpName = ConstantValue.patWhiteSpace.split(lhm_CAGEid_description.get(curCage));
				
				
				lhm_CAGEid_description.put(curCage, tmpName[0]+","+curDesc);
				
				System.out.println("found");
			}else
			{
				lhm_CAGEid_description.put(curCage, curDesc);
			}
			
			
		}
		
		
		StringBuffer bufRes = new StringBuffer();
		Set set = lhm_CAGEid_description.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext())
		{
			Map.Entry me = (Map.Entry) itr.next();
			

			
			bufRes.append(lhm_CAGEid_description.get(me.getKey()) + "\n");
			
		}
		
		CommonFunction.writeContentToFile(this.fnmOut, bufRes+"");
		
		
	}
	
	
	
	
	public static void main(String[] args) {
		
//		MergeTrxID obj = new MergeTrxID("resultIfng.txt", "resultIfng.txt.merged");
//		
		MergeTrxIDprevious obj = new MergeTrxIDprevious("resultIL413.txt", "resultIL413.txt.merged");
		
		obj.doProcessing();
		
	}




	public MergeTrxIDprevious(String fnmInput, String fnmOut) {
		super();
		this.fnmInput = fnmInput;
		this.fnmOut = fnmOut;
	}
	
}
