package com.cbrc.mergeReport;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MergeTrxidForCageID {

	String fnmTrx_Cage;
	String fnmTrx_properties;
	
	String fnmCage_Trx_Properties;
	
	
	LinkedHashMap<String, String> lhm_Trx_Cage = new LinkedHashMap<String, String>();
	
	LinkedHashMap<String, String> lhm_Cage_Trx = new LinkedHashMap<String, String>();
	LinkedHashMap<String, String> lhm_Cage_Properties = new LinkedHashMap<String, String>();
	String headerPropereties ;
	
	void loadTrxCageMapping()
	{
		Vector<String> vectTrxCage = CommonFunction.readlinesOfAfile(this.fnmTrx_Cage);
		
		String tmp[];
		String curTrx,curCAGE;
		for(int i=1; i<vectTrxCage.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectTrxCage.get(i));
			curTrx = tmp[0];
			curCAGE = tmp[1];
			
			if(lhm_Trx_Cage.containsKey(curTrx))
			{
				
			}else
			{
				lhm_Trx_Cage.put(curTrx, curCAGE);
			}
			
			
			if(lhm_Cage_Trx.containsKey(curCAGE))
			{
				String alreadyExistTrx = lhm_Cage_Trx.get(curCAGE);
				lhm_Cage_Trx.put(curCAGE, alreadyExistTrx + "," + curTrx );
				
				
			}else
			{
				lhm_Cage_Trx.put(curCAGE, curTrx);
			}
			
			
		}
		
	}
	
	void load_Trx_CAGE_Properties()
	{
		
		Vector<String> vectTrxProperties = CommonFunction.readlinesOfAfile(this.fnmTrx_properties);
		
		String tmp[];
		String curTrx,curCAGE;
		StringBuffer curProperties;
		
		headerPropereties = vectTrxProperties.get(0);
		int totField;
		for(int i=1; i<vectTrxProperties.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectTrxProperties.get(i));
			totField = tmp.length;
			
			curTrx = removeDoubleQuote(tmp[0]);
			curCAGE = lhm_Trx_Cage.get(curTrx);
			
			
			if(lhm_Cage_Properties.containsKey(curCAGE))
			{
				// already exist , No need to insert same data
			}else
			{
				curProperties= new StringBuffer();
				for(int c=1;c<totField;c++)
				{
					if(c==totField-1)
					{
						curProperties.append(tmp[c] );
					}else
					{
						curProperties.append(tmp[c] + "\t");
					}
				}
				
				lhm_Cage_Properties.put(curCAGE, curProperties+"");
				
			}
	
		}
		
	}
	
	void writeReport()
	{
		
		StringBuffer res = new StringBuffer();
		res.append("\t"+headerPropereties+"\n");
		
		Set set = lhm_Cage_Properties.entrySet();
        System.out.println("Total Unique entry:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            String cageid = (String)me.getKey();
            String properties = (String) me.getValue();
            String trxID = lhm_Cage_Trx.get(cageid);
         
            res.append(cageid + "\t" + trxID + "\t" + properties + "\n");
            
        }
		
		CommonFunction.writeContentToFile(this.fnmCage_Trx_Properties, res+"");
        
	}
	
	String  removeDoubleQuote(String curTrx)
	{
		if(curTrx.charAt(0)=='"')
		{
			curTrx = curTrx.substring(1);
		}
		int len = curTrx.length();
		if(curTrx.charAt(len-1)=='"')
		{
			curTrx = curTrx.substring(0, len-1);
		}
		
		return curTrx;
	}
	
	void doProcessing()
	{
		loadTrxCageMapping();
		load_Trx_CAGE_Properties();
		writeReport();
	}
	
	
	
	
	public MergeTrxidForCageID(String fnmTrx_Cage, String fnmTrx_properties,
			String fnmCage_Trx_Properties) {
		super();
		this.fnmTrx_Cage = fnmTrx_Cage;
		this.fnmTrx_properties = fnmTrx_properties;
		this.fnmCage_Trx_Properties = fnmCage_Trx_Properties;
	}


	public static void main(String[] args) {
		
		String inputFold="";
		String trx_CageMapping="";
		String trx_Properties="";
		String trx_Properties_ReportWihCage="";
		
		int resultType;
		
		int experimentType=4; // 1- IFNG , 2 - IL413  , 3 - NOSTIM , 4 - ReplicateReport , 5- Report for Mix
		
		if(experimentType==1)// IFNG
		{
			inputFold="./ReportChangedPvalue/IFNG/";
			trx_CageMapping = "NFvsIFNG.allTime.deg.withMtb.clusterid";
			
			resultType=4;
			
			switch (resultType) {
			case 1:
				// Replicates	
				trx_Properties="IFNG.table.deg.replicates.TPM";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			case 2:
				// Average of replicates
				trx_Properties="IFNG.table.txt";
				trx_Properties_ReportWihCage=trx_Properties+".report";		
				break;
			case 3:
				// Fold Changes
				trx_Properties="NFvsIFNG.allTime.deg.withMtb.FC";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;
			case 4:
				// P-value
				trx_Properties="NFvsIFNG.allTime.deg.withMtb.pvalue";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			default:
				break;
			}
		}else if(experimentType==2)// IL413
		{
			
			inputFold="./ReportChangedPvalue/IL413/";
			trx_CageMapping = "NFvsIL413.allTime.deg.withMtb.clusterid";
			
			resultType=4;
			
			switch (resultType) {
			case 1:
				// Replicates	
				trx_Properties="IL413.table.deg.replicates.TPM";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			case 2:
				// Average of replicates
				trx_Properties="IL413.table.txt";
				trx_Properties_ReportWihCage=trx_Properties+".report";		
				break;
			case 3:
				// Fold Changes
				trx_Properties="NFvsIL413.allTime.deg.withMtb.FC";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;
			case 4:
				// P-value
				trx_Properties="NFvsIL413.allTime.deg.withMtb.pvalue";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			default:
				break;
			}
			
			
		}else if(experimentType==3)
		{
			inputFold="./ReportChangedPvalue/NOSTIM/";
			trx_CageMapping = "NoStim.allTime.deg.withMtb.clusterid";
			
			resultType=1;
			
			switch (resultType) {
			case 1:
				// Replicates	
				trx_Properties="NONSTIM.table.deg.replicates.TPM";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			case 2:
				// Average of replicates
				trx_Properties="NONSTIM.table.txt";
				trx_Properties_ReportWihCage=trx_Properties+".report";		
				break;
			case 3:
				// Fold Changes
				trx_Properties="NoStim.allTime.deg.withMtb.FC";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;
			case 4:
				// P-value
				trx_Properties="NoStim.allTime.deg.withMtb.pvalue";
				trx_Properties_ReportWihCage=trx_Properties+".report";
				break;

			default:
				break;
			}
			
		}else if(experimentType==4)
		{
			
			
			inputFold="./ReportChangedPvalue/ReplicateReportGeneration/";
			trx_CageMapping = "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.annotation";
			
			trx_Properties="allTrxIFNG.table.txt.tagcount.replicates.TPM.selected";
			trx_Properties_ReportWihCage=trx_Properties+".report";
			
			trx_Properties="allTrxIL413.table.txt.tagcount.replicates.TPM.selected";
			trx_Properties_ReportWihCage=trx_Properties+".report";

			
			trx_Properties="allTrxNONSTIM.table.txt.tagcount.replicates.TPM.selected";
			trx_Properties_ReportWihCage=trx_Properties+".report";
			
			
			
		}
		
		else if(experimentType==5) // Mix
		{
			
			
			inputFold="./Report_Mixed/ReplicateReportGeneration/";
			trx_CageMapping = "mouse_macrophage_TB_infection_non-stimulated.counts1.csv.annotation";
			
			trx_Properties="Merged_Final_Avg_ExpressionAndFold_NotDetails_Mixed.xlsx.txt";
			trx_Properties_ReportWihCage=trx_Properties+".report";
			
			
			
			trx_Properties="Merged_Final_Avg_ExpressionAndFold_NotDetails_Mixed_ModifiedPvalue.xlsx.txt";
			trx_Properties_ReportWihCage=trx_Properties+".report";
			
		}
		
		
		
		MergeTrxidForCageID obj = new MergeTrxidForCageID(
				inputFold+trx_CageMapping,
				inputFold+trx_Properties, 
				inputFold+trx_Properties_ReportWihCage);
		
		
		
		obj.doProcessing();
	}
	
}
