package com.cbrc.masigpro;

import java.util.LinkedHashMap;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class SelectSigGeneName {

	String foutputFromR;
	String fgeneName;
	
	String finalOut;
	
	
	LinkedHashMap<String, String> lhm_Trx_Gene = new LinkedHashMap<String, String>();
	
	void init(String outR, String gencodeGene, String fou)
	{
		this.foutputFromR = outR;
		this.fgeneName = gencodeGene;
		this.finalOut = fou;
		
	}
	
	
	void loadTrx2Gene()
	{
		Vector<String> vect = CommonFunction.readlinesOfAfile(this.fgeneName);
		String tmp[];
		
		for(int i=1; i<vect.size() ;i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vect.get(i));
			lhm_Trx_Gene.put(tmp[0], tmp[1]);
		}
		System.out.println("No of trx:"+ lhm_Trx_Gene.size() );
		
	}
	
	
	void doProcessing()
	{
		loadTrx2Gene();
		
		Vector<String> vectOutR = CommonFunction.readlinesOfAfile(this.foutputFromR);
		String tmp[];
		int totField;
		boolean significant=true;
		
		StringBuffer bufResult = new StringBuffer();
		bufResult.append(vectOutR.get(0)+"\n");
		
		for(int i=1; i<vectOutR.size();i++)
		{
			significant = true;
			tmp = ConstantValue.patWhiteSpace.split(vectOutR.get(i) );
			totField = tmp.length;
			for( int j=0; j<totField ;j++)
			{
				if(tmp[j].endsWith("NA"))
					significant=false;
			}
			if(significant){
				bufResult.append( lhm_Trx_Gene.get(tmp[0]) +"\t" + vectOutR.get(i) +"\n");
			}
			
		}
		
		CommonFunction.writeContentToFile(this.finalOut, bufResult+"");
	}
	
	public static void main(String[] args) {
		SelectSigGeneName obj = new SelectSigGeneName();
//		obj.init("NFvsIFNG.DEG.4.24.DESEQ" , "gencode.v2.long_noncoding_RNAs.gtf.trx2gene", "NFvsIFNG.DEG.4.24.DESEQ.sigGene" );
		obj.init(args[0], args[1], args[2]);
		obj.doProcessing();
		
	}
}
