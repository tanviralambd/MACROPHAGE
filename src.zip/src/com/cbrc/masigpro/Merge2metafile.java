package com.cbrc.masigpro;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

/*
 *  Read the description of Metafile in maSigPro package
 */
public class Merge2metafile {

	String fin1;
	String fin2;
	String fOut;
	
	String suffix_1st;
	String suffix_2nd;
	
	void doProcessing(String f1,String f2, String fO , String pre1, String pre2)
	{
		
		this.fin1 = f1;
		this.fin2 = f2;
		this.fOut = fO;
		this.suffix_1st= pre1;
		this.suffix_2nd= pre2;
		
		Vector<String> vec1 = CommonFunction.readlinesOfAfile(this.fin1);
		Vector<String> vec2 = CommonFunction.readlinesOfAfile(this.fin2);
		
		
		String tmp[];
		int maxID=0, curID=0;
		StringBuffer bufMerged = new StringBuffer();
		
		/*
		 *  Load 1st
		 */
		bufMerged.append(vec1.get(0) + "\t"+suffix_1st + "\t"+ suffix_2nd + "\n");
		for(int i= 1;  i<vec1.size();i++)
		{
//			bufMerged.append(vec1.get(i) + "\t1" + "\t0" + "\n");
			
			tmp = ConstantValue.patTab.split(vec1.get(i));
			curID = Integer.parseInt(tmp[2]);
			bufMerged.append(tmp[0]+"_"+suffix_1st +"\t" +tmp[1]+"\t" + curID + "\t1" + "\t0"  + "\n");
			if(curID > maxID)
			{
				maxID = curID;
			}
		}
		
		
		
		/*
		 *  Load 2nd
		 */
		for(int i= 1;  i<vec2.size();i++)
		{
			tmp = ConstantValue.patTab.split(vec2.get(i));
			curID = Integer.parseInt(tmp[2]) + maxID;
			bufMerged.append(tmp[0]+"_"+suffix_2nd +"\t" +tmp[1]+"\t" + curID + "\t0" + "\t1"  + "\n");
		}
		
		
		
		/*
		 * 
		 */
		
		CommonFunction.writeContentToFile(this.fOut, bufMerged +"");
	}
	
	public static void main(String[] args) {
		
		Merge2metafile obj = new Merge2metafile();
		obj.doProcessing(args[0], args[1], args[2] , args[3], args[4]);
		
//		obj.doProcessing("mouse_macrophage_TB_infection_non-stimulated.counts.csv.meta.0.24", "mouse_macrophage_TB_infection_IL4-IL13.counts.csv.meta.0.24", "combined.meta" , "First","Second");  
		
	}
	
}
