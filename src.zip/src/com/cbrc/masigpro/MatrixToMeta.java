package com.cbrc.masigpro;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MatrixToMeta {

	String fIn;
	String fOut;
	
	
	void doProcessing(String f1, String fo)
	{
		
		this.fIn = f1;
		this.fOut = fo;
		
		String headLine="";
		
		try {
			
			FileInputStream fin = new FileInputStream(this.fIn);
			DataInputStream in = new DataInputStream(fin);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			
			String beforeTrim;

			beforeTrim = br.readLine();
			headLine = beforeTrim.trim();
			
			br.close();
			in.close();
			fin.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		generateMaSigPro_Meta(headLine);
		
	}
	
	
	void generateMaSigPro_Meta(String headLine)
	{
		
		
		StringBuffer bufRes = new StringBuffer();
		String tmp[] = ConstantValue.patTab.split(headLine);
		String tmpLabel[];
		LinkedHashMap<String, Integer> lhm_Mtb_ReplicateID = new LinkedHashMap<String, Integer>();
		int curID=0 , newReplicateID=0;
		
		
		bufRes.append( "Time" + "\t" + "Replicate" + "\n"); // You can't add trxID. As in R, (0,0) with label=TRUE should be empty 
		
		for(int i=1; i<tmp.length ;i++)
		{
			tmpLabel = ConstantValue.patUnderscore.split(tmp[i]);
			
			if( lhm_Mtb_ReplicateID.containsKey(tmp[i].substring(0, tmp[i].lastIndexOf('_') )   )  )
			{
				curID = lhm_Mtb_ReplicateID.get( tmp[i].substring(0, tmp[i].lastIndexOf('_') )  );
			}else
			{
				newReplicateID++;
				lhm_Mtb_ReplicateID.put(tmp[i].substring(0, tmp[i].lastIndexOf('_') ), newReplicateID );
				curID = newReplicateID;
			}
			
			
			bufRes.append(tmp[i] + "\t" + tmpLabel[2] +"\t"+  curID + "\n") ;
		}
		
		
		CommonFunction.writeContentToFile(this.fOut, bufRes+"");
		
	}
	
	public static void main(String[] args) {
		
		MatrixToMeta obj = new MatrixToMeta();
		obj.doProcessing(args[0], args[1]);
		
//		obj.doProcessing("mouse_macrophage_TB_infection_non-stimulated.counts.csv.matrix.24.120", "mouse_macrophage_TB_infection_non-stimulated.counts.csv.meta.24.120");
		
		
	}
}
