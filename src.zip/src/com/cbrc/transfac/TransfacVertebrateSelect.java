package com.cbrc.transfac;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.cbrc.bean.TransfacProfile;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

//import com.cbrc.motifmap.MapMotifOnSequence;

public class TransfacVertebrateSelect {

	String myfold;
	String fnameMatrixTRANSFAC;
	String fnameProfileTRANSFAC;

	String fnameMatrixInsect;
	String fnameACCID;
	String fnameTFdros;
	String fnameTF_ID_Name;
	String fnameTFBS_TFName;
	String fnameTFname_TFBSid;

	String fnameProfileInsect;

	String prefixVertebrate = "V$";

	StringBuffer tfListPrev = new StringBuffer();
	StringBuffer tfList = new StringBuffer();

	LinkedHashMap<String, TransfacProfile> lhashmapProf = new LinkedHashMap<String, TransfacProfile>();

	LinkedHashMap<String, Set<String>> lhmTF_ID_name = new LinkedHashMap<String, Set<String>>();

	LinkedHashMap<String, Set<String>> lhmTFBSid_TFName = new LinkedHashMap<String, Set<String>>();
	LinkedHashMap<String, Set<String>> lhmTFName_TFBSid = new LinkedHashMap<String, Set<String>>();

	void init(String myRoot, String origMatrix, String drosMatrix,
			String TRANSFACprofile, String drosProfile) {
		if (CommonFunction.isWindows()) {
			myfold = ConstantValue.filePrefixWindows;

		} else if (CommonFunction.isUnix()) {
			myfold = ConstantValue.filePrefixLinux;
		}

		myfold = myRoot;

		fnameMatrixTRANSFAC = myfold + origMatrix; // "test.model" ;

		fnameMatrixInsect = myfold + drosMatrix;

		// TFBS
		fnameACCID = myfold + "tfbs_ID_Acc.txt"; //
		fnameTFdros = myfold + "tfbs_Acc_ID.txt"; // drosTF;
		// TF
		fnameTF_ID_Name = myfold + "tf_ID_name.txt";
		// TFBS_TF
		fnameTFBS_TFName = myfold + "TFBSid_TFName.txt";
		// TF_TFBS
		fnameTFname_TFBSid = myfold + "TFName_TFBSid.txt";

		fnameProfileTRANSFAC = myfold + TRANSFACprofile;
		fnameProfileInsect = myfold + drosProfile;
	}

	void doProcessing() {
		findVertebrateTFBS();

		createVertebrateProfile();
	}

	void createVertebrateProfile() {

		try {

			FileInputStream fstream = new FileInputStream(fnameProfileTRANSFAC);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader brProfTRANSFAC = new BufferedReader(
					new InputStreamReader(in));

			FileInputStream fstreamACCid = new FileInputStream(fnameACCID);
			DataInputStream inACCid = new DataInputStream(fstreamACCid);
			BufferedReader brACCid = new BufferedReader(new InputStreamReader(
					inACCid));

			BufferedWriter out = new BufferedWriter(new FileWriter(
					fnameProfileInsect));

			String profileKey;
			lhashmapProf = new LinkedHashMap<String, TransfacProfile>();

			String strLine;
			int lineNo = 0;

			String accNo = null;
			String ID = null;
			Pattern p = Pattern.compile("[ \\t]+");
			String tmp[];

			strLine = brProfTRANSFAC.readLine();
			lineNo++;
			out.write(strLine + "\n");
			strLine = brProfTRANSFAC.readLine();
			lineNo++;
			out.write(strLine + "\n");
			strLine = brProfTRANSFAC.readLine();
			lineNo++;
			out.write(strLine + "\n");
			strLine = brProfTRANSFAC.readLine();
			lineNo++;
			out.write(strLine + "\n");

			while ((strLine = brProfTRANSFAC.readLine()) != null) {
				lineNo++;
				String afterTrim = strLine.trim();

				if (afterTrim.startsWith("//"))
					break;

				tmp = p.split(afterTrim);
				profileKey = tmp[3] + "_" + tmp[4]; // ACCNO_MATIRIXID

				if (lhashmapProf.containsKey(profileKey)) {
				} else {
					lhashmapProf.put(profileKey, new TransfacProfile(tmp[0],
							tmp[1], tmp[2], tmp[3], tmp[4]));
				}
			}

			System.out.println("Total TRANSFAC profile in file:" + lhashmapProf.size());

			int notFoundDrosProfile = 0;
			while ((strLine = brACCid.readLine()) != null) {

				tmp = p.split(strLine);
				profileKey = tmp[1] + "_" + tmp[0];

				if (lhashmapProf.containsKey(profileKey)) {
					TransfacProfile tmpProf = (TransfacProfile) lhashmapProf
							.get(profileKey);
					out.write(tmpProf.getOne() + "\t"
							+ tmpProf.getCoreSimCutoff() + "\t"
							+ tmpProf.getMatSimCutoff() + "\t"
							+ tmpProf.getAccNo() + "\t" + tmpProf.getIdNo()
							+ "\n");

				} else {
					System.out
							.println("In TRANSFAC min_prf  Matrix entry Not found  [ "
									+ (++notFoundDrosProfile)
									+ "] :"
									+ profileKey);
				}
			}

			out.write("//" + "\n");
			out.close();

			brACCid.close();
			inACCid.close();
			fstreamACCid.close();

			brProfTRANSFAC.close();
			in.close();
			fstream.close();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	/*
	 * find matrix, acc & ID , Tf from drosophila
	 */
	void findVertebrateTFBS() {

		try {

			FileInputStream fstream = new FileInputStream(fnameMatrixTRANSFAC);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			BufferedWriter out = new BufferedWriter(new FileWriter(
					fnameMatrixInsect));
			BufferedWriter outACCID = new BufferedWriter(new FileWriter(
					fnameACCID));
			BufferedWriter outTFdros = new BufferedWriter(new FileWriter(
					fnameTFdros));

			String strLine;
			String IDstrLine = null;
			StringBuffer allContent = new StringBuffer();

			int lineNo = 0;

			boolean fromVertebrate = false;
			String accNo = null;
			String ID = null;
			String NA = null; // TF Name
			Pattern p = Pattern.compile("[ \\t]+");
			Pattern patTFPrev = Pattern.compile("[;]+");
			Pattern patTF = Pattern.compile("[$]+");

			String tmp[];

			strLine = br.readLine();
			lineNo++;
			out.write(strLine + "\n");
			strLine = br.readLine();
			lineNo++;
			out.write(strLine + "\n");
			strLine = br.readLine();
			lineNo++;
			out.write(strLine + "\n");

			while ((strLine = br.readLine()) != null) {
				lineNo++;

				if (strLine.equals("//")) { // now write or escape

					if (fromVertebrate) {
						out.write(allContent + "//" + "\n");

						outACCID.write(ID + "\t" + accNo + "\n");
						outTFdros.write(accNo + "\t" + ID + "\n");
						// previous versoin outTFdros.write(accNo + "\t" + ID + "\t" + tfList+ "\n");

						// Previous Version Tanvir:
						// updateTF_TFBS_of_fromID(ID, IDstrLine);
					}

					// initialize value;
					allContent = null;
					allContent = new StringBuffer();
					tfList = null;
					tfList = new StringBuffer();
					fromVertebrate = false;
					continue;
				}

				// ACC
				if (strLine.startsWith("AC")) {
					tmp = p.split(strLine);
					accNo = tmp[1];
				}

				// ID
				if (strLine.startsWith("ID")) {
					tmp = p.split(strLine);
					ID = tmp[1];

					if (ID.startsWith(this.prefixVertebrate))
						fromVertebrate = true;

					IDstrLine = strLine;
					tmp = patTF.split(IDstrLine);
					tfList.append(tmp[1]);

				}

				// NA
				if (strLine.startsWith("NA")) {
					tmp = p.split(strLine);
					NA = tmp[1];
				}

				// BF EACH BF LINE CONTAINS ONE tf
				// FORMAT
				// BF TFaccNo; TFname; Species: name1, name2, ..., namen.

				// BF T00196; Dl; Species: fruit fly, Drosophila melanogaster.
				// BF T08978; Dl-A; Species: fruit fly, Drosophila melanogaster.

				String tfID = null;
				String tfName = null;

				if (strLine.startsWith("BF")
				// ( strLine.indexOf("drosophila") != -1 ||
				// strLine.indexOf("Drosophila") != -1 )

				) {
					// fromInsect = true;

					tmp = patTFPrev.split(strLine);

					tfName = tmp[1];
					tfID = p.split(tmp[0])[1];

					// tfListPrev.append(tfID+ "\t") ;

					if (lhmTF_ID_name.containsKey(tfID)) {
						lhmTF_ID_name.get(tfID).add(tfName);
					} else {
						Set<String> tmpV = new LinkedHashSet<String>();
						tmpV.add(tfName);
						lhmTF_ID_name.put(tfID, tmpV);
					}

					updateTF_TFBS_of_fromID2(ID, tfName);

				}
				allContent.append(strLine + "\n");

			}

			BufferedWriter brTFidName = new BufferedWriter(new FileWriter(
					fnameTF_ID_Name));
			Set set = lhmTF_ID_name.entrySet();
			System.out.println("Total Unique TF id:" + set.size());
			Iterator i = set.iterator();
			while (i.hasNext()) {
				Map.Entry me = (Map.Entry) i.next();
				String id = (String) me.getKey();
				brTFidName.write(id + "\t");

				Set<String> setTFname = (Set<String>) me.getValue();
				Iterator itrTFname = setTFname.iterator();
				while (itrTFname.hasNext()) {
					brTFidName.write((String) itrTFname.next() + ";");
				}

				brTFidName.write("\n");
			}

			brTFidName.close();

			BufferedWriter brTFBS_TFname = new BufferedWriter(new FileWriter(
					fnameTFBS_TFName));
			Set setTFBS = lhmTFBSid_TFName.entrySet();
			System.out.println("Total Unique TFBS found :" + setTFBS.size());
			Iterator itrTFBS = setTFBS.iterator();
			while (itrTFBS.hasNext()) {
				Map.Entry me = (Map.Entry) itrTFBS.next();
				String id = (String) me.getKey();
				brTFBS_TFname.write(id + "\t");

				Set<String> setTFname = (Set<String>) me.getValue();
				Iterator itrTFname = setTFname.iterator();
				while (itrTFname.hasNext()) {
					brTFBS_TFname.write((String) itrTFname.next() + ";");
				}

				brTFBS_TFname.write("\n");
			}
			brTFBS_TFname.close();

			BufferedWriter brTFname_TFBSid = new BufferedWriter(new FileWriter(
					fnameTFname_TFBSid));
			Set setTFname = lhmTFName_TFBSid.entrySet();
			System.out
					.println("Total Unique TFname found :" + setTFname.size());
			Iterator itrTFname = setTFname.iterator();
			while (itrTFname.hasNext()) {
				Map.Entry me = (Map.Entry) itrTFname.next();
				String id = (String) me.getKey();
				brTFname_TFBSid.write(id + "\t");

				Set<String> setTFBSid = (Set<String>) me.getValue();
				Iterator itrTFBSid = setTFBSid.iterator();
				while (itrTFBSid.hasNext()) {
					brTFname_TFBSid.write((String) itrTFBSid.next() + ";");
				}

				brTFname_TFBSid.write("\n");
			}

			brTFname_TFBSid.close();

			out.close();
			outTFdros.close();
			outACCID.close();

			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	boolean updateTF_TFBS_of_fromIDWrong(String TFBSID, String sourSpeciesLine) {
		boolean decision = false;

		Pattern patTF = Pattern.compile("[$]+");
		String tmp[] = patTF.split(sourSpeciesLine);

		String tfTransfacName = tmp[1].trim();

		// for( int i=0 ; i<cisMetaTFnames.size() ; i++)
		// {
		// if( tfTransfacName.startsWith(cisMetaTFnames.get(i).toUpperCase() ) )
		// // It creates >1 TFBS per TF

		// if( tfTransfacName.equals( cisMetaTFnames.get(i).toUpperCase() ) )
		// {

		decision = true;
		// tfList.append(tfTransfacName.toUpperCase()+ "\t") ;

		if (lhmTFBSid_TFName.containsKey(TFBSID)) {
			lhmTFBSid_TFName.get(TFBSID).add(tfTransfacName.toUpperCase());
		} else {
			Set<String> tmpV = new LinkedHashSet<String>();
			tmpV.add(tfTransfacName.toUpperCase());

			lhmTFBSid_TFName.put(TFBSID, tmpV);
		}

		if (lhmTFName_TFBSid.containsKey(tfTransfacName.toUpperCase())) {
			lhmTFName_TFBSid.get(tfTransfacName.toUpperCase()).add(TFBSID);
		} else {
			Set<String> tmpV = new LinkedHashSet<String>();
			tmpV.add(TFBSID);

			lhmTFName_TFBSid.put(tfTransfacName.toUpperCase(), tmpV);
		}

		// }
		// }

		return decision;
	}

	boolean updateTF_TFBS_of_fromID2(String TFBSID, String tfTransfacName) {

		boolean decision = true;

		decision = true;
		// tfList.append(tfTransfacName.toUpperCase()+ "\t") ;

		if (lhmTFBSid_TFName.containsKey(TFBSID)) {
			lhmTFBSid_TFName.get(TFBSID).add(tfTransfacName.toUpperCase());
		} else {
			Set<String> tmpV = new LinkedHashSet<String>();
			tmpV.add(tfTransfacName.toUpperCase());

			lhmTFBSid_TFName.put(TFBSID, tmpV);
		}

		if (lhmTFName_TFBSid.containsKey(tfTransfacName.toUpperCase())) {
			lhmTFName_TFBSid.get(tfTransfacName.toUpperCase()).add(TFBSID);
		} else {
			Set<String> tmpV = new LinkedHashSet<String>();
			tmpV.add(TFBSID);

			lhmTFName_TFBSid.put(tfTransfacName.toUpperCase(), tmpV);
		}

		return decision;
	}

	public static void main(String[] args) {
		TransfacVertebrateSelect obj = new TransfacVertebrateSelect();

		 obj.init(args[0], args[1] , args[2] , args[3], args[4]) ;
//		obj.init("./", "matrix2012.dat", "matrix2012Verteb.dat", "minFP2012.prf", "minFP2012verteb.prf");

		obj.doProcessing();

	}

}
