package com.cbrc.transfac;


import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class ParseMatch_ThrBased {

	String fnmMatchOutput;
	Double thrCore;
	Double thrMatrix;
	String finalOut;
	
	
	void init(String matchOut, String thrCor, String thrWhole, String fnmOut)
	{
		this.fnmMatchOutput = matchOut;
		this.thrCore        = Double.parseDouble(thrCor);
		this.thrMatrix      = Double.parseDouble(thrWhole);
		this.finalOut       = fnmOut;
	}
	
	void doProcessing()
	{
		Vector<String> vectAllMap = CommonFunction.readlinesOfAfile(this.fnmMatchOutput);
		StringBuffer bufResult = new StringBuffer();
		int  i;
		
		String afterTrim="";
		String tmp[];
		double coreTh, matTh;
		
		String inspect="Inspecting sequence ID";
		int inspectLen= inspect.length();
		
		try {
			
			for(i=3; i<vectAllMap.size()-3 ;i++)
			{
				afterTrim = vectAllMap.get(i);
				
				if(afterTrim.startsWith("Inspecting sequence ID") )
				{
					bufResult.append(">"+afterTrim.substring(inspectLen).trim()+"\n");
				}else
				{
					tmp = ConstantValue.patTransfacMatch.split(vectAllMap.get(i));
					
					coreTh = Double.parseDouble(tmp[2].trim());
					matTh = Double.parseDouble(tmp[3].trim());
					if( coreTh>= this.thrCore && matTh>= this.thrMatrix ){
					
						bufResult.append(tmp[0].trim()+"\t" + tmp[1].trim() + "\t" + coreTh +"\t" + matTh+  "\n");
					}
				}
			}
			
			CommonFunction.writeContentToFile(this.finalOut, bufResult+"");
			
			
		} catch (Exception e) {
			System.out.println("ERR for LINE:"+ afterTrim);
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		ParseMatch_ThrBased obj = new ParseMatch_ThrBased();
		
//		obj.init("tmp.map"	, "0.95", "0.95", "matchSelected.out");
		obj.init(args[0], args[1], args[2], args[3]);
		
		obj.doProcessing();
		
	}
}
