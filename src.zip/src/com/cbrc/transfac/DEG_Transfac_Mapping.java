package com.cbrc.transfac;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Vector;

import com.cbrc.bean.FastaMult;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class DEG_Transfac_Mapping {

	
	
	String finTransfacOutput;
	String finDEG;
	String fin_lncRNA_FastaHeader;
	
	String extOut;
	
	
	
	
	LinkedHashMap<String, String>  lhm_GeneID_FastaHeader = new LinkedHashMap<String, String>();	
	
	LinkedHashMap<String, String>  lhm_FastaHeader_Transfac = new LinkedHashMap<String, String>();
	
	Vector<String> vect_DEG = new Vector<String>();

	
	public DEG_Transfac_Mapping(String outputTransfac, String finDEG,
			String lncRNA_FastaHeader, String extOut) {
		super();
		this.finTransfacOutput = outputTransfac;
		this.finDEG = finDEG;
		this.fin_lncRNA_FastaHeader = lncRNA_FastaHeader;
		this.extOut = extOut;

		
	}

	void loadTransfacMap()
	{
		
		FastaMult multFast =CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(this.finTransfacOutput);
		String tmp[];
		String header, body;
		StringBuffer bufResult = new StringBuffer();
		
		System.out.println("Tot entry: "+ multFast.getHeader().size());
		
		for(int i=0; i<multFast.getHeader().size();i++)
		{
			header = multFast.getHeader().get(i);
			body = multFast.getSeq().get(i);
			lhm_FastaHeader_Transfac.put(header, body);
			
		}
		
		
//		tmp = ConstantValue.patAngle.split(allLines);
//		
//		String header, body;
//		outputTransfac
//		for(int i=0; i<tmp.length;i++)
//		{
//			header = tmp[0];
//			CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(fnmFasta)
//		}
		
	}
	
	void load_AllGene_Fastaheader_Map()
	{
		Vector<String> vect_Gencode_FastaHeader = CommonFunction.readlinesOfAfile(this.fin_lncRNA_FastaHeader);
		String curline;
		String tmp[];
		for(int i=0; i<vect_Gencode_FastaHeader.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vect_Gencode_FastaHeader.get(i));
			
			lhm_GeneID_FastaHeader.put(tmp[0], tmp[1]);
			
		}
		System.out.println("Tot Gene entry: "+  lhm_GeneID_FastaHeader.size());
	}
	
	
	void load_DEG()
	{
		Vector<String> vectTmp = CommonFunction.readlinesOfAfile(this.finDEG);
		String tmp[];
		
		for(int i=1; i<vectTmp.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectTmp.get(i));
			vect_DEG.add(tmp[1]);
		}
		System.out.println("Tot DEG entry: "+  vect_DEG.size() );
		
	}
	
	void selectTransfactResult_for_DEG()
	{
		StringBuffer bufResTFBS = new StringBuffer();
		StringBuffer bufResTransfac = new StringBuffer();
		String head,body;
		
		String tmpLines[] , tmp[];
		
		for(int i=0; i<vect_DEG.size();i++)
		{
			head = lhm_GeneID_FastaHeader.get(vect_DEG.get(i));
			body = lhm_FastaHeader_Transfac.get(head);
			bufResTransfac.append(head+"\n" + body+ "\n");
			
			// Writing Unique TFBS
			LinkedHashSet<String> set = new LinkedHashSet<String>();
			bufResTFBS.append(head+"\n");
			tmpLines = ConstantValue.patNewline.split(body);
			for(int k=0; k<tmpLines.length;k++)
			{
				tmp = ConstantValue.patWhiteSpace.split(tmpLines[k]);
				set.add(tmp[0]); // add the TFBS name
				
			}
			Iterator itr = set.iterator();
			while( itr.hasNext())
			{
				bufResTFBS.append(  itr.next() +"\n");
			}
			
			
		}
		
		CommonFunction.writeContentToFile(this.finDEG+ extOut            , bufResTransfac+"");
		CommonFunction.writeContentToFile(this.finDEG+ extOut + ".tfbs"  , bufResTFBS+"");
		
		
	}
	
	void doProcessing()
	{
		loadTransfacMap();
		load_AllGene_Fastaheader_Map();
		load_DEG();
		selectTransfactResult_for_DEG();
	}
	
	public static void main(String[] args) {
		
		DEG_Transfac_Mapping obj = new DEG_Transfac_Mapping(args[0],args[1],args[2],args[3]);
		
//		DEG_Transfac_Mapping obj = new DEG_Transfac_Mapping("Alltfbs_lncRNA.thr.map","NFvsIFNG.DEG.4.24.DESEQ.sigGene", 
//				"finalLncRNA.prom.bed.fastaheader" ,".transfac");
		
		
		obj.doProcessing();
		
	}
}
