package com.cbrc.common;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Iterator;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import com.cbrc.bean.MotifDMF;
import com.cbrc.bean.MotifHOCOMOCO;
import com.cbrc.constant.ConstantValue;



public class LoadModelDMF {

	String myfold;

	String fnameSeqPromoter ;
	String allStat  ;
	String allDistFromC ;
	String allDistFromNC  ;

//	static NumberFormat myFormat = new DecimalFormat("#0.000000");

	static Vector<MotifDMF> vecDMFmotif =  new Vector<MotifDMF>();  

	
	
	public static Vector<MotifDMF> loadModels( String fname )
	{
		vecDMFmotif =  null;
		vecDMFmotif =  new Vector<MotifDMF>();
		doParsing( fname );

		return vecDMFmotif;
	}

	public static Vector<MotifDMF> loadModels_WithDistance( String fname, double X, double Y )
	{
		vecDMFmotif =  null;
		vecDMFmotif =  new Vector<MotifDMF>();
		doParsing( fname );
		calcDistance(X, Y);
		return vecDMFmotif;
	}

	
	public static Vector<MotifDMF> loadModelsSelected( String fnmID , String fnameAllMotif)
	{
		vecDMFmotif =  null;
		vecDMFmotif =  new Vector<MotifDMF>();
		doParsingSelected( fnmID ,  fnameAllMotif );
		return vecDMFmotif ;
	}
	
	static void doParsing( String fname )
	{
		vecDMFmotif = null; 
		vecDMFmotif = new Vector<MotifDMF>();

		String filename =  fname;
		MotifDMF curMotif;
		int count=0;
		String id;
		StringTokenizer st;
		String consensus, TGcoverage, BGcoverage, source ,score;
		String tmp[];
		String strLine;
		try {

			FileInputStream fstream = new FileInputStream(filename);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			while ((strLine = br.readLine()) != null) {

				if(strLine.startsWith("*")) // new motif
				{
					count++;
					strLine = br.readLine(); // ID
					tmp = ConstantValue.patWhiteSpace.split(strLine);
//					st = new StringTokenizer(strLine);
//					st.nextToken(); 
					id = tmp[1]; 
					


					strLine = br.readLine(); // Cons
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					consensus = tmp[1]; 


					strLine = br.readLine(); // len
					strLine = br.readLine(); // Thr


					strLine = br.readLine(); // Cov
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					TGcoverage = tmp[1];  
					TGcoverage =    CommonFunction.formatterScientific.format(Double.parseDouble(TGcoverage) )   ;

					strLine = br.readLine(); // BGCov
					tmp = ConstantValue.patWhiteSpace.split(strLine);
					BGcoverage = tmp[1];  
					BGcoverage =  CommonFunction.formatterScientific.format(Double.parseDouble(BGcoverage))   ;

					strLine = br.readLine(); // source
					tmp = ConstantValue.patWhiteSpace.split(strLine);		
					source = tmp[1]; 	


					strLine = br.readLine(); // Score: p-Value for overrepresentation
					tmp = ConstantValue.patWhiteSpace.split(strLine); 		
					score = tmp[1];  	
					score = CommonFunction.formatterScientific.format(Double.parseDouble(score))   ;


					if ( source.startsWith("C"))
					{
						curMotif = new MotifDMF(  id, Double.parseDouble(TGcoverage), Double.parseDouble(BGcoverage),  Double.parseDouble(score)  , source, consensus) ;

					}

					else
					{
						curMotif = new MotifDMF( id , Double.parseDouble(BGcoverage), Double.parseDouble(TGcoverage),  Double.parseDouble(score)  , source, consensus) ;

					}

					strLine = br.readLine(); // A
					curMotif.setA(strLine);
					strLine = br.readLine(); // C
					curMotif.setC(strLine);
					strLine = br.readLine(); // G
					curMotif.setG(strLine);
					strLine = br.readLine(); // T
					curMotif.setT(strLine);

					//					double dist =   Math.sqrt(  Math.pow( ( curMotif.getcCov() - X )  , 2 ) +  Math.pow( (  curMotif.getNcCov() - Y ) , 2)    );


					vecDMFmotif.add(curMotif);
				}

			}

			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println(" Tot motif read:" + count);

	}
	
	
	
	/*
	 *  ONLY FOR TRACK
	 */
	static void doParsingSelected( String fnameID , String  fnameAllMotif )
	{
		vecDMFmotif = null; 
		vecDMFmotif = new Vector<MotifDMF>();
		String tmp[];

		LinkedHashMap<String, Set<String>> lhmMotifID = new LinkedHashMap<String, Set<String>>();
		int indexUnderscore=0;
		try {
			FileInputStream fstream = new FileInputStream(fnameID);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			String strLine;
			while ((strLine = br.readLine()) != null) {
				
				if( strLine.length() < 3)
				{
					continue;
				}
				tmp = ConstantValue.patTab.split(strLine);
				
//				indexUnderscore = strLine.indexOf('_');
//				lhmMotifID.put(strLine.substring(0, indexUnderscore) ,  strLine);
				
				
				if(lhmMotifID.containsKey(tmp[1])  )
				{
					lhmMotifID.get(tmp[1]).add(tmp[0]);
				}else
				{
					Set st = new LinkedHashSet<String>();
					st.add(tmp[0]);
					lhmMotifID.put(tmp[1], st);
				}
				
				
			}
			
			
			System.out.println("Selected matrix size:" + lhmMotifID.size());
			
			br.close();
			in.close();
			fstream.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		MotifDMF curMotif;
		int count=0;
		StringTokenizer st;
		String id , consensus, len, thr, TGcoverage, BGcoverage, source ,score;
		
		String strLine;
		try {

			FileInputStream fstream = new FileInputStream(fnameAllMotif);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			while ((strLine = br.readLine()) != null) {

				if(strLine.startsWith("*")) // new motif
				{
					count++;
					strLine = br.readLine(); // ID
					id = ConstantValue.patWhiteSpace.split(strLine)[1];

					consensus = ConstantValue.patWhiteSpace.split(br.readLine()) [1];
					len = ConstantValue.patWhiteSpace.split(br.readLine()) [1];
					thr = ConstantValue.patWhiteSpace.split(br.readLine()) [1];

					 // Cov
					TGcoverage = ConstantValue.patWhiteSpace.split(br.readLine())[1];
					TGcoverage =    CommonFunction.formatterScientific.format(Double.parseDouble(TGcoverage) )   ;

					// BGCov
					BGcoverage = ConstantValue.patWhiteSpace.split(br.readLine() )[1];
					BGcoverage =  CommonFunction.formatterScientific.format(Double.parseDouble(BGcoverage))   ;

					// source
					source = ConstantValue.patWhiteSpace.split(br.readLine()  )[1];		
	
					// Score: p-Value for over-representation
					score = ConstantValue.patWhiteSpace.split(br.readLine() )[1]; 
					score = CommonFunction.formatterScientific.format(Double.parseDouble(score))   ;

					curMotif = new MotifDMF(  id, consensus, Integer.parseInt(len) ,  Double.parseDouble(thr) ,Double.parseDouble(TGcoverage), Double.parseDouble(BGcoverage),  source, Double.parseDouble(score)  ) ;

	

					strLine = br.readLine(); // A
					curMotif.setA(strLine);
					strLine = br.readLine(); // C
					curMotif.setC(strLine);
					strLine = br.readLine(); // G
					curMotif.setG(strLine);
					strLine = br.readLine(); // T
					curMotif.setT(strLine);

					//					double dist =   Math.sqrt(  Math.pow( ( curMotif.getcCov() - X )  , 2 ) +  Math.pow( (  curMotif.getNcCov() - Y ) , 2)    );

					if(lhmMotifID.containsKey(id))
					{
						// if you want to change id
						Set s = lhmMotifID.get(id);
						StringBuffer buf = new StringBuffer();
						buf.append(id);
						Iterator itr = s.iterator();
						while( itr.hasNext())
						{
							buf.append("#"+itr.next() );
						}
						curMotif.setMotifid(buf+"");
						
						
						// just keep existing one
						vecDMFmotif.add(curMotif);
					}
						
				}

			}

			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println(" Tot motif read:" + count);


	}
	

	static void calcDistance (double X, double Y)
	{

		for(int i=0 ; i<vecDMFmotif.size() ; i++)
		{

			double dist =   Math.sqrt(  Math.pow( ( vecDMFmotif.get(i).getcCov() - X )  , 2 ) +  Math.pow( (  vecDMFmotif.get(i).getNcCov() - Y ) , 2)    );
			vecDMFmotif.get(i).setDistanceValue(dist);
		}

	}


}

