package com.cbrc.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Random;
import java.util.Vector;
import java.util.regex.Pattern;

import org.apache.commons.math.special.Gamma;

import com.cbrc.bean.BedFormat;
import com.cbrc.bean.FastaMult;
import com.cbrc.bean.TrxExonInfo;
import com.cbrc.constant.ConstantValue;



public class CommonFunction {

	public static Random myrand = new Random();
	
	public static NumberFormat formatterScientific = new DecimalFormat("0.#####E0");
	static Random generator = new Random( 19580427 );
	
	public static   boolean isWindows() {

		String os = System.getProperty("os.name").toLowerCase();
		// windows
		return (os.indexOf("win") >= 0);

	}

	public  static boolean isUnix() {

		String os = System.getProperty("os.name").toLowerCase();
		// linux or unix
		return (os.indexOf("nix") >= 0 || os.indexOf("nux") >= 0);

	}
	
	
	public static void findDuplicateTerms(String fName, String fnmOutDup, String fnmUniq)
	{
		Vector<String> allWords = CommonFunction.readlinesOfAfile(fName);
		LinkedHashMap<String, String> lhmUniq = new LinkedHashMap<String, String>();
		
		StringBuffer bufDup = new StringBuffer();
		StringBuffer bufUniq = new StringBuffer();
		String key;
		for(int i=0; i<allWords.size() ;i++)
		{
			key = allWords.get(i) ;
			if(lhmUniq.containsKey( key) ) {
				
				bufDup.append(key +"\n") ;
			}else
			{
				lhmUniq.put(key, key);
				bufUniq.append( key +"\n") ;
			}
		}
		
		CommonFunction.writeContentToFile(fnmOutDup, bufDup+"");
		CommonFunction.writeContentToFile(fnmUniq, bufUniq+"");
	}
	
	
	public static void readLastColumn(String fnmBedWith1column)
	{
		Vector<String > vectLines = CommonFunction.readlinesOfAfile(fnmBedWith1column);
		String curLine;
		String tmp[];
		int sum=0 , totNozZero=0,n;
		int totField;
		int i=0;
		for( i=0; i<vectLines.size();i++)
		{
			curLine = vectLines.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			totField = tmp.length;
			n = Integer.parseInt(tmp[totField - 1]);
			
			sum += n;
			if(n>0)
				totNozZero+=1;
		}
		
//		System.out.println("Tot non-zero entry: "+totNozZero + "\t sum:" + sum +  "\t avg:" + sum/i );
		System.out.println(totNozZero  );
		
	}
	
	/*
	 *  return chr_TSS_strand
	 */
	public static String getUniqueNameFromBed_0based(String chrm, String start, String end, String strand)
	{
		String uniqueID="";
		String tss;

		if(strand.charAt(0)=='+')
		{
			tss = start;

		}else
		{
			tss = ( Integer.parseInt(end) -1) + "";

		}

		uniqueID = chrm+"_"+tss+"_"+ strand;



		return uniqueID;
	}
	
//	HG19_CHR20_43849009_43851009_+
	public static String fasta_HeaderWithoutAngle(String chrm, String start, String end, String strand)
	{
		String  s = null;
		s = "HG19"+"_" + chrm.toUpperCase() + "_"  + start  + "_"  + end + "_" + strand  ;
		return  s;
	}

	/*
	 *  Returens the header of fasta file
	 */
	public static Vector<String>  fasta_readFastaHeader(String fnmFasta)
	{
		Vector<String> header = null; 
		try {

			header = new Vector<String>();
			FileInputStream fstream = new FileInputStream(fnmFasta);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			while ((strLine = br.readLine()) != null) {
				if(strLine.length()<3)
					continue;
				if(strLine.startsWith(">"))
					header.add(strLine);
			}

			br.close();
			in.close();
			fstream.close();


		} catch (Exception e) {

			e.printStackTrace();
		}
		return header;
	}

	
	public static void fasta_doAllSetOperation_SequenceBased_MultiLines (String fnameA, String fnameB)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getSeq().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getSeq().size();i++)
			{
				setSecond.add(fast2.getSeq().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			


			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationFasta.out"));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void fasta_doAllSetOperation_headerBased_MultiLines (String fnameA, String fnameB)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getHeader().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getHeader().size();i++)
			{
				setSecond.add(fast2.getHeader().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				header = (String)itrCom.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				header = (String)itr.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				header = (String)itr2.next();
				buf.append(  header +"\n");
				index = fast2.getLhmHeader_VectIndex().get(header);
				buf.append(  fast2.getSeq().get(index) +"\n");
			}




			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationFasta.out"));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void fasta_doAllSetOperation_headerBased_MultiLines_DifferentMeaning	(String fnameA, String fnameB , String fnmOut)
	{

		FastaMult fast1 = CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(fnameA);
		FastaMult fast2 = CommonFunction.fasta_readFasta_Multiplelines_DifferentMeaning(fnameB);


		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();



		Set setFirst = new LinkedHashSet();
		Set setSecond = new LinkedHashSet();

		int index;
		String header;

		try {



			for(int i=0; i<fast1.getHeader().size() ; i++)
			{
				setFirst.add(fast1.getHeader().get(i) );
			}
			buf.append( "A size:"+ setFirst.size() +"\n");



			for(int i=0;i<fast2.getHeader().size();i++)
			{
				setSecond.add(fast2.getHeader().get(i));
			}
			buf.append("B size:"+ setSecond.size() + "\n");




			Set intersection = new LinkedHashSet<String>(setSecond);
			intersection.retainAll(setFirst);


			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				header = (String)itrCom.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}

			Set differenceNF = new LinkedHashSet(setFirst);
			differenceNF.removeAll(setSecond);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				header = (String)itr.next();
				buf.append(  header +"\n");
				index = fast1.getLhmHeader_VectIndex().get(header);
				buf.append(  fast1.getSeq().get(index) +"\n");
			}



			Set differenceFN = new LinkedHashSet(setSecond);
			differenceFN.removeAll(setFirst);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				header = (String)itr2.next();
				buf.append(  header +"\n");
				index = fast2.getLhmHeader_VectIndex().get(header);
				buf.append(  fast2.getSeq().get(index) +"\n");
			}




			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnmOut));

			bwr.write(buf+"");
			bwr.close();


		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 *   -------- Select a subset of fasta,  if Header matches ---------
	 *   
	 *  fnmFasta4Header -- list of header
	 *  fnmFasta - all fasta
	 *  fnmSelected - output of selected fasta subset
	 */
	public static void fasta_subsetSelect_ByMatchingHeader_MultiLines(String fnmFasta4Header, String fnmFasta, String fnmSelected)
	{
		Vector<String> vectHeader = fasta_readFastaHeader(fnmFasta4Header); 
		FastaMult multFastaMult = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();
		int index; 

		for(int i=0;i<vectHeader.size();i++)
		{
			if(multFastaMult.getLhmHeader_VectIndex().containsKey(vectHeader.get(i)))
			{
				index = multFastaMult.getLhmHeader_VectIndex().get(vectHeader.get(i));
				buf.append(multFastaMult.getHeader().get(index) + "\n" );
				buf.append(multFastaMult.getSeq().get(index) + "\n");
			}

		}

		try {
			BufferedWriter bwr = new BufferedWriter( new FileWriter(fnmSelected));
			bwr.write(buf+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *   -------- Select a subset of fasta,  if Header matches ---------
	 *  
	 *  fnmFasta4Header -- list of header
	 *  fnmFasta - all fasta
	 *  fnmSelected - output of selected fasta subset
	 */
	public static void fasta_subsetSelect_ByMatchingHeader_MultiLines_DifferentMeaning (String fnmFasta4Header, String fnmFasta, String fnmSelected)
	{
		Vector<String> vectHeader = fasta_readFastaHeader(fnmFasta4Header); 
		FastaMult multFastaMult = fasta_readFasta_Multiplelines_DifferentMeaning(fnmFasta);

		StringBuffer buf = new StringBuffer();
		int index; 

		for(int i=0;i<vectHeader.size();i++)
		{
			if(multFastaMult.getLhmHeader_VectIndex().containsKey(vectHeader.get(i)))
			{
				index = multFastaMult.getLhmHeader_VectIndex().get(vectHeader.get(i));
				buf.append(multFastaMult.getHeader().get(index) + "\n" );
				buf.append(multFastaMult.getSeq().get(index) + "\n");
			}

		}

		try {
			BufferedWriter bwr = new BufferedWriter( new FileWriter(fnmSelected));
			bwr.write(buf+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	public  static FastaMult fasta_readFasta_Multiplelines (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(strLine);

						if( !lhmHead_Ind.containsKey(strLine))
						{
							lhmHead_Ind.put(strLine, index);
						}



						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				seq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}




			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}

	/*
	 *  Read a file like multiple fasta , but different lines means different meaning
	 */
	public  static FastaMult fasta_readFasta_Multiplelines_DifferentMeaning (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmpBuf= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(strLine);

						if( !lhmHead_Ind.containsKey(strLine))
						{
							lhmHead_Ind.put(strLine, index);
						}

						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmpBuf.toString().trim()+"");
							tmpBuf = new StringBuffer();

						}

					}else
					{
						tmpBuf.append(strLine+"\n");
					}

				}
				seq.add(tmpBuf.toString().trim()+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}

			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}


	

	/*
	 *  Returns unique HEADER entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Header_FastaMultiplelines (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> vectHeader = null; 
			Vector<String> vectSeq = null; 

			Vector<String> vectHeaderUniq = new Vector<String>(); 
			Vector<String> vectSeqUniq = new Vector<String>(); 


			/*
			 *  Key - Fasta Header
			 *  Value - 0-based index in vector
			 */
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();

			String header;

			try {

				vectHeader = new Vector<String>();
				vectSeq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){

						header = strLine;

						//						if(lhmHead_Ind.containsKey(header))
						//							System.out.println("EXIST:" + header);
						if( ! lhmHead_Ind.containsKey(header))
						{
							lhmHead_Ind.put(header, index);
						}

						vectHeader.add(header);
						index++;
						if( vectHeader.size() !=1) // for first case, do not append sequence
						{
							vectSeq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				vectSeq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}

			/*
			 *  	NOW CHECK THE UNIQUENESS
			 */

			int index ;
			Set set = lhmHead_Ind.entrySet();
			System.out.println("Total Unique header in fasta line:" + set.size() ) ;
			Iterator itr = set.iterator();
			while(itr.hasNext()){


				Map.Entry me = (Map.Entry) itr.next();
				String myHead = (String)me.getKey();
				index = (Integer) me.getValue();

				vectHeaderUniq.add(vectHeader.get(index));
				vectSeqUniq.add(vectSeq.get(index));

			}


			obj.header = vectHeaderUniq;
			obj.seq = vectSeqUniq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;


		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}


	/*
	 *  Returns unique SEQ entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Sequence_FastaMultiplelines (String fnmFasta)
	{

		FastaMult result=null;

		FastaMult multUniqHeader = fasta_read_Unique_Header_FastaMultiplelines(fnmFasta);

		LinkedHashMap<String, Integer> lhm_Seq_index = new LinkedHashMap<String, Integer>();

		Vector<String> head = new Vector<String>();
		Vector<String> seqUniq = new Vector<String>();
		LinkedHashMap<String, Integer> lhm_Header_index = new LinkedHashMap<String, Integer>();

		String stringOfInterest=null;
		int totUniqSeq=0;

		for(int i=0; i<  multUniqHeader.getSeq().size() ;i++)
		{
			stringOfInterest = multUniqHeader.getSeq().get(i);
			
			if(  ! lhm_Seq_index.containsKey(stringOfInterest  ) )
			{
				lhm_Seq_index.put(multUniqHeader.getSeq().get(i), i) ;
				seqUniq.add(stringOfInterest);
				head.add(multUniqHeader.getHeader().get(i));
				lhm_Header_index.put(multUniqHeader.getHeader().get(i), i);

				totUniqSeq++;
			}
		}

		System.out.println("Total Uniq whole Seq : " + totUniqSeq);
		
		FastaMult uniqSeqFastaMult=  new FastaMult();
		uniqSeqFastaMult.header = head;
		uniqSeqFastaMult.seq = seqUniq;
		uniqSeqFastaMult.lhmHeader_VectIndex = lhm_Header_index;

		return uniqSeqFastaMult;

	}

	/*
	 *  Returns unique SEQ entry of a fasta file
	 */
	public  static FastaMult fasta_read_Unique_Subregion_Sequence_FastaMultiplelines (String fnmFasta, int start_0based, int end_0based)
	{

		FastaMult result=null;

		FastaMult multUniqHeader = fasta_read_Unique_Header_FastaMultiplelines(fnmFasta);

		LinkedHashMap<String, Integer> lhm_Seq_index = new LinkedHashMap<String, Integer>();

		Vector<String> head = new Vector<String>();
		Vector<String> seqUniq = new Vector<String>();
		LinkedHashMap<String, Integer> lhm_Header_index = new LinkedHashMap<String, Integer>();

		String stringOfInterest=null;
		int totUniqSeq=0;

		for(int i=0; i<  multUniqHeader.getSeq().size() ;i++)
		{
			stringOfInterest = multUniqHeader.getSeq().get(i).substring(start_0based, end_0based+1);
			
			if(  ! lhm_Seq_index.containsKey( stringOfInterest  ) )
			{
				lhm_Seq_index.put( stringOfInterest, i) ;
				seqUniq.add( stringOfInterest  ); 
				head.add(multUniqHeader.getHeader().get(i));
				lhm_Header_index.put(multUniqHeader.getHeader().get(i), i);
				
				totUniqSeq++;

			}
		}

		System.out.println("Total Uniq sub-region of Seq : " + totUniqSeq);
		
		FastaMult uniqSeqFastaMult=  new FastaMult();
		uniqSeqFastaMult.header = head;
		uniqSeqFastaMult.seq = seqUniq;
		uniqSeqFastaMult.lhmHeader_VectIndex = lhm_Header_index;

		return uniqSeqFastaMult;

	}
	

	/*
	 *  Conver fasta header from Text to SequenceNumber
	 */
	public  static FastaMult fasta_Header_To_Numerical (String fnmFasta)
	{

		FastaMult obj = new FastaMult();
		try {

			Vector<String> header = null; 
			Vector<String> seq = null; 
			LinkedHashMap<String, Integer> lhmHead_Ind = null;

			StringBuffer tmp= new StringBuffer();;

			try {

				header = new Vector<String>();
				seq = new Vector<String>();
				lhmHead_Ind = new LinkedHashMap<String, Integer>();

				FileInputStream fstream = new FileInputStream(fnmFasta);
				DataInputStream in = new DataInputStream(fstream);
				BufferedReader br = new BufferedReader(new InputStreamReader(in));

				String strLine;
				String beforeTrim;

				int index=0;

				while ((beforeTrim = br.readLine()) != null) {
					strLine = beforeTrim.trim();
					if(strLine.length() <=0)
						continue;

					if(strLine.startsWith(">")){
						header.add(">"+index+"");

						if( !lhmHead_Ind.containsKey(">"+index+""))
						{
							lhmHead_Ind.put(">"+index+"", index);
						}

						index++;
						if( header.size() !=1) // for first case, do not append sequence
						{
							seq.add(tmp+"");
							tmp = new StringBuffer();

						}

					}else
					{
						tmp.append(strLine);
					}

				}
				seq.add(tmp+"");

				//				System.out.println("Total #seq in Multiple-lined fasta: " + seq.size() );

				br.close();
				in.close();
				fstream.close();


			} catch (Exception e) {

				e.printStackTrace();
			}




			obj.header = header;
			obj.seq = seq;
			obj.lhmHeader_VectIndex = lhmHead_Ind;

		} catch (Exception e) {
			e.printStackTrace();
		}



		return obj;

	}

	/*
	 *  Select 0-BASED start and end sub-region of each sequence of fasta file
	 */
	public static FastaMult fasta_SubRegion_FromAll_1 (String fnmFasta, int start_0based, int end_0based)
	{
		FastaMult mult = CommonFunction.fasta_readFasta_Multiplelines(fnmFasta);

		int totSeq = mult.getSeq().size();
		String curS;
		for(int i=0;i< totSeq;i++)
		{
			curS = mult.getSeq().get(i);
			mult.getSeq().set(i, curS.substring(start_0based, end_0based+1 )) ;
		}

		return mult;
	}





	public  static void fasta_mult_To_singleFasta (String fnmFasta , String fnmOut)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();

		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf.append( obj.getHeader().get(i)+"\n" );
			buf.append( obj.getSeq().get(i) + "\n");
		}

		try {

			bwr = new BufferedWriter(new FileWriter( fnmOut));
			bwr.write(buf+"");
			bwr.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	public  static void fasta_mult_To_singleFasta_MulticellularDB (String fnmFasta , String fnmOut)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();
		String tmp;
		int len;
		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf.append( obj.getHeader().get(i)+"\n" );
			tmp = obj.getSeq().get(i) ;
			len = tmp.length();

			if(tmp.charAt(len-1) =='*')
				buf.append( tmp.substring(0, len-1)+ "\n");
		}

		try {

			bwr = new BufferedWriter(new FileWriter( fnmOut));
			bwr.write(buf+"");
			bwr.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}


	/*
	 *  Create 1 file for each multi-line fasta of a file
	 */
	public  static void fasta_splitFasta_Numbered (String fnmFasta , String outDir)
	{

		BufferedWriter bwr;
		FastaMult obj = fasta_readFasta_Multiplelines(fnmFasta);

		StringBuffer buf = new StringBuffer();

		for(int i=0 ; i<obj.getHeader().size(); i++)
		{
			buf = new StringBuffer();

			buf.append( obj.getHeader().get(i)+"\n" );
			buf.append( obj.getSeq().get(i));

			try {

				bwr = new BufferedWriter(new FileWriter(outDir + "/"+ (i+1) + ".fa" ));
				bwr.write(buf+"");
				bwr.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	


	

	
	
	public static void doAllSetOperation(String fnameA, String fnameB)
	{
		StringBuffer buf = new StringBuffer();
		StringBuffer tmp = new StringBuffer();
		
		
		
		Set setNurse = new LinkedHashSet();
		Set setForager = new LinkedHashSet();
	
		try {

			FileInputStream fstream = new FileInputStream(fnameA);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			String beforeTrim;
			while(  (beforeTrim = br.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setNurse.add(  strLine );
			}
			br.close(); in.close(); fstream.close();
			buf.append( "A size:"+ setNurse.size() +"\n");
			
			
			FileInputStream fstream2 = new FileInputStream(fnameB);
			DataInputStream in2 = new DataInputStream(fstream2);
			BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
			
			while(  (beforeTrim = br2.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setForager.add(  strLine );
			}
			buf.append("B size:"+ setForager.size() + "\n");
			
			
			br2.close(); in2.close(); fstream2.close();
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);

			
			buf.append("************ Common: " + intersection.size() + "*****************" + "\n") ;
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				buf.append(  itrCom.next() +"\n");
			}
			
			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append( "*****************" + "A -B size:" + differenceNF.size() +  "*****************" +"\n" ) ; 
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append( "*****************" +" B -A size:" + differenceFN.size() +  "*****************" + "\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}
			
			
			
			
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			bwr.write(buf+"");
			bwr.close();
		
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperation(Vector<String> vA, Vector<String> vB)
	{
		Set setNurse  = new LinkedHashSet<String>();
		Set setForager  = new LinkedHashSet<String>();
		
		for(int i=0;i<vA.size();i++)
		{
			setNurse.add(vA.get(i) );
		}
		
		for(int i=0;i<vB.size();i++)
		{
			setForager.add(vB.get(i) );
		}
		
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			Iterator itrCom = intersection.iterator();
			while( itrCom.hasNext())
			{
				buf.append(  itrCom.next() +"\n");
			}

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static void doAllSetOperation(Set A, Set B)
	{
		
		Set setNurse = A;
		Set setForager = B;
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
			Iterator itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperationStat(Set A, Set B)
	{
		
		Set setNurse = A;
		Set setForager = B;
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperationStat.out"));
			
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			buf.append("********** B size :"+ setForager.size() + "******************* " +"\n");
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("**********  Common:"+ intersection.size() + "******************* " +"\n");
			

			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append("**********  A-B:"+ differenceNF.size() + "******************* " +"\n");
//			Iterator itr = differenceNF.iterator();
//			while( itr.hasNext())
//			{
//				buf.append(  itr.next() +"\n");
//			}
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append("**********  B-A:"+ differenceFN.size() + "******************* " +"\n");
//			Iterator itr2 = differenceFN.iterator();
//			while( itr2.hasNext())
//			{
//				buf.append(  itr2.next() +"\n");
//			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void doAllSetOperation_3Set_Stat(Set A, Set B , Set C, String fnmOut)
	{
		
		Set setA = A;
		Set setB = B;
		Set setC = C;
		
	
		try {
			StringBuffer buf = new StringBuffer();
			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnmOut));
			
			buf.append("n1" + "\t" + setA.size() + "\n");
			buf.append("n2" + "\t" + setB.size() + "\n");
			buf.append("n3" + "\t" + setC.size() + "\n");
			
			
			
			Set intersectionAB = new LinkedHashSet<String>(setA);
			intersectionAB.retainAll(setB);
			buf.append("n12" + "\t" +  intersectionAB.size()  +"\n");
			
			Set intersectionBC = new LinkedHashSet<String>(setB);
			intersectionBC.retainAll(setC);
			buf.append("n23" + "\t" +  intersectionBC.size()  +"\n");
			
			Set intersectionCA = new LinkedHashSet<String>(setC);
			intersectionCA.retainAll(setA);
			buf.append("n31" + "\t" +  intersectionCA.size()  +"\n");
			
			
			Set intersectionABC = new LinkedHashSet<String>(setA);
			intersectionABC.retainAll(intersectionBC);
			buf.append("n123" + "\t" + intersectionABC.size() + "\n");
			
			

			Set differenceAB = new LinkedHashSet(setA);
			differenceAB.removeAll(setB);
			buf.append("n1-2" + "\t" +  differenceAB.size()  +"\n");
			
			Set differenceAC = new LinkedHashSet(setA);
			differenceAC.removeAll(setC);
			buf.append("n1-3" + "\t" +  differenceAC.size()  +"\n");
			
			
			
			Set differenceBA = new LinkedHashSet(setB);
			differenceBA.removeAll(setA);
			buf.append("n2-1" + "\t" +  differenceBA.size() +"\n");
			
			Set differenceBC = new LinkedHashSet(setB);
			differenceBC.removeAll(setC);
			buf.append("n2-3" + "\t" +  differenceBC.size()  +"\n");
			
			Set differenceCA = new LinkedHashSet(setC);
			differenceCA.removeAll(setA);
			buf.append("n3-1" + "\t" +  differenceCA.size()  +"\n");
			
			Set differenceCB = new LinkedHashSet(setC);
			differenceCB.removeAll(setB);
			buf.append("n3-2" + "\t" +  differenceCB.size()  +"\n");
			
			
			
//			Iterator itr2 = differenceFN.iterator();
//			while( itr2.hasNext())
//			{
//				buf.append(  itr2.next() +"\n");
//			}

			bwr.write(buf+"");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void doAllSetOperation(String fnameA, int zeroBasedIndexA,  String fnameB , int zeroBasedIndexB )
	{
		
		Set setNurse = new LinkedHashSet();
		Set setForager = new LinkedHashSet();
		String tmp[];
		StringBuffer buf = new StringBuffer();
		try {

			FileInputStream fstream = new FileInputStream(fnameA);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			
			BufferedWriter bwr = new BufferedWriter(new FileWriter("setoperation.out"));
			
			String strLine;
			String beforeTrim;
			while(  (beforeTrim = br.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				setNurse.add(  tmp[zeroBasedIndexA] );
			}
			br.close(); in.close(); fstream.close();
			buf.append("**********  A size :"+ setNurse.size() + "******************* " +"\n");
			
			
			FileInputStream fstream2 = new FileInputStream(fnameB);
			DataInputStream in2 = new DataInputStream(fstream2);
			BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
			while(  (beforeTrim = br2.readLine()) !=null)
			{
				strLine = beforeTrim.trim();
				if(strLine.length() <= 0)
					continue;
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				setForager.add(  tmp[zeroBasedIndexB] );
			}
			buf.append("**********  B size :"+ setForager.size() + "******************* "  +"\n" );
			br2.close(); in2.close(); fstream2.close();
			
			Set intersection = new LinkedHashSet<String>(setForager);
			intersection.retainAll(setNurse);
			buf.append("*********** Common: " + intersection.size() + "****************"  +"\n" ) ;
			Iterator itr = intersection.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			Set differenceNF = new LinkedHashSet(setNurse);
			differenceNF.removeAll(setForager);
			buf.append(  "****************" + "diff A-B:" + differenceNF.size() + "****************"  +"\n") ;
			itr = differenceNF.iterator();
			while( itr.hasNext())
			{
				buf.append(  itr.next() +"\n");
			}
			
			
			
			Set differenceFN = new LinkedHashSet(setForager);
			differenceFN.removeAll(setNurse);
			buf.append(  "****************" + "diff B-A:" + differenceFN.size() + "****************"  +"\n") ;
			Iterator itr2 = differenceFN.iterator();
			while( itr2.hasNext())
			{
				buf.append(  itr2.next() +"\n");
			}
			
			bwr.write(buf + "");
			bwr.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static double  callFisherExactTest(int a, int b, int c, int d)
	{

		int hitA = a;
		int hitAB = a+ b;
		int totA = a+c;
		int totAB = a+b+c+d;
		return calcRightsidePValue(hitA, hitAB, totA, totAB);
	}
	
	/*
	 *                 CLASSA    CLASSB
	 *                        -----------------
	 *  PRESENT    |    k    |        |    TOTALpresent=n
	 *  ABSENT      |          |        |    TOTALabsent
	 *                         -------------------------------
	 *  TOTALclassA|        |        | TOTALclass A + B
	 *                 K                                    N
	 */

	/*
	 *  k - #PRESENT in CLASSA
	 *  n - #PRESENT in CLASSA + CLASSB
	 *
	 *  K - #TOTAL sample in CLASSA
	 *  N - #TOTAL sample in CLASSA + CLASSB
	 */
	public static double calcRightsidePValue( int hitA,int hitAB,int totA,int totAB )
	{
	        double pv,t1,x;

	/*
	        k      n-k         |  n
	        K-k    (N-K)-(n-k) |  N-n
	        -------------------------
	        K      N-K         |  N


	        This calculates the Right Hand Side PValue.
	        (LHS would be k=0,n.)
	*/
	        t1= Gamma.logGamma(((double) totA+1))+
	        		Gamma.logGamma(((double) totAB-totA+1))-
	        		Gamma.logGamma(((double) totAB+1))+
	        		Gamma.logGamma(((double) hitAB+1))+
	        		Gamma.logGamma(((double) totAB-hitAB+1));
	        
	        for (pv=-1e100; hitA<=hitAB && hitA<=totA && (hitAB-hitA)<=(totAB-totA);   hitA++) {
	                x=t1-Gamma.logGamma(((double) hitA+1))-Gamma.logGamma(((double) totA-hitA+1))-Gamma.logGamma(((double) hitAB-hitA+1))-+Gamma.logGamma(((double) totAB-totA-hitAB+hitA+1));
	                
	                pv=( pv>=x  ? pv+  Math.log(1.0+Math.exp(x-pv))  :  x+ Math.log(1.0+ Math.exp(pv-x)));
	        }

	        // Bonferroni correction (pval * nSEQF)
	        //rankDB[id].pvalue=((float) rankDB[id].nSEQF)*exp(pv);
	        //rankDB[id].pvalue=exp(pv);
	        return( Math.exp(pv));
	}
	
	
	public static boolean isOverlap( int promStart, int promEnd , int snpStart, int snpEnd )
	{

		int overlapStart = promStart > snpStart ? promStart : snpStart ; // take max
		int overlapEnd   = promEnd   < snpEnd   ? promEnd   : snpEnd   ; // take min
		int len = overlapEnd - overlapStart + 1;

		int overlapStartIndex = overlapStart - promStart   ;
		int overlapEndIndex   =  overlapStartIndex + len -1;
		
		if(overlapEndIndex >= overlapStartIndex)
			return true;
		else
			return false;
	}
	
	public static int getGenomicDist(int st1, int end1, int st2, int end2)
	{
		int minDist = Integer.MAX_VALUE;
		
		int a = Math.abs(st1 - st2);
		int b = Math.abs(st1 - end2);
		int c = Math.abs(end1 - st2);
		int d = Math.abs(end1 - end2);
		
		
		minDist = Math.min(  Math.min(a, b) , Math.min(c, d) );
		
		return minDist;
	}
	
	
	public static double distFromPoint( double refX, double refY , double poiX, double poiY)
	{
		
		return  Math.sqrt(   Math.pow((refX-poiX)  , 2) +  Math.pow(   (refY- poiY), 2) ) ;
		
	}
	
	public static int nucleotideToindex(char c) {
        switch (c) {

            case 'A':
            case 'a':
                	
                return 0;
            case 'C':
            case 'c':
                
                return 1;
            case 'G':
            case 'g':
                
                return 2;
            case 'T':
            case 't':
                
                return 3;
            default:
                double zeroToOne = myrand.nextDouble();
                if (zeroToOne >= 0 && zeroToOne <= .25) {
                    return 0;
                } else if (zeroToOne > .25 && zeroToOne <= .5) {
                    return 1;
                } else if (zeroToOne > .5 && zeroToOne <= .75) {
                    return 2;
                } else if (zeroToOne > .75 && zeroToOne <= 1.0) {
                    return 3;
                }
        }

        return 0;
	}
	
//	HG19_CHR20_43849009_43851009_+
	public static String fastaHeaderWithoutAngle(String chrm, String start, String end, String strand)
	{
		String  s = null;
		s = "HG19"+"_" + chrm.toUpperCase() + "_"  + start  + "_"  + end + "_" + strand  ;
		return  s;
	}
	
	
	public static String hocomocoHuman(String input)
	{
		int pos = input.indexOf('_');
		return input.substring(0, pos)+"_HUMAN";
	}
	
	
	/*
	 *  return index in [0 , size)
	 */
	public static int genRandomInZeroBasedRange( int size)
	{
		
		int r = generator.nextInt( size);
		return r;
	}
	
	
	public static String  formGeneID( String chrom, String start, String strand)
	{
		return  chrom+start+strand;
	}
	
	
	public  static StringBuffer selectSeriallyBasedOnOtherSerial (String fnmSerial, int index0basedKey_Order,
			String fnmRepository , int index0basedKey_Repo)
	
	{
		
		StringBuffer resBuf = new StringBuffer();
		
		LinkedHashMap<String, String> lhm_keySerial_value = CommonFunction.readlinesOfAfile_asMap_EachLine( fnmSerial, index0basedKey_Order);
		
		LinkedHashMap<String, String> lhm_keyRepsitory_value = CommonFunction.readlinesOfAfile_asMap_EachLine( fnmRepository, index0basedKey_Repo);
		
		Set set = lhm_keySerial_value.entrySet();
        System.out.println("Total Unique entry in serial:" + set.size() ) ;
        Iterator itr = set.iterator();
        while(itr.hasNext()){


            Map.Entry me = (Map.Entry) itr.next();
            String id = (String)me.getKey();
            
            if( lhm_keyRepsitory_value.containsKey(id) )
            {
            String detailsRepo = lhm_keyRepsitory_value.get(id);
            
            resBuf.append(detailsRepo + "\n");
            
            }else
            {
            	System.out.println( id+  " Does not exist in full repository");
            	
            }
           
        }
		
		
		return resBuf;
		
	}
	
	public  static Vector<String> readlinesOfAfile (String fnm)
	{

		Vector<String> seq = new Vector<String>();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				seq.add(strLine);
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return seq;
	}
	
	
	public  static String readlinesOfAfileAsBuffer (String fnm)
	{

		StringBuffer seqBuf = new StringBuffer();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				seqBuf.append(strLine+"\n");
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return seqBuf+"";
	}
	
	
	public  static Set<String> readlinesOfAfileInSet (String fnm)
	{

		Set<String> setSeq = new LinkedHashSet();
		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				setSeq.add(strLine);
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return setSeq;
	}
	
	/*
	 *  Write the string into the file
	 */
	public static void writeContentToFile (String fnm, String content)
	{
		StringBuffer buf = new StringBuffer();
		try {
			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnm));
			bwr.write(content+"");
			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static Vector<BedFormat> readBedfile(String fnmBed)
	{
		Vector<BedFormat> vec = new Vector<BedFormat>();
		try {
			FileInputStream fstream = new FileInputStream(fnmBed);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String befTrim;
			String strLine;
			String tmp[];
			BedFormat bedForm;
			while ((befTrim = br.readLine()) != null) {
				strLine = befTrim.trim();
				
				tmp = ConstantValue.patWhiteSpace.split(strLine);
				bedForm = new BedFormat(tmp[0], Integer.parseInt(tmp[1]) , Integer.parseInt(  tmp[2] ) , tmp[3], tmp[4], tmp[5].charAt(0)  );
				vec.add(bedForm);
				
			}

			System.out.println("Total line in bed file:"+vec.size());
			
			br.close();
			in.close();
			fstream.close();

			
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		return vec;
	}
	
	
	public static Vector<TrxExonInfo> readBedfileInDetails(String fnmBed)
	{
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		Vector<TrxExonInfo> vectTrx = new Vector<TrxExonInfo>();
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i), 12);
			TrxExonInfo trx = new TrxExonInfo(tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7], tmp[8], tmp[9], tmp[10], tmp[11]) ;
			vectTrx.add(trx);			
		}
		
		return vectTrx;
		
	}
	
	
	
	public static Vector<String>  readFastaHeader(String fnmFasta)
	{
		Vector<String> header = null; 
		try {

			header = new Vector<String>();
			FileInputStream fstream = new FileInputStream(fnmFasta);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			while ((strLine = br.readLine()) != null) {
				if(strLine.length()<3)
					continue;
				if(strLine.startsWith(">"))
					header.add(strLine);
			}

			br.close();
			in.close();
			fstream.close();

			
		} catch (Exception e) {

			e.printStackTrace();
		}
		return header;
	}
	
	
	
	public static boolean isEmptyFile(String fNm)
	{
		
		File f = new File(fNm);
		
		if(f.exists()){
			 
			double bytes = f.length();
			if(bytes>0)
				return true;
			else
				return false;
		}else{
			 return false;
		}

	}
	
	

	public  static LinkedHashMap<String, String> readlinesOfAfile_asMap_uniqueValue (String fnm, int index_Key_0based, int index_Value_0based )
	{

		Vector<String> seq = new Vector<String>();
		LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();

		try {
			FileInputStream fstream = new FileInputStream(fnm);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			String strLine;
			String beforeTrim;

			while ((beforeTrim = br.readLine()) != null) {
				strLine = beforeTrim.trim();
				if(strLine.length() <=0)
					continue;
				seq.add(strLine);
			}
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		String tmp[];

		for(int i=0; i<seq.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(seq.get(i));
			lhm_Key_value.put(tmp[index_Key_0based], tmp[index_Value_0based]);

		}

		System.out.println("Tot line read:"+seq.size());
		System.out.println("Tot unique key :"+ lhm_Key_value.size());

		return lhm_Key_value;
	}



	public  static LinkedHashMap<String, String> readlinesOfAfile_asMap_EachLine (String fnm, int index_Key_0based )
	{

		Vector<String> seq = new Vector<String>();
		LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();


		seq = CommonFunction.readlinesOfAfile(fnm);

		String tmp[];
		String curKey, curVal;
		for(int i=0; i<seq.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(seq.get(i));
			curKey = tmp[index_Key_0based];
			curVal = seq.get(i);


			if(lhm_Key_value.containsKey(curKey))
			{

			}else
			{
				lhm_Key_value.put( curKey,curVal);
			}

		}

		System.out.println("Tot line read:"+seq.size());
		System.out.println("Tot unique key :"+ lhm_Key_value.size());

		return lhm_Key_value;
	}





	public  static LinkedHashMap<String, Set <String>> readlinesOfAfile_asMap_setValue (String fnm, int index_Key_0based, int index_Value_0based )
	{

		Vector<String> seq = new Vector<String>();
		//		LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();
		LinkedHashMap<String, Set<String>> lhm_Key_valueSet = new LinkedHashMap<String, Set<String>>();

		//		try {
		//			FileInputStream fstream = new FileInputStream(fnm);
		//			DataInputStream in = new DataInputStream(fstream);
		//			BufferedReader br = new BufferedReader(new InputStreamReader(in));
		//
		//			String strLine;
		//			String beforeTrim;
		//
		//			while ((beforeTrim = br.readLine()) != null) {
		//				strLine = beforeTrim.trim();
		//				if(strLine.length() <=0)
		//					continue;
		//				seq.add(strLine);
		//			}
		//			br.close();
		//			in.close();
		//			fstream.close();
		//
		//		} catch (Exception e) {
		//			e.printStackTrace();
		//		}
		seq = CommonFunction.readlinesOfAfile(fnm);

		String tmp[];
		String curKey, curVal;
		for(int i=0; i<seq.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(seq.get(i));
			curKey = tmp[index_Key_0based];
			//			System.out.println("checking: "+curKey);

			if( tmp.length > index_Value_0based)
			{

				curVal = tmp[index_Value_0based];
				if(lhm_Key_valueSet.containsKey(curKey))
				{
					((Set)lhm_Key_valueSet.get(curKey)).add(curVal);
				}else
				{
					Set tmpSet = new LinkedHashSet<String>();
					tmpSet.add(curVal);
					lhm_Key_valueSet.put( curKey,tmpSet);
				}

			}





		}

//		System.out.println("Tot line read:"+seq.size());
//		System.out.println("Tot unique key :"+ lhm_Key_valueSet.size());

		return lhm_Key_valueSet;
	}




	public  static LinkedHashMap<String, Set <String>> readlinesOfAfile_asMap_setValueCommaSeperated (String fnm, int index_Key_0based, int index_Value_0based )
	{

		Vector<String> seq = new Vector<String>();
		//		LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();
		LinkedHashMap<String, Set<String>> lhm_Key_valueSet = new LinkedHashMap<String, Set<String>>();

		seq = CommonFunction.readlinesOfAfile(fnm);

		String tmp[];
		String curKey, curVal;
		for(int i=0; i<seq.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(seq.get(i));
			curKey = tmp[index_Key_0based];
			//			System.out.println("checking: "+curKey);

			if( tmp.length > index_Value_0based)
			{

				curVal = tmp[index_Value_0based];
				tmp = ConstantValue.patCSV.split(curVal);
				Set tmpSet = new LinkedHashSet<String>();
				for(int k=0; k<tmp.length;k++)
				{
					tmpSet.add(tmp[k]);
				}
				//				Iterator itrElement = tmpSet.iterator();
				//				while(itrElement.hasNext())
				//				{
				//					tmpSet.add(itrElement.next());
				//				}


				if(lhm_Key_valueSet.containsKey(curKey))
				{
					((Set)lhm_Key_valueSet.get(curKey)).addAll(tmpSet);
				}else
				{
					Set tmpSet2 = new LinkedHashSet<String>();
					tmpSet2.addAll(tmpSet);
					lhm_Key_valueSet.put( curKey,tmpSet2);
				}

			}





		}

		System.out.println("Tot line read:"+seq.size());
		System.out.println("Tot unique key :"+ lhm_Key_valueSet.size());

		return lhm_Key_valueSet;
	}




	public  static LinkedHashMap<String, Set <String>> readlinesOfAfile_asMap_setValueCommaSemicolonSeperated (String fnm, int index_Key_0based, int index_Value_0based )
	{

		Vector<String> seq = new Vector<String>();
		//		LinkedHashMap<String, String> lhm_Key_value = new LinkedHashMap<String, String>();
		LinkedHashMap<String, Set<String>> lhm_Key_valueSet = new LinkedHashMap<String, Set<String>>();

		seq = CommonFunction.readlinesOfAfile(fnm);

		System.out.println( "Total line: " + seq.size() );
		
		String tmp[];
		String curKey, curVal;
		for(int i=0; i<seq.size();i++)
		{
			
			if( i%1000 ==0)
			{
				System.out.println( "Loading map done for seq no:" + i);
			}
			
			tmp = ConstantValue.patWhiteSpace.split(seq.get(i));
			curKey = tmp[index_Key_0based];
			//			System.out.println("checking: "+curKey);

			if( tmp.length > index_Value_0based)
			{

				curVal = tmp[index_Value_0based];
				tmp = ConstantValue.patSemiColonComma.split(curVal);
				Set tmpSet = new LinkedHashSet<String>();
				for(int k=0; k<tmp.length;k++)
				{
					tmpSet.add(tmp[k]);
				}
				//				Iterator itrElement = tmpSet.iterator();
				//				while(itrElement.hasNext())
				//				{
				//					tmpSet.add(itrElement.next());
				//				}


				if(lhm_Key_valueSet.containsKey(curKey))
				{
					((Set)lhm_Key_valueSet.get(curKey)).addAll(tmpSet);
				}else
				{
					Set tmpSet2 = new LinkedHashSet<String>();
					tmpSet2.addAll(tmpSet);
					lhm_Key_valueSet.put( curKey,tmpSet2);
				}

			}





		}

		System.out.println("Tot line read:"+seq.size());
		System.out.println("Tot unique key :"+ lhm_Key_valueSet.size());

		return lhm_Key_valueSet;
	}



	/*
	 *  mapA = key1, val1
	 *  mapB = key2, val2
	 *  
	 *  if (key1==key2)
	 *  	return : (key1,val1,val2)
	 *  else
	 *  	return : (key1,val1,None) 
	 */
	public  static Vector<String> joinMapaKey_MapbKey (LinkedHashMap<String, String> mapA , LinkedHashMap<String, String> mapB  )
	{

		Vector<String> result = new Vector<String>();
		String curKey1, curValue1;
		String curKey2, curValue2;



		Set set = mapA.entrySet();
		System.out.println("Total Unique entry inf First Map:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			curKey1 = (String)me.getKey();
			curValue1 = (String) me.getValue();

			if(mapB.containsKey(curKey1))
			{
				curValue2 = (String) mapB.get(curKey1);
			}else
			{
				curValue2 = "None";
			}

			result.add(curKey1 + "\t" + curValue1 + "\t" + curValue2);


		} 

		return result;
	}



	/*
	 *  mapA = key1, val1
	 *  mapB = key2, val2
	 *  
	 *  if (val1==key2)
	 *  	return : (key1 \t val1  \t val2)
	 *  else
	 *  	return : (key1  \t val1  \t None) 
	 */
	public  static Vector<String> joinMapaValue_MapbKey (LinkedHashMap<String, String> mapA , LinkedHashMap<String, String> mapB  )
	{

		Vector<String> result = new Vector<String>();
		String curKey1, curValue1;
		String curKey2, curValue2;



		Set set = mapA.entrySet();
		System.out.println("Total Unique entry inf First Map:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			curKey1 = (String)me.getKey();
			curValue1 = (String) me.getValue();

			if(mapB.containsKey(curValue1))
			{
				curValue2 = (String) mapB.get(curValue1);
			}else
			{
				curValue2 = "None";
			}

			result.add(curKey1 + "\t" + curValue1 + "\t" + curValue2);


		} 

		return result;
	}



	/*
	 *  mapA = key1, Set<val1>
	 *  mapB = key2, Set<val2>
	 *  
	 *  if (val1==key2)
	 *  	return : (key1	val2,val2,val2)
	 *  else
	 *  	return : (key1	empty) 
	 */
	public  static Vector<String> joinMapaValue_MapbKey_Setwise (LinkedHashMap<String, Set<String>> mapA , LinkedHashMap<String, Set<String> > mapB  )
	{

		StringBuffer result = new StringBuffer();
		Vector<String> vectRes = new Vector<String>();
		String curKey1; Set curValue1Set=null;
		String curKey2; Set curValue2Set=null;

		String tmpVal1,tmpVal2;

		Set set = mapA.entrySet();
		System.out.println("Total Unique entry inf First Map:" + set.size() ) ;
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			curKey1 = (String)me.getKey();
			curValue1Set = (Set<String>) me.getValue();

			result = new StringBuffer();

			result.append(curKey1 + "\t");

			Iterator itrVal1 = curValue1Set.iterator();
			while( itrVal1.hasNext())
			{
				tmpVal1 = (String)itrVal1.next();
				if(mapB.containsKey(tmpVal1))
				{
					curValue2Set = (Set<String>) mapB.get(tmpVal1);
				}else
				{
					//                	curValue2 = "None";
				}

				if(curValue2Set!=null)
				{
					Iterator itrVal2 = curValue2Set.iterator();
					while( itrVal2.hasNext())
					{
						tmpVal2 = (String)itrVal2.next();

						result.append(  tmpVal2 +",");
					}
				}

			} // iterate each element of set1

			int lastIndex = result.lastIndexOf(",");
			vectRes.add(result.substring(0,lastIndex) + "");
			//			result.append( "\n");


		} // iterate over each Key1

		return vectRes;
	}

	

	public static void forSaeed()
	{
		
		
		for( int i=1 ;  i<= 10 ; i=i+1 )
		{
			System.out.println( 7 * i );
		}
		
		
	}
	
	public static void main(String[] args) {
		

		String foldOut= "./CoExpression/";
		String fnmSerial = "";
		String fnmRepository= "";
		String fnmOut = "";
		
//		StringBuffer resBuf = selectSeriallyBasedOnOtherSerial ("", 0,"" , 1);
//		
//		CommonFunction.writeContentToFile( "", resBuf+"");
		

//		forSaeed();
		
		// 4 hr
//		doAllSetOperation("./testOverlap/IL413Mtb_4_up.txt", 0,  "./testOverlap/Mtb_4_up.txt" , 0 ) ;
//		 doAllSetOperation("./testOverlap/IfngMtb_4_up.txt", 0,  "./testOverlap/Mtb_4_up.txt" , 0 ) ;
//		doAllSetOperation("./testOverlap/IL413Mtb_4_down.txt", 0,  "./testOverlap/Mtb_4_down.txt" , 0 ) ;
//		doAllSetOperation("./testOverlap/IfngMtb_4_down.txt", 0,  "./testOverlap/Mtb_4_down.txt" , 0 ) ;

		
		
		// 12 hr
//		doAllSetOperation("./testOverlap/IL413Mtb_12_up.txt", 0,  "./testOverlap/Mtb_12_up.txt" , 0 ) ;
//		 doAllSetOperation("./testOverlap/IfngMtb_12_up.txt", 0,  "./testOverlap/Mtb_12_up.txt" , 0 ) ;
		
//		doAllSetOperation("./testOverlap/IL413Mtb_12_down.txt", 0,  "./testOverlap/Mtb_12_down.txt" , 0 ) ;		 
//		doAllSetOperation("./testOverlap/IfngMtb_12_down.txt", 0,  "./testOverlap/Mtb_12_down.txt" , 0 ) ;
		
		
		// 24 hr
//		doAllSetOperation("./testOverlap/IL413Mtb_24_up.txt", 0,  "./testOverlap/Mtb_24_up.txt" , 0 ) ;
//		doAllSetOperation("./testOverlap/IfngMtb_24_up.txt", 0,  "./testOverlap/Mtb_24_up.txt" , 0 ) ;
			
//		doAllSetOperation("./testOverlap/IL413Mtb_24_down.txt", 0,  "./testOverlap/Mtb_24_down.txt" , 0 ) ;		 
//		doAllSetOperation("./testOverlap/IfngMtb_24_down.txt", 0,  "./testOverlap/Mtb_24_down.txt" , 0 ) ;
				

		// 48 hr
//		doAllSetOperation("./testOverlap/IL413Mtb_48_up.txt", 0,  "./testOverlap/Mtb_48_up.txt" , 0 ) ;
//		doAllSetOperation("./testOverlap/IfngMtb_48_up.txt", 0,  "./testOverlap/Mtb_48_up.txt" , 0 ) ;
			
//		doAllSetOperation("./testOverlap/IL413Mtb_48_down.txt", 0,  "./testOverlap/Mtb_48_down.txt" , 0 ) ;		 
		doAllSetOperation("./testOverlap/IfngMtb_48_down.txt", 0,  "./testOverlap/Mtb_48_down.txt" , 0 ) ;
		
		
		
//		doAllSetOperation("allID_IFNg.txt", 0,  "allID_IL413.txt" , 0 ) ;
		
		
		
		
//		doAllSetOperation("allID_IL4.txt", 0,  "allID_IL13.txt" , 0 ) ;
//		doAllSetOperation("IFNG.table.txt", 0,  "IL413.table.txt" , 0 ) ;
		
//		doAllSetOperation("a.txt", 0,  "b.txt" , 0 ) ;
		
//		Set A = new LinkedHashSet<String>();
//		A.add("A");
//		A.add("B");
//		A.add("D");
//		A.add("E");
//		
//		Set B = new LinkedHashSet<String>();
//		B.add("A");
//		B.add("B");
//		
//		Set C = new LinkedHashSet<String>();
//		C.add("A");
//		C.add("C");
//		C.add("F");
//		
//		
//		doAllSetOperation_3Set_Stat( A, B, C, "out.txt");
		
//		doAllSetOperation("selectedIFNGcage.id", 0,  "selectedIL413cage.id" , 0 ) ;
		
//		doAllSetOperation("tmp.txt", 0,  "test.txt" , 0 ) ;
		
		
		
//		doAllSetOperation("FANTOMlncRNA.id.txt", 0,  "GencodeV2lncRNA.id.txt" , 0 ) ;
		
//		for(int i=0 ; i<10; i++)
//			System.out.println( genRandomInZeroBasedRange( 33 ) );
		
		// CPS
//		doAllSetOperation("significantRankedTFBSfromNC.motif.name", 0 , "final_encode.name", 0);
		
		// REFPS
//		doAllSetOperation("motifSelectedREFPS.name", 0 , "final_encode.name", 0);
//		doAllSetOperation("motifSelectedCPS.name", 0 , "final_encode.name", 0);
		
		
		// Suzuki VS M1, M2
//		doAllSetOperation("suzuki_lncRNAID_1TPM.txt", "tanvir_lncRNAID_1TMP.txt"); 
//		doAllSetOperation("suzuki_lncRNAID.txt", "m1_trxID.txt"); 
//		doAllSetOperation("suzuki_lncRNAID.txt", "m2_trxID.txt"); 
		
		
//		doAllSetOperation("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header", "mouse_macrophage_TB_infection_non-stimulated.counts.csv.header"); 
		
//		doAllSetOperation("mouse_macrophage_TB_infection_IL4-IL13.counts.csv.header", "mouse_macrophage_TB_infection_IL13.counts.csv.header");
		
//		doAllSetOperation("NFvsIFNG.DEG.4.24.DESEQ.sigGene", 0,  "NFvsIL413.DEG.4.24.DESEQ.sigGene" , 0 ) ;
		
//		doAllSetOperation("classic.cloverid", 0,  "alternative.cloverid" , 0 ) ;
		
		//////////  COMPARE WITH PREV LIST
//		Set<String> prev = readlinesOfAfileInSet ("./noncodingPrev.fasta"); // ("./allGene1.fasta");
//		Set<String> now = readlinesOfAfileInSet("./noncodingNow.fasta");//("./allGene2.fasta");
		
//		doAllSetOperationStat(prev, now);
//		doAllSetOperation(prev, now);
		
//		doAllSetOperation("CPSb", "prevCPSb"); 
//		doAllSetOperation("CPSd", "prevCPSd");
		
//		doAllSetOperation("tmp1.txt", "tmp2.txt"); 
//		doAllSetOperation("REFPSd", "prevREFPSd");
		
//		findDuplicateTerms("./tmp1.txt", "./dup.txt", "./uniq.txt");
		
//		
//		readLastColumn("coding.withrpt.bed.tmp.refseqcoding2014.CDS.bed.overlap");
//		readLastColumn("noncoding.withrpt.bed.tmp.refseqcoding2014.CDS.bed.overlap");

//		doAllSetOperation("noncoding.withrpt.bed.tmp.CGIoverlap.nooverlap.prom.bedtools", "CGIoverlap.nooverlap.prom");
		
//		doAllSetOperation("lncrna_CPS.txt", 0, "lncrna_CPS_afterCDS.txt", 0);
		
//		fasta_doAllSetOperation_SequenceBased_MultiLines("Galaxy12-[FASTA_Width_on_data_11].fasta", "allGene.fasta");
//		
		
//		readLastColumn("noncoding.withrpt.bed.Up.count");
//		readLastColumn("noncoding.withrpt.bed.Down.count");
//		readLastColumn("noncoding.withrpt.bed.count");
//		readLastColumn("/home/alamt/CNC/FANTOManalysis/noncoding.withrpt.bed.wholebody.bed.prom.count");
		
		
//		readLastColumn("coding.withrpt.bed.Up.count");
//		readLastColumn("coding.withrpt.bed.Down.count");
//		readLastColumn("coding.withrpt.bed.count");
//		readLastColumn("/home/alamt/CNC/FANTOManalysis//coding.withrpt.bed.wholebody.bed.prom.count");
//		
		
//		readLastColumn("noncoding.withrpt.bed.bp");
		
		
	}
	
}
