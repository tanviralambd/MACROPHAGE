package com.cbrc.common;

public class SelectSeriallyBasedOnOtherSerial {

	
	
	public static void main(String[] args) {
		
		
		String foldOut= "./CoExpression/";
		String fnmSerial =  foldOut +  "SerialInput.txt";
		String fnmRepository=  foldOut +  "Repository.txt";
		String fnmOut = foldOut + "RepositoryNewSerial.txt";
		
		StringBuffer resBuf = CommonFunction.selectSeriallyBasedOnOtherSerial ( fnmSerial, 1,
				fnmRepository , 0);
		
		CommonFunction.writeContentToFile( fnmOut, resBuf+"");
		
	}
	
}
