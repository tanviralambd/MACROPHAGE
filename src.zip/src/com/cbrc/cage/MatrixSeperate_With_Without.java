package com.cbrc.cage;

import java.util.LinkedHashSet;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class MatrixSeperate_With_Without {

	
	String fin;
	
	String suffWith;
	String suffWithout;
	
	
	void doProcessing(String fnm , String sufWith, String sufWihtout)
	{
		this.fin = fnm;
		this.suffWith = sufWith;
		this.suffWithout = sufWihtout;				
		
		Vector<String> vectMat = CommonFunction.readlinesOfAfile(this.fin);
		
		/*
		 *  Manage Header/1st Line
		 */
		String firstLine = vectMat.get(0);
		String tmp[];
		tmp = ConstantValue.patWhiteSpace.split(firstLine);
		
		LinkedHashSet<Integer> setWith = new LinkedHashSet<Integer>();
		LinkedHashSet<Integer> setWithOut = new LinkedHashSet<Integer>();
		
		
		for(int i=0; i<tmp.length;i++)
		{
			if(tmp[i].startsWith("With_"))
			{
				setWith.add( i ) ;
				
			}else if ( tmp[i].startsWith("Without_"))
			{
				setWithOut.add( i ) ;
			}
		}
		
		
		/*
		 *  Manage 2nd to Last Line
		 */
		StringBuffer bufWith = new StringBuffer();
		StringBuffer bufWithout = new StringBuffer();
		
		for(int i=0; i<vectMat.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vectMat.get(i));
			for(int j=0; j<tmp.length; j++)
			{
				if(setWith.contains(j))
				{
					bufWith.append(tmp[j]+"\t");
				}else if (setWithOut.contains(j))
				{
					bufWithout.append(tmp[j]+"\t");
				}else
				{
					bufWith.append(tmp[j]+"\t");
					bufWithout.append(tmp[j]+"\t");
				}
				
			}
			
			bufWith.append("\n");
			bufWithout.append("\n");
			
			
		}
		
		CommonFunction.writeContentToFile(this.fin+ this.suffWith     , bufWith+"");
		CommonFunction.writeContentToFile(this.fin+ this.suffWithout  , bufWithout+"");
		
		
		
		
		
	}
	
	public static void main(String[] args) {
		
		MatrixSeperate_With_Without obj = new MatrixSeperate_With_Without();
		obj.doProcessing(args[0], args[1] , args[2]);
//		obj.doProcessing("mouse_macrophage_TB_infection_IL13.counts.csv.matrix.6.6" , ".withMtb" , ".withoutMtb") ; //("mouse_macrophage_TB_infection_IFNg.counts.csv.matrix.28.28");
		
	}
	
	
	
}
