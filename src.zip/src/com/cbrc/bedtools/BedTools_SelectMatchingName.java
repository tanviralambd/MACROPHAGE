package com.cbrc.bedtools;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.sql.CommonDataSource;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class BedTools_SelectMatchingName {

	
	String fnameBedForthColumn;
	String fBed;
	String fOutBed;
	
	
	
	
	public BedTools_SelectMatchingName(String fnameBedForthColumn, String fBed,
			String fOutBed) {
		super();
		this.fnameBedForthColumn = fnameBedForthColumn;
		this.fBed = fBed;
		this.fOutBed = fOutBed;
	}


	void doProcessing()
	
	{
		
		Vector<String> vectAllID = CommonFunction.readlinesOfAfile(this.fnameBedForthColumn);
		Vector<String> vectAllBed = CommonFunction.readlinesOfAfile(this.fBed);
		
		LinkedHashMap<String, String> lhm_Name_fullLine = new LinkedHashMap<String, String>();
		
		String tmp[];
		String curLine;
		for(int i=0; i<vectAllBed.size();i++)
		{
			curLine = vectAllBed.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			lhm_Name_fullLine.put(tmp[3], curLine);
		}
		
		
		StringBuffer buf = new StringBuffer();
		String id , line;
		
		for(int i=0; i<vectAllID.size();i++)
		{
			id = vectAllID.get(i);
			buf.append(lhm_Name_fullLine.get(id) + "\n");
			
		}
		
		
//		Set set = lhm_Name_fullLine.entrySet();
//        System.out.println("Total Unique entry:" + set.size() ) ;
//        Iterator itr = set.iterator();
//        while(itr.hasNext()){
//
//
//            Map.Entry me = (Map.Entry) itr.next();
//            id = (String)me.getKey();
//            line = (String) me.getValue();
//           
//           
//        }
		
		
		
		CommonFunction.writeContentToFile(this.fOutBed, buf+"");
		
	}
	
	
	public static void main(String[] args) {
		
//		BedTools_SelectMatchingName obj = new BedTools_SelectMatchingName(args[0] , args[1], args[2]);
		
		
//		BedTools_SelectMatchingName obj = new BedTools_SelectMatchingName("degLncRNA.id" , "finalLncRNA.bed.prom", "selected.finalLncRNA.bed.prom");
//		BedTools_SelectMatchingName obj = new BedTools_SelectMatchingName("degLncRNA.id" , "finalLncRNA.bed", "selected.finalLncRNA.bed");
		
		
//		BedTools_SelectMatchingName obj = new BedTools_SelectMatchingName("degmRNA.id" , "refGene.mm9.NM.bed.prom", "selected.refGene.mm9.NM.bed.prom");
		BedTools_SelectMatchingName obj = new BedTools_SelectMatchingName("degmRNA.id" , "refGene.mm9.NM.bed", "selected.refGene.mm9.NM.bed");
			
		
		
		obj.doProcessing();
		
	}
	
	
}
