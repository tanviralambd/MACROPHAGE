package com.cbrc.bedtools;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class BedTools_NonRedundantTSS_FromBED {


	String fnmRedundant;
	String fnmNonRedundant_TSS;





	public BedTools_NonRedundantTSS_FromBED(String fnmRedundant,
			String fnmNonRedundant_TSS) {
		super();
		this.fnmRedundant = fnmRedundant;
		this.fnmNonRedundant_TSS = fnmNonRedundant_TSS;
	}

	void doProcessing()
	{
		Vector<String> vectBed = CommonFunction.readlinesOfAfile(this.fnmRedundant);
		StringBuffer resBuf = new StringBuffer();

		String tmp[];
		String curLine,curID;
		String chrm,start,end,name,score,strand;

		LinkedHashMap<String, String> lhm_id_descBED = new LinkedHashMap<String, String>();


		for(int i=0; i<vectBed.size();i++)
		{
			curLine = vectBed.get(i);
			tmp = ConstantValue.patTab.split( curLine);

			chrm   = tmp[0];
			start  = tmp[1] ;
			end    = tmp[2] ;
			strand = tmp[5] ;


			curID = CommonFunction.getUniqueNameFromBed_0based(chrm, start, end, strand);

			if(lhm_id_descBED.containsKey(curID))
			{

			}else
			{
				lhm_id_descBED.put(curID, curLine);
			}


		}


		System.out.println("Input file had entries: "+ vectBed.size());
		System.out.println("Input file had Non-Redundant TSS entries: "+ lhm_id_descBED.size());



		/// Write it

		Set set = lhm_id_descBED.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()){


			Map.Entry me = (Map.Entry) itr.next();
			String id = (String)me.getKey();
			String desc = (String) me.getValue();

			resBuf.append(desc + "\n");
		}

		CommonFunction.writeContentToFile(this.fnmNonRedundant_TSS, resBuf+"");
	}

	public static void main(String[] args) {


				BedTools_NonRedundantTSS_FromBED obj = new BedTools_NonRedundantTSS_FromBED(args[0] , args[1]);

//		BedTools_NonRedundantTSS_FromBED obj = new BedTools_NonRedundantTSS_FromBED("test.bed" , "test.NR.bed");

		obj.doProcessing();
	}

}
