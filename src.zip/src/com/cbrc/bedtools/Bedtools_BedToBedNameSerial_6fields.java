package com.cbrc.bedtools;



import java.util.Vector;
import java.util.regex.Pattern;
import com.cbrc.bean.BedFormat;
import com.cbrc.common.CommonFunction;

public class Bedtools_BedToBedNameSerial_6fields {

	
	void convert_Bed_To_TSS(String fnmBed, String fnmBedOutput)
	{
		
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		BedFormat myBed;
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i));
			myBed = new BedFormat(tmp[0], tmp[1], tmp[2], tmp[3] , tmp[4 ], tmp[5] , i);

			buf.append(myBed.toString_6fields_WithtSerialNumber() +"\n");
			
		}
	
		CommonFunction.writeContentToFile(fnmBedOutput, buf+"");
		
	}
	

	
	
	public static void main(String[] args) {
		Bedtools_BedToBedNameSerial_6fields obj = new Bedtools_BedToBedNameSerial_6fields();
		obj.convert_Bed_To_TSS(args[0],   args[1] ); 

		
	}
}

