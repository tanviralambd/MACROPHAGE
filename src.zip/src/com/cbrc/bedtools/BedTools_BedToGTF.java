package com.cbrc.bedtools;

import java.util.Vector;

import com.cbrc.bean.BedFormat;
import com.cbrc.common.CommonFunction;

public class BedTools_BedToGTF {

	
	void convert_Bed_Gtf(String fnmBed, String fnmGtf)
	{
		
		
		Vector<BedFormat> myBed=  CommonFunction.readBedfile(fnmBed);
		
		StringBuffer buf = new StringBuffer();
//		StringBuffer tmpBuf;
		BedFormat curBed;
		for(int i=0; i<myBed.size() ;i++)
		{
//			tmpBuf = new StringBuffer();
			curBed = myBed.get(i);
			
			buf.append(curBed.getChrom()+"\t"+"LLlab"+"\t"+"transcript"+ "\t"+
			(curBed.getStart()+1)+"\t" +curBed.getEnd()+"\t"+curBed.getScore()+"\t"+curBed.getStrand()+"\t" +
			"."+"\t"+ ( "transcript_id \""+curBed.getName()+"\";"  )+"\n");
			
			
		}
		
		CommonFunction.writeContentToFile(fnmGtf, buf+"");
		
		
	}
	
	public static void main(String[] args) {
		BedTools_BedToGTF obj = new BedTools_BedToGTF();
//		obj.convert_Bed_Gtf("./coding.withrpt.bed", "./coding.withrpt.bed.gtf" );
//		obj.convert_Bed_Gtf("./noncoding.withrpt.bed", "./noncoding.withrpt.bed.gtf" );
		
	}
}
