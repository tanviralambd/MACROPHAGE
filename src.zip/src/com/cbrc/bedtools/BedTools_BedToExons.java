package com.cbrc.bedtools;

import java.util.Vector;
import java.util.regex.Pattern;

import com.cbrc.bean.TrxExonInfo;
import com.cbrc.common.CommonFunction;

public class BedTools_BedToExons {

	
	void convert_Bed_To_Exons(String fnmBed, String fnmBedExons)
	{
		
		String tmp[];
		Pattern p = Pattern.compile("[\\t]+");
		Vector<String> vectBedStr = CommonFunction.readlinesOfAfile(fnmBed);
		StringBuffer buf = new StringBuffer();
		for(int i=0;i<vectBedStr.size();i++)
		{
			tmp = p.split(vectBedStr.get(i), 12);
			TrxExonInfo trx = new TrxExonInfo(tmp[0], tmp[1], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6], tmp[7], tmp[8], tmp[9], tmp[10], tmp[11]) ;
			
			
			// create 1 entry for transcript
			
			buf.append(trx.getChrom()+"\t"+"LLlab"+"\t"+"transcript"+ "\t"+
					(trx.getStart()+1)+"\t" +trx.getEnd()+"\t"+trx.getScore()+"\t"+trx.getStrand()+"\t" +
					"."+"\t"+ getAdditionalInfoMandatory(trx.getName() ) +"\n");
			
			// create multiple entry for exons
			
			for(int  e=0; e<trx.getExonStarts().size(); e++)
			{
				buf.append(trx.getChrom()+"\t"+"LLlab"+"\t"+"exon"+ "\t"+
						(trx.getExonStarts().get(e)+1)+"\t" +trx.getExonEnds().get(e)+"\t"+trx.getScore()+"\t"+trx.getStrand()+"\t" +
						"."+"\t"+ getAdditionalInfoMandatory(trx.getName() ) +"\n");
				
			}
		}
	
			
	
		CommonFunction.writeContentToFile(fnmBedExons, buf+"");
		
	}
	
	String getAdditionalInfoMandatory(String trxID)
	{
		return 
			" gene_id "    + trxID + ";" +
			" transcript_id " + trxID + ";" +
			" gene_type "    + "RNA" + ";" +
			" gene_status "    + "KNOWN" + ";" +
			" gene_name "    + trxID + ";" +
			" transcript_type "    + "RNA" + ";" +
			" transcript_status "    + "KNOWN" + ";" +
			" transcript_name "    + trxID + ";" +
			" level "    + "1" + ";" ;
			
	}
	
	
	public static void main(String[] args) {
		BedTools_BedToExons obj = new BedTools_BedToExons();
		obj.convert_Bed_To_Exons(args[0],   args[1] ); 
		// example
//		obj.convert_Bed_GencodeGtfv3("./test.bed",    "./coding.withrpt.bed.wholebody.bed.gtf3" ); // "./coding.withrpt.bed.wholebody.bed"
//		obj.convert_Bed_GencodeGtfv3("./noncoding.withrpt.bed.wholebody.bed.bed", "./noncoding.withrpt.bed.wholebody.bed.gtf3" );
		
	}
}
