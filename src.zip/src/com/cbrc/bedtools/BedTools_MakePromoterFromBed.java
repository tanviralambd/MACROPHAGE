package com.cbrc.bedtools;

import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;


/*
 *  Create Bed Format promoters
 *  Input: 
 *  	bedFile
 *  	upstream
 *  	downstream : If downstream =-1, then take the whole gene body
 *  
 *  Output:
 *  	bedFile containing promoters
 *  
 *  
 *  Example
 *     input.bed  1000  200 output.bed  -- it creates a promoter [-1000,200]
 *     input.bed  1000  -1 outputWholeBody.bed -- it creates a promoter [-1000, whole gene body]
 */

public class BedTools_MakePromoterFromBed {

	
	String fnmInBed;
	
	int upstream;
	int downstream;
	
	String fnmOutBed;
	
	
	
	
	public BedTools_MakePromoterFromBed(String finBed, int upstream,
			int downstream, String fnmOutBed) {
		super();
		this.fnmInBed = finBed;
		this.upstream = upstream;
		this.downstream = downstream;
		this.fnmOutBed = fnmOutBed;
	}


	void doProcessing()
	{
		
		Vector<String> vectBed = CommonFunction.readlinesOfAfile(this.fnmInBed);
		
		String tmp[];
		String curStr;
		
		StringBuffer nonMandatory;
		
		// mandatory 6 fields
		String chrm, name, score,strand;
		int start,end;
		
		int promStartCoord,promEndCoord;
		StringBuffer bufPromoter = new StringBuffer();
		
		for(int i=0 ; i<vectBed.size();i++)
		{
			curStr = vectBed.get(i).trim();
			tmp = ConstantValue.patWhiteSpace.split(curStr);
			
			// mandatory
			
			chrm = tmp[0]; start = Integer.parseInt(tmp[1] ); 	end = Integer.parseInt(tmp[2]); name = tmp[3]; score =tmp[4]; 	strand= tmp[5];
			
			// optional
			nonMandatory = new StringBuffer();
			for(int j=6;j<tmp.length ;j++)
			{
				nonMandatory.append(tmp[j]+"\t");
			}
			
			
			
			if (downstream>= 0) // NORMAL
			{
				promStartCoord  = (strand.compareTo("+") ==0 ) ? start - upstream    : end - downstream;
				promEndCoord    = (strand.compareTo("+") ==0 ) ? start + downstream  : end + upstream ;
				
			}else // take the whole gene body . EXCEPTIONAL
			{
				// EXCEPTIONAL.  As it is the WHOLE GENE BODY
				promStartCoord  = (strand.compareTo("+") ==0 ) ? start - upstream    : start;
				promEndCoord    = (strand.compareTo("+") ==0 ) ? end  : end + upstream ;
			}
			
			bufPromoter.append(chrm+"\t" + promStartCoord + "\t" + promEndCoord + "\t" + name + "\t" + score + "\t" + strand + "\t" + nonMandatory +"\n");
			
			
			nonMandatory = null;
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOutBed, bufPromoter+"");
		
	}


	public static void main(String[] args) {
		
		
//		BedTools_MakePromoterFromBed obj = new BedTools_MakePromoterFromBed(args[0], Integer.parseInt( args[1] ), Integer.parseInt(  args[2] ) , args[3] );
		

		// normal UPSTREM as DOWNSTREAM
//		BedTools_MakePromoterFromBed obj = new BedTools_MakePromoterFromBed( "finalLncRNA.bed", Integer.parseInt( "500" ), Integer.parseInt(  "500" ) , "finalLncRNA.bed.prom" );
		BedTools_MakePromoterFromBed obj = new BedTools_MakePromoterFromBed( "refGene.mm9.NM.bed", Integer.parseInt( "500" ), Integer.parseInt(  "500" ) , "refGene.mm9.NM.bed.prom" );
		
		
		
		// WHOLE BODY as DOWNSTREAM
//		BedTools_MakePromoterFromBed obj = new BedTools_MakePromoterFromBed( "tmp.txt.bed", Integer.parseInt( "1000" ), Integer.parseInt(  "-1" ) , "tmp.txt.bed.prom" );
		
		obj.doProcessing();
		
		
	}
}
