package com.cbrc.bedtools;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Pattern;

import com.cbrc.bean.BedFormat;
import com.cbrc.bean.RMSK;
//import com.cbrc.chipseq.PromoterFeature;
import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class BedTools_Minus {


	String fnmOne;
	String fnmTwo;
	String fnmOut;

	//	String foldIn1;
	//	String foldIn2;
	//
	//	String foldOut;

	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState = new HashMap<String, Vector<BedFormat>>();
	HashMap<String, Vector<BedFormat> > mapChrmWisePromoterState2 = new HashMap<String, Vector<BedFormat>>();


	//	public void init(String foldIn1, String foldIn2, String foldOut, String fnm1, String fnm2, String fnmOut)
	//	{
	//		this.foldIn1 = foldIn1;
	//		this.foldIn2 = foldIn2;
	//		this.foldOut = foldOut;
	//		this.fnmOne = this.foldIn1 + "/" + fnm1;
	//		this.fnmTwo =  this.foldIn2 + "/" +  fnm2;
	//
	//		this.fnmOut =  this.foldOut + "/" + fnmOut;		
	//
	//	}


	public void init( String fnm1, String fnm2, String fnmOut)
	{

		this.fnmOne =  fnm1;
		this.fnmTwo =  fnm2;

		this.fnmOut =  fnmOut;		

	}

	void makeChrmWisePromoterMap() {
		System.out.println("Extracting prom info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[,\\t]+");
		int index = 0;

		try {

			FileInputStream fstream = new FileInputStream(fnmOne);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));


			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);

				try {
					addInChrMap( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total PROMOTER entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();
			//            out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}





	void addInChrMap( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState.containsKey(chrm)) {
			mapChrmWisePromoterState.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState.put(chrm, vp);
		}

	}


	void addInChrMap2( String chrm, int start, int end,   String name, String score ,char strand) {

		BedFormat pm = new BedFormat(chrm, start, end,    name ,score,strand);

		if (mapChrmWisePromoterState2.containsKey(chrm)) {
			mapChrmWisePromoterState2.get(chrm).add(pm);
		} else {
			Vector<BedFormat> vp = new Vector<BedFormat>();
			vp.add(pm);
			mapChrmWisePromoterState2.put(chrm, vp);
		}

	}


	void makeChrmWisePromoterMap2() {
		System.out.println("Extracting peak info ... ... ... ");
		String strLine = null;
		String tmp[];
		Pattern p = Pattern.compile("[,\\t]+");
		int index = 0;
		try {

			FileInputStream fstream = new FileInputStream(fnmTwo);//test.combine.bed.promoter
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			while ((strLine = br.readLine()) != null) {

				if (strLine.startsWith(">")) {
					continue;
				}
				if (strLine.length() < 3) {
					continue;
				}
				tmp = p.split(strLine, 7);

				try {

					addInChrMap2 ( tmp[0], Integer.parseInt(tmp[1])   , Integer.parseInt(tmp[2])   ,  tmp[3], tmp[4] , tmp[5].charAt(0)); // as UCSC startIndex 0 based, endIndex 1 based 

				} catch (Exception e) {
					e.printStackTrace();
				}
				index++;

			}

			System.out.println("Total PEAK entry in the file:" + index); //9918801
			br.close();
			in.close();
			fstream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void findMinus()
	{
		boolean include = true;
		int disMidPoint=0;
		String other=null;
		try {
			BufferedWriter bwr = new BufferedWriter(new FileWriter( this.fnmOut));
			StringBuffer bufResult = new StringBuffer();

			Set setChrm = mapChrmWisePromoterState.entrySet();
			Set setChrm2 = mapChrmWisePromoterState2.entrySet();


			Iterator it = setChrm.iterator();
			while (it.hasNext()) {
				Map.Entry me = (Map.Entry) it.next();
				String currentChrm = (String)me.getKey();
				//				System.out.println("Find overlap in chromosome:"+ currentChrm);

				Vector<BedFormat> vp = (Vector<BedFormat>) me.getValue();
				Vector<BedFormat> vp2 =  mapChrmWisePromoterState2.get(currentChrm);
				if(vp2==null)
					System.out.println("No B file entry found for chromosome: "+ currentChrm) ;
				for(int i=0;  i<vp.size() ;i++)
				{
					include = true;
					if(vp2 != null)
					{
						for(int j=0; j<vp2.size();j++)
						{

							if(CommonFunction.isOverlap(vp.get(i).getStart(), vp.get(i).getEnd() ,vp2.get(j).getStart() ,vp2.get(j).getEnd()))
							{
								include = false;
								j = vp2.size();
							}
						}

						if(include)
						{
							bufResult.append((  vp.get(i).getChrom()+"\t" +  vp.get(i).getStart() + "\t" + vp.get(i).getEnd() + "\t" + vp.get(i).getName() + "\t"+ vp.get(i).getScore()+"\t" +vp.get(i).getStrand() +"\n" ) );
						}
					}else // chrm in A is not found in chr in B
					{
						bufResult.append((  vp.get(i).getChrom()+"\t" +  vp.get(i).getStart() + "\t" + vp.get(i).getEnd() + "\t" + vp.get(i).getName() + "\t"+ vp.get(i).getScore()+"\t" +vp.get(i).getStrand() +"\n" ) );
					}

				}

			}

			bwr.write(bufResult+"");

			bwr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}




	}

	void doProcessing()
	{
		makeChrmWisePromoterMap();
		makeChrmWisePromoterMap2();

		findMinus();


	}

	public static void main(String[] args) {

		BedTools_Minus obj = new BedTools_Minus();


		//		obj.init("testa.bed", "testb.bed" , "check.bed" );

		obj.init(args[0], args[1], args[2]);

		obj.doProcessing();




	}


}
