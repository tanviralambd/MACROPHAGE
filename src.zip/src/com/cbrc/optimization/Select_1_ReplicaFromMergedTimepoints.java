package com.cbrc.optimization;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class Select_1_ReplicaFromMergedTimepoints {

	String finDataNormalized;
	String suffix1st;
	String suffix2nd;
	String finTimes;
	
	
	Vector<String> vecTimes ;
	Vector<String> vecData  ;
	
	void init(String finName, String suf1 , String suf2 , String times)
	{
		this.finDataNormalized = finName;
		this.suffix1st = suf1;
		this.suffix2nd = suf2;
		this.finTimes = times;
	}
	
	void doProcessing()
	{
	
		vecTimes = CommonFunction.readlinesOfAfile(this.finTimes);
		vecData  = CommonFunction.readlinesOfAfile(this.finDataNormalized);
		
		Set<Integer> setColumn0based_first = new LinkedHashSet<Integer>();
		Set<Integer> setColumn0based_second = new LinkedHashSet<Integer>();
		
		
		setColumn0based_first  = findCoumns(suffix1st);
		setColumn0based_second = findCoumns(suffix2nd);
		
		writeSelectdColumns(setColumn0based_first , suffix1st);
		writeSelectdColumns(setColumn0based_second , suffix2nd);
		
		
	}
	
	void writeSelectdColumns(Set setColumn , String suf)
	{
		String tmp[];
		
		StringBuffer bufResult = new StringBuffer();
		for(int i=1;  i<vecData.size();i++)
		{
			tmp = ConstantValue.patWhiteSpace.split(vecData.get(i));
			
			for(int j=0;  j<tmp.length;j++)
			{
				if(setColumn.contains(j))
				{
					bufResult.append(tmp[j] + "\t");
				}
			}
			bufResult.append("\n");
			
		}
		CommonFunction.writeContentToFile(this.finDataNormalized+"."+suf, bufResult+"");
	}
	
	
	Set<Integer>  findCoumns(String suff)
	{
		String firstLine = vecData.get(0);
		String tmpHeader[] = ConstantValue.patWhiteSpace.split(firstLine);
		Set<Integer> setColumn_Obased = new LinkedHashSet<Integer>();
		
		String curTimeString;
		Pattern curPat;
		Matcher mymatcher;
		
		boolean found=false;
		/*
		 *  For each time, check suffix
		 */
		for(int i=0;  i<vecTimes.size();i++)
		{
			curTimeString = vecTimes.get(i);
			System.out.println("Cur Time: "+curTimeString);
			curPat = Pattern.compile(curTimeString+ "(.)+" + "1_"+ suff);
			found = false;
			
			for(int j=0; j<tmpHeader.length ;j++)
			{
				mymatcher = curPat.matcher(tmpHeader[j]);
				if(mymatcher.find())
				{
					System.out.println("Matched pattern: "+ tmpHeader[j] + " in column position: " + (j) );
					found=true;
					setColumn_Obased.add(j+1);
				}
				if(found) // For selecting one
					break;
			}
			
			
		}
		
		return setColumn_Obased;
		
	}
	
	
	public static void main(String[] args) {
		
		Select_1_ReplicaFromMergedTimepoints obj = new Select_1_ReplicaFromMergedTimepoints();
//		obj.init("NFvsIFNG.matrix.4.24.withoutMtb.norm.EDGER" , "NF" , "IFNG", "timePointsWithoutMtb.txt");
		obj.init(args[0],args[1], args[2],args[3]);
		
		obj.doProcessing();

		
		
	}
}
