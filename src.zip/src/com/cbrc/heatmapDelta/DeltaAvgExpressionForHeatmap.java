package com.cbrc.heatmapDelta;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import com.cbrc.common.CommonFunction;
import com.cbrc.constant.ConstantValue;

public class DeltaAvgExpressionForHeatmap {

	
	
	String fnmID;
	String fnmAvgExpr;
	String fnmDeltaAvgExpr;
	
	
	
	
	
	public DeltaAvgExpressionForHeatmap(String fnmID, String fnmAvgExpr,
			String fnmDeltaAvgExpr) {
		super();
		this.fnmID = fnmID;
		this.fnmAvgExpr = fnmAvgExpr;
		this.fnmDeltaAvgExpr = fnmDeltaAvgExpr;
	}


	Set<String> selectedID = new LinkedHashSet<String>();
	
	
	
	void loadSelectedID()
	{
		this.selectedID = CommonFunction.readlinesOfAfileInSet(this.fnmID);
		
	}
	
	
	void writeDeltaAvgExpression()
	{
		StringBuffer bufRes = new StringBuffer();
		String tmp[];
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmAvgExpr);
		
		String curcageID , curGeneList;
		
		double delta28 ,delta36, delta48, delta72 ;
		
		
		bufRes.append("\tGeneID\t" + "t_28h\t" + "t_36h\t"  + "t_48h\t" + "t_72h\n" );
		
		for( int i=1 ;  i<vectAll.size() ; i++)
		{
			
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			
			curcageID = tmp[0];
			
			if(selectedID.contains(curcageID))
			{
				curGeneList = tmp[1];
				
				delta28 = Double.parseDouble(tmp[6]) - Double.parseDouble(tmp[2]);
				delta36 = Double.parseDouble(tmp[7]) - Double.parseDouble(tmp[3]);
				delta48 = Double.parseDouble(tmp[8]) - Double.parseDouble(tmp[4]);
				delta72 = Double.parseDouble(tmp[9]) - Double.parseDouble(tmp[5]);
				
				
				bufRes.append(curcageID + "\t" + curGeneList + "\t" + 
						delta28 + "\t" + delta36 + "\t" + delta48 + "\t" + delta72 + "\n" );
			}
			
			
			
		}
		
		
		
		CommonFunction.writeContentToFile(this.fnmDeltaAvgExpr, bufRes+"");
	}
	
	void doProcessing()
	{
	
		loadSelectedID();
		
		
		writeDeltaAvgExpression();
		
	}
	
	
	public static void main(String[] args) {
		
		
//		DeltaAvgExpressionForHeatmap obj = new DeltaAvgExpressionForHeatmap(args[0], args[1], args[2]);
		
		DeltaAvgExpressionForHeatmap obj1 = new DeltaAvgExpressionForHeatmap(
				"IFNG.specific.id", 
				"IFNG.table.txt.report", 
				"IFNG.table.txt.report.specific");
		
		DeltaAvgExpressionForHeatmap obj2 = new DeltaAvgExpressionForHeatmap(
				"IL413.specific.id", 
				"IL413.table.txt.report", 
				"IL413.table.txt.report.specific");
		
		
		DeltaAvgExpressionForHeatmap obj3 = new DeltaAvgExpressionForHeatmap(
				"Mtb.specific.id", 
				"NONSTIM.table.txt.report", 
				"NONSTIM.table.txt.report.specific");
		
		
		
		DeltaAvgExpressionForHeatmap obj4 = new DeltaAvgExpressionForHeatmap(
				"IFNG.IL413.Mtb.id", 
				"IFNG.table.txt.report", 
				"IFNG.table.txt.report.common");
		
		
		DeltaAvgExpressionForHeatmap obj5 = new DeltaAvgExpressionForHeatmap(
				"IFNG.IL413.Mtb.id", 
				"IL413.table.txt.report", 
				"IL413.table.txt.report.common");
		
		
		DeltaAvgExpressionForHeatmap obj = new DeltaAvgExpressionForHeatmap(
				"IFNG.IL413.Mtb.id", 
				"NONSTIM.table.txt.report", 
				"NONSTIM.table.txt.report.common");
		
		obj.doProcessing();
		
	}
	
}
