package com.cbrc.folderoperation;

import java.util.List;
import java.util.Vector;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.*;

import org.apache.commons.io.FileUtils;

public class FolderOperations {


	public static Vector<String> listFiles_Files_Dir(String absPathFolder)
	{
		Vector<String> vectAllFiles = new Vector<String>();


		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {

				//				System.out.println("File: " + listOfFiles[i].getName());
				vectAllFiles.add(listOfFiles[i].getName() );

			} else if (listOfFiles[i].isDirectory()) {

				//				System.out.println("Directory: " + listOfFiles[i].getName());
				vectAllFiles.add(listOfFiles[i].getName() );

			}
		}

		return vectAllFiles;
	}


	
	public static Vector<String> listFiles_Dir(String absPathFolder)
	{
		Vector<String> vectAllDirectories = new Vector<String>();


		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {

				//				System.out.println("File: " + listOfFiles[i].getName());
//				vectAllFiles.add(listOfFiles[i].getName() );

			} else if (listOfFiles[i].isDirectory()) {

//				System.out.println("Directory: " + listOfFiles[i].getName()); // + absPathFolder+ "/" +
				vectAllDirectories.add(  listOfFiles[i].getName() ); //  absPathFolder + "/" + 

			}
		}

		return vectAllDirectories;
	}


	
	public static Vector<String> listFiles_Files(String absPathFolder)
	{
		Vector<String> vectAllFiles = new Vector<String>();


		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {

				//				System.out.println("File: " + listOfFiles[i].getName());
				vectAllFiles.add(listOfFiles[i].getName() );

			} else if (listOfFiles[i].isDirectory()) {

				//				System.out.println("Directory: " + listOfFiles[i].getName());
				//			 vectAllFiles.add(listOfFiles[i].getName() );

			}
		}

		return vectAllFiles;
	}
	
	public static Vector<String> listFiles_Files_MatchingExt(String absPathFolder, String ext)
	{
		Vector<String> vectAllFiles = new Vector<String>();


		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {

				//				System.out.println("File: " + listOfFiles[i].getName());
				if(  listOfFiles[i].getName().endsWith( ext))
				{
					vectAllFiles.add(listOfFiles[i].getName() );
				}

			} else if (listOfFiles[i].isDirectory()) {

				//				System.out.println("Directory: " + listOfFiles[i].getName());
				//			 vectAllFiles.add(listOfFiles[i].getName() );

			}
		}

		return vectAllFiles;
	}


	public static Vector<String> listAllFilesInDirectoryBasedOnExtensions(String absPathFolder,String myExt) {


		Vector<String> vectAllFiles = new Vector<String>();

		String curFullName="";
		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {

				curFullName = listOfFiles[i].getName();
				if(curFullName.endsWith(myExt))
				{
					vectAllFiles.add(listOfFiles[i].getName() );
//					System.out.println(listOfFiles[i].getName());
					
				}
				

			} else if (listOfFiles[i].isDirectory()) {

				//				System.out.println("Directory: " + listOfFiles[i].getName());
//				vectAllFiles.add(listOfFiles[i].getName() );

			}
		}

//		System.out.println( "Total match found: " + vectAllFiles.size() );
		
		return vectAllFiles;

		
		
		
		

	}
	

	/*
	 *  myDir = Absolute pathe of directory
	 *  myExt = extension without '.' symbol. If you place '.' symbol it will not work.
	 */
	public static Vector<String> letAllFilesInDirectoryBasedOnExtensionsNotUsed(String myDir,String myExt) {


		Vector<String> resFileNames = new Vector<String>();

		try {
			File dir = new File(myDir);
			
//			String[] extensions1 = new String[] { "txt", "jsp" };
//			System.out.println("Getting all .txt and .jsp files in " + dir.getCanonicalPath()+ " including those in subdirectories");
			
			String[] extensions = new String[] { myExt };
			List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, true);


			String curpath;
			for (File file : files) {
				curpath = file.getCanonicalPath() ;
				resFileNames.add(curpath);
			}


		} catch (Exception e) {
			e.printStackTrace();
		}

		return resFileNames;

	}


	/*
	 *   pathCopy  =  Absolute path of existing file 
	 *   pathPaste = Absolute path of new file to be created
	 */

	public static void copy_paste_file(String pathCopy, String pathPaste)
	{
		try {
			File source = new File(pathCopy);
			File dest = new File(pathPaste);
			Files.copy(source.toPath(), dest.toPath() , StandardCopyOption.REPLACE_EXISTING );
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 *  absPathFolder = Absolute path of new folder to be created
	 */
	public static void create_new_folder(String absPathFolder)
	{
		File theDir = new File(absPathFolder);

		// if the directory does not exist, create it
		if (!theDir.exists()) {
			System.out.println("creating directory: " + absPathFolder);

			try{
				theDir.mkdir();
			} catch(SecurityException se){
				se.printStackTrace();
			}

		}
	}



	public static boolean isFileExistInFolder(String abspathFinename)
	{

		try {
			File source = new File(abspathFinename);
			if(source.exists())
				return true;
			else
				return false;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}


	public static void main(String[] args) {

		FolderOperations obj = new FolderOperations();

		//		 obj.copy_paste_file("./ENCODEname_UNIPROT_HOCOMOCO.txt", "./bin/ENCODEname_UNIPROT_HOCOMOCO.txt");
		//		obj.create_new_folder("./tanvir");
//		Vector<String> fList = obj.listFiles_Files_Dir("./today") ;
		
//		Vector<String> fList = obj.listFiles_Dir("./today") ;
		
		Vector<String> fList  = listFiles_Files_MatchingExt("./" , ".txt");
		
		
//		obj.letAllFilesInDirectoryBasedOnExtensions("/run/media/tanviralam/Data/eclipseLunaWorkspace/F5shortRNA/", ".filter");
		for(int i=0; i<fList.size();i++)
		{
			System.out.println(fList.get(i));
		}


	}
}
