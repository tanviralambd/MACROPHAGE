#--------Call This function as --------
#./edgeR_KH.R Nano_InnerDistance_588/MyPipelineOutputs_keepSingle/GeneExpression.txt Nano_InnerDistance_588/LibrarySizes.txt 0.05 ./Nano_InnerDistance_588/MyPipelineOutputs_keepSingle/
#--------------------------------------

#!/usr/bin/Rscript

# load cmd arguments
args <- commandArgs(trailingOnly = TRUE)
expFile <- args[1]
librarySizesFile <- args[2]
FDR <- as.numeric(args[3])
basePath <- args[4]

library(edgeR)

# read in raw data table
rawdata <- read.table( file = expFile , header = FALSE, row.names=1 )

# read in library sizes
if(is.na(librarySizesFile)==FALSE){
	x <- read.csv(librarySizesFile,header=FALSE)
	lib.size <- as.numeric(x[,1])
}else
{
	lib.size <-NULL
}

# reformat as 'counts' w/ genes as rownames and libs as colnames (colnames already done)
foragers=list("F14","F27","F28","F41","F48","F49","F50","F54")
#foragers=list("F14","F27","F28","F48","F49","F50","F54")
nurses=list("N2","N4","N29","N31","N32","N33","N41","N42")
#foragers=list("F14","F27","F28","F41")
#nurses=list("F48","F49","F50","F54")
#foragers=list("F1_1","F2_1","F3_1","F4_1","F5_1")
#nurses=list("N1_1","N2_1","N3_1","N4_1","N5_1")
#foragers=list("F1_1","F1_2","F2_1","F2_2","F3_1","F3_2","F4_1","F4_2","F4_3","F5_1","F5_2","F5_3")
#nurses=list("N1_1","N1_2","N2_1","N2_2","N2_3","N3_1","N3_2","N4_1","N4_2","N5_1","N5_2")
colnames(rawdata)=c(foragers,nurses)
counts <- rawdata

# Quick Summery
dim( counts )
colSums( counts ) # Library Sizes
colSums( counts ) / 1e06 # Library Sizes in millions of reads
table( rowSums( counts ) )[ 1:30 ] # Number of genes with low counts

#  make group variable
group <- c(rep("F", length(foragers)), rep("N", length(nurses)))

#make DGElist
dge.list <- DGEList(counts, group=group, lib.size=lib.size)

# filter out low expressed genes
# keep only those that have at least 1 tpm in at least 3 libs as suggested in example
dge.list <- dge.list[rowSums(1e+06 * dge.list$counts/expandAsMatrix(dge.list$samples$lib.size, dim(dge.list)) > 1) >= 2,]

# calculate normalisation factors
dge.list <- calcNormFactors(dge.list)

# plot Multi-diemensional scaling plot of samples
svg(paste(basePath,'/edgeR_MDSPlot.svg',sep='')) #if you want, use (png)
plotMDS.DGEList( dge.list , method='bcv',labels = colnames( dge.list$counts ) ,xlab='BCV distance 1',ylab='BCV distance 2',col=c(rep('red',8),rep('blue',8)))
dev.off()


#  estimate common and tagwise dispersion
dge.list <- estimateCommonDisp(dge.list)
residual.df=((length(foragers) + length(nurses)) - 2)
prior.df = 50 #prior.df=prior.n * residual.df
prior.n = round(prior.df / residual.df)
#dge.list <- estimateTagwiseDisp(dge.list, prior.n=prior.n) #use this in case you have the old version of edgeR (ex: on our cluster)
dge.list <- estimateTagwiseDisp(dge.list, prior.df=50)   #use this in case you have new version of edgeR

# plot Mean Variance
svg(paste(basePath,'/edgeR_PlotMeanVar.svg',sep='')) #if you want, use (png)
meanVarPlot <- plotMeanVar( dge.list , show.raw.vars=TRUE ,show.tagwise.vars=TRUE ,show.binned.common.disp.vars=FALSE ,show.ave.raw.vars=FALSE , NBline = TRUE ,nbins = 100 ,pch = 16 ,xlab ="Mean Expression (Log10 Scale)" ,ylab = "Variance (Log10 Scale)" ,main = "Mean-Variance Plot" )
dev.off()

# perform differential expression tests
de.exactTest.tgw <- exactTest(dge.list, dispersion = "tagwise", pair = c("F", "N"))

# control for multiple testing and store complete table
resultsTbl.tgw <- topTags(de.exactTest.tgw, n = nrow(de.exactTest.tgw$table))$table

#Show how many DEG upregulated in Foragers (-1) and upregulated in Nurses (1) and non in both (0)
summary( de<-decideTestsDGE( de.exactTest.tgw ,  adjust.method="FDR", p.value=0.05) ) # the adjusted p-values (FDR) are used here

# plot the log-fold changes with DEG genes highlighted
svg(paste(basePath,'/edgeR_PlotLogFoldChange.svg',sep='')) #if you want, use (png)
detags <- rownames(dge.list)[as.logical(de)] 
plotSmear(de.exactTest.tgw, de.tags=detags,pair = c("F","N") ,cex = .35 ,xlab="Avergae Log Counts Per Million of Reads" , ylab="Log Fold-Change" )
abline(h = c(-2, 2), col = "blue")
dev.off()

# output results
write.table(resultsTbl.tgw, file=paste(basePath,'/edgeR_Output.txt',sep='') , sep = "\t" , row.names=TRUE)

# output DEG F and DEG N and Expression Matrix for all DEG
write.table(rownames(de.exactTest.tgw[de==1]$table),quote=FALSE,row.names=FALSE,col.names=FALSE,file=paste(basePath,'/N_DEG_',FDR,'.txt',sep=''))
write.table(rownames(de.exactTest.tgw[de==-1]$table),quote=FALSE,row.names=FALSE,col.names=FALSE,file=paste(basePath,'/F_DEG_',FDR,'.txt',sep=''))
write.table(dge.list$counts[ rownames( de.exactTest.tgw[de==1 | de==-1]$table ) , ],sep="\t",quote=FALSE,row.names=TRUE,col.names=FALSE,file=paste(basePath,'/DEG_GeneExp_Original_',FDR,'.txt',sep=''))
write.table(dge.list$pseudo.counts[ rownames( de.exactTest.tgw[de==1 | de==-1]$table ) , ],sep="\t",quote=FALSE,row.names=TRUE,col.names=FALSE,file=paste(basePath,'/DEG_GeneExp_Normalized_',FDR,'.txt',sep=''))
normalizedExpression <-cpm(dge.list,normalized.lib.sizes=TRUE)
write.table(normalizedExpression,sep="\t",quote=FALSE,row.names=TRUE,col.names=FALSE,file=paste(basePath,'/GeneExp_TMMNormalized.txt',sep=''))
#The pseudo.counts is not recommended by edgeR developer (Mark Robinson) so we used CPM above
#write.table(dge.list$pseudo.counts,sep="\t",quote=FALSE,row.names=TRUE,col.names=FALSE,file=paste(basePath,'/GeneExp_TMMNormalized_',FDR,'.txt',sep=''))
