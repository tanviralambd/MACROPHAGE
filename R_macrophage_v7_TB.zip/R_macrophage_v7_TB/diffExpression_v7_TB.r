
testCall <-function(){

myDir="D:/research/MACROPHAGE/R_macrophage_v7_TB/"; 
myData="D:/research/MACROPHAGE/data/dataCAGEv7_TB/"

# For linux
#myDir="/home/alamt/MACROPHAGE/R_macrophage_v7_TB/"; 
#myData="/home/alamt/MACROPHAGE/data/dataCAGEv7_TB/"


setwd(myDir);
source('diffExpression_v7_TB.r')

fnmData1="D:/research/MACROPHAGE/data/dataCAGEv7/mouse_macrophage_TB_infection_IFNg.counts.csv.matrix.0.0.withoutMtb"
fnmData2="D:/research/MACROPHAGE/data/dataCAGEv7/mouse_macrophage_TB_infection_IFNg.counts.csv.matrix.6.6.withoutMtb"
fnmLibsize1="D:/research/MACROPHAGE/data/dataCAGEv7/mouse_macrophage_TB_infection_IFNg.counts.csv.0.0.libsize.withoutMtb"
fnmLibsize2="D:/research/MACROPHAGE/data/dataCAGEv7/mouse_macrophage_TB_infection_IFNg.counts.csv.6.6.libsize.withoutMtb"
outPrefix="NFvsIFNG"
baseTime="0"
timeInterest="6"
extWithoutMtb=".withoutMtb"

}

doAnalysis <-function( fnmData1, fnmData2, fnmLibsize1 , fnmLibsize2 , outPrefix , baseTime , timeInterest, extWithoutMtb) {

	background="NS"
	target="S"

	baseMat = read.table(fnmData1, header=T, row.names=1)
	baseMatLibSize = read.table(fnmLibsize1, header=T, row.names=NULL)

	curMat = read.table(fnmData2, header=T, row.names=1)
	curMatLibSize = read.table(fnmLibsize2, header=T, row.names=NULL)

	## Merged Matix
	mergedMat = cbind(baseMat,curMat);
	fnmOutputMerge= paste(myData , outPrefix , ".matrix", ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  sep="");
	# write.table( mergedMat, file=fnmOutputMerge,row.names=T,col.names=T, sep='\t',quote=F);

	## Merged Lib size
	tmpMerge = cbind(baseMatLibSize,curMatLibSize);
	mergedLibsize= as.numeric(tmpMerge)
	#print(dim(mergedLibsize))

	##  make group variable
	mergedgroup <- c(rep("NS", ncol(baseMatLibSize)), rep("S", ncol(curMatLibSize)))
	#print(mergedgroup)


	## make DGElist
	dge.list <- DGEList(mergedMat, group=mergedgroup, lib.size=mergedLibsize)
	print('Before filter')
	print(dim(dge.list$counts))
	# filter out low expressed genes
	# keep only those that have at least 1 tpm in at least 3 libs as suggested in example
	thrTPM=1
	thrMinLibrary=2;
	dge.list.tpm<- 1e+06 * dge.list$counts/ expandAsMatrix(mergedLibsize, dim(dge.list) )

	dge.list <- dge.list[rowSums(1e+06 * dge.list$counts/ expandAsMatrix(mergedLibsize, dim(dge.list)) > thrTPM) >= thrMinLibrary,]

	print('After filter')
	print(dim(dge.list$counts))

	################################## Normalization: ####################################
	# The default normalization method employed by “edgeR” is the trimmed mean of M values
	# (TMM) method and accounts for under sampling of lowly expressed transcripts. 
	# http://grokbase.com/t/r/bioconductor/132mdden0w/bioc-edger-counts-or-pseudo-counts
	dge.list <- calcNormFactors( dge.list )
	dge.list.normalized<- cpm(dge.list, normalized.lib.size=TRUE) # It gives the normalized count

	################################## Find differentially expressed transcripts #######################

	#a.  estimate common and tagwise dispersion
	dge.list <- estimateCommonDisp(dge.list)
	residual.df=((length(baseMatLibSize) + length(curMatLibSize)) - 2)
	prior.df = 50 #prior.df=prior.n * residual.df
	prior.n = round(prior.df / residual.df)
	#dge.list <- estimateTagwiseDisp(dge.list, prior.n=prior.n) #use this in case you have the old version of edgeR (ex: on our cluster)
	dge.list <- estimateTagwiseDisp(dge.list, prior.df=50)   #use this in case you have new version of edgeR

	#b. perform differential expression tests
	de.exactTest.tgw <- exactTest(dge.list, dispersion = "tagwise", pair = c("NS", "S"))
	befCorrection=  dge.list$counts[ ( de.exactTest.tgw$table$PValue < 0.05 ) ,  ]  
	befCorrectionStat= de.exactTest.tgw$table[(de.exactTest.tgw$table$PValue < .05) , ]
	write.table(befCorrectionStat,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  ".deg" ,".beforeCorrStat"  ,sep="") )

	#d. control for multiple testing : FDR/ BH 
	isCorrected<-decideTestsDGE( de.exactTest.tgw ,  adjust.method="BH", p.value=0.05 )  # the adjusted p-values (fdr) / BH are used here
	aftCorrection= dge.list$counts[ rownames( de.exactTest.tgw[isCorrected==-1 | isCorrected==1]$table ) ,  ]
	aftCorrection.tpm= dge.list.tpm[ rownames( de.exactTest.tgw[isCorrected==-1 | isCorrected==1]$table ) ,  ]
	aftCorrection.norm= dge.list.normalized[ rownames( de.exactTest.tgw[isCorrected==-1 | isCorrected==1]$table ) ,  ]

	## Write after correction stat
	write.table(befCorrectionStat[ rownames( de.exactTest.tgw[isCorrected==-1 | isCorrected==1]$table ) , ],sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  ".deg" ,".afterCorrStat"  ,sep="") )


	

	## e. Rank based on P-value
	# resultsTbl.tgw <- topTags(de.exactTest.tgw, n = nrow(de.exactTest.tgw$table) , adjust.method="BH" sort.by="PValue" )$table

	# Show how many DEG upregulated in NS_base_nonstimulated (-1) and upregulated in S_stimulated (1) and non in both (0)
	# NO NEED write.table(summary( isCorrected) , file= paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb, ".summary" ,sep="") , sep = "\t" , row.names=TRUE)
	write.table(dge.list$counts[ rownames( de.exactTest.tgw[isCorrected==-1 | isCorrected==1]$table ) ,  ],sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb, ".deg" ,sep="") )
	write.table(dge.list$counts[ rownames( de.exactTest.tgw[isCorrected==1]$table ) ,  ],sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  ".deg"  , ".", target ,sep="") )


	# plot the log-fold changes with DEG genes highlighted
	png(paste(myDir, 'change.', baseTime , '.' ,timeInterest, '.png',sep='')) #if you want, use (png)
	detags <- rownames(dge.list)[as.logical(isCorrected)] 
	plotSmear(de.exactTest.tgw, de.tags=detags,pair = c("NS","S") ,cex = .35 ,xlab="Avergae Log Counts Per Million of Reads" , ylab="Log Fold-Change" )
	abline(h = c(-2, 2), col = "blue")
	dev.off()

	# Write only DEG original Tag Count
	write.table(aftCorrection,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData, outPrefix ,'.', baseTime , 'vs' ,timeInterest , extWithoutMtb, ".deg" , '.tagcount' ,sep='')  )
	# Write only DEG original Tag Count in TPM
	write.table(dge.list.tpm,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData, outPrefix ,'.', baseTime , 'vs' ,timeInterest , extWithoutMtb,  '.tagcount.TPM' ,sep='')  )
	# Write only DEG normalized Tag Count
	write.table(aftCorrection.norm,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData, outPrefix ,'.', baseTime , 'vs' ,timeInterest , extWithoutMtb, ".deg" , '.tagcount.norm' ,sep='')  )

}



doAnalysisFC <-function( fnmData1, fnmData2, fnmLibsize1 , fnmLibsize2 , outPrefix , baseTime , timeInterest, extWithoutMtb) {

background="NS"
target="S"

baseMat = read.table(fnmData1, header=T, row.names=1)
baseMatLibSize = read.table(fnmLibsize1, header=T, row.names=NULL)

curMat = read.table(fnmData2, header=T, row.names=1)
curMatLibSize = read.table(fnmLibsize2, header=T, row.names=NULL)

## Merged Matix
mergedMat = cbind(baseMat,curMat);
fnmOutputMerge= paste(myData , outPrefix , ".matrix", ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  sep="");
# write.table( mergedMat, file=fnmOutputMerge,row.names=T,col.names=T, sep='\t',quote=F);

## Merged Lib size
tmpMerge = cbind(baseMatLibSize,curMatLibSize);
mergedLibsize= as.numeric(tmpMerge)
#print(dim(mergedLibsize))

##  make group variable
mergedgroup <- c(rep("NS", ncol(baseMatLibSize)), rep("S", ncol(curMatLibSize)))
#print(mergedgroup)


## make DGElist
dge.list <- DGEList(mergedMat, group=mergedgroup, lib.size=mergedLibsize)
print('Before filter')
print(dim(dge.list$counts))
# filter out low expressed genes
# keep only those that have at least 1 tpm in at least 3 libs as suggested in example
thrTPM=1
thrMinLibrary=2;
thrPval=0.05;
thrPvalAll=1.00

## Avoid all filtering. NO NEED filtering . This is the difference with doAnalysis
if(FALSE){ 
	# dge.list.tpm<- 1e+06 * dge.list$counts/ expandAsMatrix(mergedLibsize, dim(dge.list) )
	# dge.list <- dge.list[rowSums(1e+06 * dge.list$counts/ expandAsMatrix(mergedLibsize, dim(dge.list)) > thrTPM) >= thrMinLibrary,]
}
print('After filter')
print(dim(dge.list$counts))

################################## Normalization: ####################################
# The default normalization method employed by “edgeR” is the trimmed mean of M values
# (TMM) method and accounts for under sampling of lowly expressed transcripts. 
# http://grokbase.com/t/r/bioconductor/132mdden0w/bioc-edger-counts-or-pseudo-counts
dge.list <- calcNormFactors( dge.list )
dge.list.normalized<- cpm(dge.list, normalized.lib.size=TRUE) # It gives the normalized count

################################## Find differentially expressed transcripts #######################

#a.  estimate common and tagwise dispersion
dge.list <- estimateCommonDisp(dge.list)
residual.df=((length(baseMatLibSize) + length(curMatLibSize)) - 2)
prior.df = 50 #prior.df=prior.n * residual.df
prior.n = round(prior.df / residual.df)
#dge.list <- estimateTagwiseDisp(dge.list, prior.n=prior.n) #use this in case you have the old version of edgeR (ex: on our cluster)
dge.list <- estimateTagwiseDisp(dge.list, prior.df=50)   #use this in case you have new version of edgeR
print('After Tagwise Dispersion')
print(dim(dge.list$counts))

#b. perform differential expression tests
de.exactTest.tgw <- exactTest(dge.list, dispersion = "tagwise", pair = c("NS", "S"))
befCorrection=  dge.list$counts[ ( de.exactTest.tgw$table$PValue <= thrPvalAll ) ,  ]  
befCorrectionStat= de.exactTest.tgw$table[(de.exactTest.tgw$table$PValue <= thrPvalAll) , ]
write.table(befCorrectionStat,sep="\t",quote=FALSE,row.names=TRUE,col.names=TRUE,file=paste(myData , outPrefix , ".", baseTime, "vs",timeInterest ,  extWithoutMtb,  ".all.stat"   ,sep="") )

}


getMergedMatLogFoldChange <- function(datafiles) {
	columnLogFC=1;

	mat2= read.table( paste(  myData,"/",datafiles[1] , sep=""), header=T,row.names=1)
	val2=mat2[,columnLogFC]
	val2 = as.matrix(val2)
	
	mat4= read.table( paste(  myData,"/",datafiles[2] , sep=""), header=T)
	val4=mat4[,columnLogFC]
	val4 = as.matrix(val4)

	mat6= read.table( paste(  myData,"/",datafiles[3] , sep=""), header=T)
	val6=mat6[,columnLogFC]
	val6 = as.matrix(val6)
	
	mat12= read.table( paste(  myData,"/",datafiles[4] , sep=""), header=T)
	val12=mat12[,columnLogFC]
	val12 = as.matrix(val12)

	if(FALSE){
		mat24= read.table( paste(  myData,"/",datafiles[5] , sep=""), header=T)
		val24=mat24[,columnLogFC]
		val24 = as.matrix(val24)
	}
	
	mergedMat = cbind(rownames(mat2),val2,val4,val6,val12 );
	return (mergedMat);

	}
	
	
getUniqueGeneNames <- function(datafilesDEG) {

curName2= read.table( paste(  myData,"/",datafilesDEG[1] , sep=""), header=T, row.names=1)
totRow=nrow(curName2)
totCol=ncol(curName2)
if(totRow==0 || totCol==1)
{
	curName2 = NULL
}else
{
	curName2=rownames(curName2)
}

curName4= read.table( paste(  myData,"/",datafilesDEG[2] , sep=""), header=T, row.names=1)
totRow=nrow(curName4)
totCol=ncol(curName4)
if(totRow==0 || totCol==1)
{
	curName4 = NULL
}else
{
	curName4=rownames(curName4)
}

curName6= read.table( paste(  myData,"/",datafilesDEG[3] , sep=""), header=T, row.names=1)
totRow=nrow(curName6)
totCol=ncol(curName6)
if(totRow==0 || totCol==1)
{
	curName6 = NULL
}else
{
	curName6=rownames(curName6)
}
curName12= read.table( paste(  myData,"/",datafilesDEG[4] , sep=""), header=T, row.names=1)
totRow=nrow(curName12)
totCol=ncol(curName12)
if(totRow==0 || totCol==1)
{
	curName12 = NULL
}else
{
	curName12=rownames(curName12)
}

if(FALSE){
	curName24= read.table( paste(  myData,"/",datafilesDEG[5] , sep=""), header=T, row.names=1)
	totRow=nrow(curName24)
	totCol=ncol(curName24)
	if(totRow==0 || totCol==1)
	{
		curName24 = NULL
	}else
	{
		curName24=rownames(curName24)
	}
}

finalName=union(curName2,curName4)
finalName=union(finalName,curName6)
finalName=union(finalName,curName12)

# finalName=union(finalName,curName24)


return (finalName);
}	



